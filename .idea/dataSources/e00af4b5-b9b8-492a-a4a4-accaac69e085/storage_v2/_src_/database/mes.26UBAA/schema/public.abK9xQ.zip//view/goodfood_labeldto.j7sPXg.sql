create view goodfood_labeldto
            (id, registrationdate, palletcontextday, palletcontextshiftname, palletcontextoperatorname,
             palletcontextoperatorsurname, productionlinenumber, masterordernumber, productnumber, printedcount,
             firstssccnumber, lastssccnumber, state, active)
as
SELECT label.id,
       label.registrationdate,
       palletcontext.day     AS palletcontextday,
       shift.name            AS palletcontextshiftname,
       staff.name            AS palletcontextoperatorname,
       staff.surname         AS palletcontextoperatorsurname,
       productionline.number AS productionlinenumber,
       masterorder.number    AS masterordernumber,
       product.number        AS productnumber,
       label.printedcount,
       label.firstssccnumber,
       label.lastssccnumber,
       label.state,
       label.active
FROM goodfood_label label
         LEFT JOIN goodfood_palletcontext palletcontext ON palletcontext.id = label.palletcontext_id
         LEFT JOIN basic_shift shift ON shift.id = palletcontext.shift_id
         LEFT JOIN basic_staff staff ON staff.id = palletcontext.operator_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = label.productionline_id
         LEFT JOIN masterorders_masterorder masterorder ON masterorder.id = label.masterorder_id
         LEFT JOIN masterorders_masterorderproduct masterorderproduct
                   ON masterorderproduct.masterorder_id = masterorder.id
         LEFT JOIN basic_product product ON product.id = masterorderproduct.product_id;

alter table goodfood_labeldto
    owner to postgres;


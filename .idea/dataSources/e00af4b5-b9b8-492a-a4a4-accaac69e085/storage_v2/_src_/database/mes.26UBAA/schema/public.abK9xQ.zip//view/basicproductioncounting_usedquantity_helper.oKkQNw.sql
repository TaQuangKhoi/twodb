create view basicproductioncounting_usedquantity_helper(usedquantity, order_id, product_id, technologyoperationcomponent_id) as
SELECT sum(topic.usedquantity) AS usedquantity,
       pt.order_id,
       topic.product_id,
       pt.technologyoperationcomponent_id
FROM productioncounting_trackingoperationproductincomponent topic
         JOIN productioncounting_productiontracking pt ON pt.id = topic.productiontracking_id
WHERE pt.state::text = '02accepted'::text
GROUP BY pt.order_id, topic.product_id, pt.technologyoperationcomponent_id;

alter table basicproductioncounting_usedquantity_helper
    owner to postgres;


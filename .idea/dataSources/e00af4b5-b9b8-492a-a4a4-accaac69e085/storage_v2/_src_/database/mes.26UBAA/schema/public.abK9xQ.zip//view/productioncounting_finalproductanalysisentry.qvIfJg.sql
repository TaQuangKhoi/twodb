create view productioncounting_finalproductanalysisentry
            (id, productionlinenumber, ordernumber, companynumber, assortmentname, productnumber, productname,
             productunit, size, quantity, wastes, donequantity, timerangefrom, timerangeto, shiftname,
             technologygeneratornumber)
as
SELECT row_number() OVER ()                                                                            AS id,
       pl.number                                                                                       AS productionlinenumber,
       ord.number                                                                                      AS ordernumber,
       c.number                                                                                        AS companynumber,
       assortment.name                                                                                 AS assortmentname,
       product.number                                                                                  AS productnumber,
       product.name                                                                                    AS productname,
       product.unit                                                                                    AS productunit,
       product.size,
       sum(COALESCE(topoc.usedquantity, 0::numeric))                                                   AS quantity,
       sum(COALESCE(topoc.wastesquantity, 0::numeric))                                                 AS wastes,
       sum(COALESCE(topoc.usedquantity, 0::numeric)) + sum(COALESCE(topoc.wastesquantity, 0::numeric)) AS donequantity,
       date(date_trunc('day'::text, pt.timerangefrom))                                                 AS timerangefrom,
       date(date_trunc('day'::text, pt.timerangeto))                                                   AS timerangeto,
       shift.name                                                                                      AS shiftname,
       tcontext.number                                                                                 AS technologygeneratornumber
FROM productioncounting_trackingoperationproductoutcomponent topoc
         JOIN productioncounting_productiontracking pt ON pt.id = topoc.productiontracking_id
         JOIN orders_order ord ON ord.id = pt.order_id
         JOIN basic_product product ON topoc.product_id = product.id
         JOIN technologies_technology technology ON technology.id = ord.technologyprototype_id
         LEFT JOIN basic_shift shift ON pt.shift_id = shift.id
         LEFT JOIN basic_assortment assortment ON product.assortment_id = assortment.id
         LEFT JOIN productionlines_productionline pl ON ord.productionline_id = pl.id
         LEFT JOIN basic_company c ON c.id = ord.company_id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext ON tcontext.id = technology.generatorcontext_id
WHERE ord.parent_id IS NULL
  AND (product.id = ord.product_id OR
       pt.technologyoperationcomponent_id IS NOT NULL AND topoc.typeofmaterial::text = '02intermediate'::text)
GROUP BY ord.number, shift.name, (date_trunc('day'::text, pt.timerangefrom)), (date_trunc('day'::text, pt.timerangeto)),
         pl.number, c.number, assortment.name, product.number, product.name, product.unit, product.size, tcontext.number
UNION ALL
SELECT row_number() OVER ()                                                                            AS id,
       pl.number                                                                                       AS productionlinenumber,
       ord.number                                                                                      AS ordernumber,
       c.number                                                                                        AS companynumber,
       assortment.name                                                                                 AS assortmentname,
       product.number                                                                                  AS productnumber,
       product.name                                                                                    AS productname,
       product.unit                                                                                    AS productunit,
       product.size,
       sum(COALESCE(topoc.usedquantity, 0::numeric))                                                   AS quantity,
       sum(COALESCE(topoc.wastesquantity, 0::numeric))                                                 AS wastes,
       sum(COALESCE(topoc.usedquantity, 0::numeric)) + sum(COALESCE(topoc.wastesquantity, 0::numeric)) AS donequantity,
       date(date_trunc('day'::text, pt.timerangefrom))                                                 AS timerangefrom,
       date(date_trunc('day'::text, pt.timerangeto))                                                   AS timerangeto,
       shift.name                                                                                      AS shiftname,
       tcontext.number                                                                                 AS technologygeneratornumber
FROM arch_productioncounting_trackingoperationproductoutcomponent topoc
         JOIN arch_productioncounting_productiontracking pt ON pt.id = topoc.productiontracking_id
         JOIN arch_orders_order ord ON ord.id = pt.order_id
         JOIN basic_product product ON topoc.product_id = product.id
         JOIN technologies_technology technology ON technology.id = ord.technologyprototype_id
         LEFT JOIN basic_shift shift ON pt.shift_id = shift.id
         LEFT JOIN basic_assortment assortment ON product.assortment_id = assortment.id
         LEFT JOIN productionlines_productionline pl ON ord.productionline_id = pl.id
         LEFT JOIN basic_company c ON c.id = ord.company_id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext ON tcontext.id = technology.generatorcontext_id
WHERE ord.parent_id IS NULL
  AND (product.id = ord.product_id OR
       pt.technologyoperationcomponent_id IS NOT NULL AND topoc.typeofmaterial::text = '02intermediate'::text)
GROUP BY ord.number, shift.name, (date_trunc('day'::text, pt.timerangefrom)), (date_trunc('day'::text, pt.timerangeto)),
         pl.number, c.number, assortment.name, product.number, product.name, product.unit, product.size,
         tcontext.number;

alter table productioncounting_finalproductanalysisentry
    owner to postgres;


create view orders_orderlistdto
            (id, active, number, name, datefrom, dateto, startdate, finishdate, state, externalnumber,
             externalsynchronized, issubcontracted, plannedquantity, donequantity, workplandelivered, deadline,
             ordercategory, plannedquantityforadditionalunit, unitforadditionalunit, productnumber, technologynumber,
             unit, masterordernumber, divisionname, companyname, masterorderdefinitionnumber, existsrepairorders,
             masterorderid, ordersgroupnumber, annotation)
as
SELECT ordersorder.id,
       ordersorder.active,
       ordersorder.number,
       ordersorder.name,
       ordersorder.datefrom,
       ordersorder.dateto,
       ordersorder.startdate,
       ordersorder.finishdate,
       ordersorder.state,
       ordersorder.externalnumber,
       ordersorder.externalsynchronized,
       ordersorder.issubcontracted,
       ordersorder.plannedquantity,
       ordersorder.donequantity,
       ordersorder.workplandelivered,
       ordersorder.deadline,
       ordersorder.ordercategory,
       COALESCE(ordersorder.plannedquantityforadditionalunit,
                ordersorder.plannedquantity)          AS plannedquantityforadditionalunit,
       COALESCE(product.additionalunit, product.unit) AS unitforadditionalunit,
       product.number                                 AS productnumber,
       technology.number                              AS technologynumber,
       product.unit,
       masterorder.number                             AS masterordernumber,
       division.name                                  AS divisionname,
       company.number                                 AS companyname,
       masterorderdefinition.number                   AS masterorderdefinitionnumber,
       CASE
           WHEN (EXISTS (SELECT repairoder.id
                         FROM repairs_repairorder repairoder
                         WHERE repairoder.order_id = ordersorder.id)) THEN true
           ELSE false
           END                                        AS existsrepairorders,
       masterorder.id::integer                        AS masterorderid,
       ordersgroup.number                             AS ordersgroupnumber,
       ''::character varying(255)                     AS annotation
FROM orders_order ordersorder
         JOIN basic_product product ON product.id = ordersorder.product_id
         LEFT JOIN technologies_technology technology ON technology.id = ordersorder.technology_id
         LEFT JOIN basic_company company ON company.id = ordersorder.company_id
         LEFT JOIN masterorders_masterorder masterorder ON masterorder.id = ordersorder.masterorder_id
         LEFT JOIN masterorders_masterorderdefinition masterorderdefinition
                   ON masterorderdefinition.id = masterorder.masterorderdefinition_id
         LEFT JOIN ordersgroups_ordersgroup ordersgroup ON ordersorder.ordersgroup_id = ordersgroup.id
         LEFT JOIN basic_division division ON division.id = ordersorder.division_id;

alter table orders_orderlistdto
    owner to postgres;


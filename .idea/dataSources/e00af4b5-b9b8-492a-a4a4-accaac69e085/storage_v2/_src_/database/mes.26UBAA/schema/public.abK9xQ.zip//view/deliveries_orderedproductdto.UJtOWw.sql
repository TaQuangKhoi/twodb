create view deliveries_orderedproductdto
            (id, succession, orderedquantity, priceperunit, totalprice, conversion, additionalquantity, description,
             actualversion, delivery, deliveryid, supplier, deliverydate, deliverystate, deliverynumber, deliveryname,
             deliveryactive, deliverycurrency, suppliername, productnumber, productname, productnorm, productunit,
             additionalcode, mergedproductnumberandadditionalcode, offernumber, negotiationnumber, operationnumber,
             productcatalognumber, deliveredquantity, additionaldeliveredquantity, lefttoreceivequantity,
             additionallefttoreceivequantity, hasattachments)
as
WITH product_attachments AS (SELECT product_1.id              AS productid,
                                    count(attachment.id) <> 0 AS hasattachments
                             FROM basic_product product_1
                                      LEFT JOIN basic_productattachment attachment
                                                ON attachment.product_id = product_1.id
                             GROUP BY product_1.id)
SELECT orderedproduct.id,
       orderedproduct.succession,
       orderedproduct.orderedquantity,
       orderedproduct.priceperunit,
       orderedproduct.totalprice,
       orderedproduct.conversion,
       orderedproduct.additionalquantity,
       orderedproduct.description,
       orderedproduct.actualversion,
       delivery.id                                                                           AS delivery,
       delivery.id::integer                                                                  AS deliveryid,
       delivery.supplier_id                                                                  AS supplier,
       delivery.deliverydate,
       delivery.state                                                                        AS deliverystate,
       delivery.number                                                                       AS deliverynumber,
       delivery.name                                                                         AS deliveryname,
       delivery.active                                                                       AS deliveryactive,
       currency.alphabeticcode                                                               AS deliverycurrency,
       supplier.name                                                                         AS suppliername,
       product.number                                                                        AS productnumber,
       product.name                                                                          AS productname,
       product.norm                                                                          AS productnorm,
       product.unit                                                                          AS productunit,
       addcode.code                                                                          AS additionalcode,
       product.number::text ||
       CASE
           WHEN addcode.code IS NULL THEN ''::text
           ELSE ' - '::text || addcode.code::text
           END                                                                               AS mergedproductnumberandadditionalcode,
       offer.number                                                                          AS offernumber,
       negotiation.number                                                                    AS negotiationnumber,
       operation.number                                                                      AS operationnumber,
       (SELECT productcatalognumbers_productcatalognumbers.catalognumber
        FROM productcatalognumbers_productcatalognumbers
        WHERE productcatalognumbers_productcatalognumbers.product_id = product.id
          AND productcatalognumbers_productcatalognumbers.company_id = delivery.supplier_id) AS productcatalognumber,
       orderedproduct.deliveredquantity,
       orderedproduct.additionaldeliveredquantity,
       orderedproduct.orderedquantity - orderedproduct.deliveredquantity                     AS lefttoreceivequantity,
       orderedproduct.additionalquantity -
       orderedproduct.additionaldeliveredquantity                                            AS additionallefttoreceivequantity,
       attachments.hasattachments
FROM deliveries_orderedproduct orderedproduct
         LEFT JOIN deliveries_delivery delivery ON orderedproduct.delivery_id = delivery.id
         LEFT JOIN basic_currency currency ON delivery.currency_id = currency.id
         LEFT JOIN basic_company supplier ON delivery.supplier_id = supplier.id
         LEFT JOIN basic_product product ON orderedproduct.product_id = product.id
         LEFT JOIN supplynegotiations_offer offer ON orderedproduct.offer_id = offer.id
         LEFT JOIN supplynegotiations_negotiation negotiation ON offer.negotiation_id = negotiation.id
         LEFT JOIN technologies_operation operation ON orderedproduct.operation_id = operation.id
         LEFT JOIN basic_additionalcode addcode ON orderedproduct.additionalcode_id = addcode.id
         LEFT JOIN product_attachments attachments ON attachments.productid = product.id;

alter table deliveries_orderedproductdto
    owner to postgres;


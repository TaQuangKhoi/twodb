create function add_archived_column() returns void
    language plpgsql
as
$$
	DECLARE
		arch_table RECORD;
	BEGIN
		FOR arch_table IN SELECT * FROM information_schema.tables AS t
			WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE'
				AND t.table_name LIKE 'arch_%'
			ORDER BY t.table_name
		LOOP
			EXECUTE 'ALTER TABLE '|| arch_table.table_name ||' ADD COLUMN archived boolean';
			EXECUTE 'ALTER TABLE '|| arch_table.table_name ||' ALTER COLUMN archived SET DEFAULT FALSE';
		END LOOP;
	END;
$$;

alter function add_archived_column() owner to postgres;


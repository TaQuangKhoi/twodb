create view masterorders_masterorderposition_manyproducts
            (id, masterorderdefinitionnumber, masterorderid, productid, masterorderproductid, name, number, deadline,
             masterorderstatus, masterorderpositionstatus, masterorderquantity, cumulatedmasterorderquantity,
             producedorderquantity, lefttorelease, comments, productnumber, productname, unit, technologyname,
             companyname, active, companypayer, assortmentname, state, description, quantitytakenfromwarehouse,
             quantityremainingtoorder, quantityremainingtoorderwithoutstock)
as
SELECT masterorderproduct.id,
       masterorderdefinition.number                                                        AS masterorderdefinitionnumber,
       masterorder.id::integer                                                             AS masterorderid,
       masterorderproduct.product_id::integer                                              AS productid,
       masterorderproduct.id::integer                                                      AS masterorderproductid,
       masterorder.name,
       masterorder.number,
       masterorder.deadline,
       masterorder.masterorderstate                                                        AS masterorderstatus,
       masterorderproduct.masterorderpositionstatus,
       COALESCE(masterorderproduct.masterorderquantity, 0::numeric)                        AS masterorderquantity,
       COALESCE((SELECT sum(orders.plannedquantity) AS sum), 0::numeric)                   AS cumulatedmasterorderquantity,
       COALESCE((SELECT sum(orders.donequantity) AS sum), 0::numeric)                      AS producedorderquantity,
       CASE
           WHEN (COALESCE(masterorderproduct.masterorderquantity, 0::numeric) -
                 COALESCE((SELECT sum(orders.donequantity) AS sum), 0::numeric)) > 0::numeric THEN
               COALESCE(masterorderproduct.masterorderquantity, 0::numeric) -
               COALESCE((SELECT sum(orders.donequantity) AS sum), 0::numeric)
           ELSE 0::numeric
           END                                                                             AS lefttorelease,
       masterorderproduct.comments,
       _product.number                                                                     AS productnumber,
       _product.name                                                                       AS productname,
       _product.unit,
       technology.number                                                                   AS technologyname,
       company.name                                                                        AS companyname,
       masterorder.active,
       companypayer.name                                                                   AS companypayer,
       assortment.name                                                                     AS assortmentname,
       masterorder.state,
       masterorder.description,
       masterorderproduct.quantitytakenfromwarehouse,
       GREATEST((COALESCE(masterorderproduct.masterorderquantity, 0::numeric) -
                 COALESCE((SELECT sum(orders.plannedquantity) AS sum), 0::numeric) -
                 COALESCE(masterorderproduct.quantitytakenfromwarehouse, 0::numeric))::numeric(14, 5),
                0::numeric(14, 5))                                                         AS quantityremainingtoorder,
       (COALESCE(masterorderproduct.masterorderquantity, 0::numeric) -
        COALESCE((SELECT sum(orders.plannedquantity) AS sum), 0::numeric))::numeric(14, 5) AS quantityremainingtoorderwithoutstock
FROM masterorders_masterorderproduct masterorderproduct
         LEFT JOIN masterorders_masterorder masterorder ON masterorderproduct.masterorder_id = masterorder.id
         LEFT JOIN masterorders_masterorderdefinition masterorderdefinition
                   ON masterorderdefinition.id = masterorder.masterorderdefinition_id
         LEFT JOIN basic_product _product ON _product.id = masterorderproduct.product_id
         LEFT JOIN basic_company company ON company.id = masterorder.company_id
         LEFT JOIN technologies_technology technology ON technology.id = masterorderproduct.technology_id
         LEFT JOIN orders_order orders ON orders.masterorder_id = masterorderproduct.masterorder_id AND
                                          orders.product_id = masterorderproduct.product_id
         LEFT JOIN basic_company companypayer ON companypayer.id = masterorder.companypayer_id
         LEFT JOIN basic_assortment assortment ON assortment.id = _product.assortment_id
GROUP BY masterorderdefinition.number, masterorder.id, masterorderproduct.product_id, masterorderproduct.id,
         masterorder.name, masterorder.deadline, masterorder.masterorderstate,
         masterorderproduct.masterorderpositionstatus, masterorderproduct.comments, _product.number, _product.name,
         _product.unit, technology.number, company.name, masterorder.active, companypayer.name, assortment.name;

alter table masterorders_masterorderposition_manyproducts
    owner to postgres;


create view arch_materialflowresources_documentdto
            (inbuffer, id, number, description, name, type, time, state, active, locationfrom_id, locationfromnumber,
             locationto_id, locationtonumber, company_id, companyname, documentaddress, user_id, username,
             maintenanceevent_id, maintenanceeventnumber, plannedevent_id, plannedeventnumber, delivery_id,
             deliverynumber, order_id, ordernumber, suborder_id, subordernumber, printed, issend)
as
SELECT arch_mv_materialflowresources_documentdto.inbuffer,
       arch_mv_materialflowresources_documentdto.id,
       arch_mv_materialflowresources_documentdto.number,
       arch_mv_materialflowresources_documentdto.description,
       arch_mv_materialflowresources_documentdto.name,
       arch_mv_materialflowresources_documentdto.type,
       arch_mv_materialflowresources_documentdto."time",
       arch_mv_materialflowresources_documentdto.state,
       arch_mv_materialflowresources_documentdto.active,
       arch_mv_materialflowresources_documentdto.locationfrom_id,
       arch_mv_materialflowresources_documentdto.locationfromnumber,
       arch_mv_materialflowresources_documentdto.locationto_id,
       arch_mv_materialflowresources_documentdto.locationtonumber,
       arch_mv_materialflowresources_documentdto.company_id,
       arch_mv_materialflowresources_documentdto.companyname,
       arch_mv_materialflowresources_documentdto.documentaddress,
       arch_mv_materialflowresources_documentdto.user_id,
       arch_mv_materialflowresources_documentdto.username,
       arch_mv_materialflowresources_documentdto.maintenanceevent_id,
       arch_mv_materialflowresources_documentdto.maintenanceeventnumber,
       arch_mv_materialflowresources_documentdto.plannedevent_id,
       arch_mv_materialflowresources_documentdto.plannedeventnumber,
       arch_mv_materialflowresources_documentdto.delivery_id,
       arch_mv_materialflowresources_documentdto.deliverynumber,
       arch_mv_materialflowresources_documentdto.order_id,
       arch_mv_materialflowresources_documentdto.ordernumber,
       arch_mv_materialflowresources_documentdto.suborder_id,
       arch_mv_materialflowresources_documentdto.subordernumber,
       arch_mv_materialflowresources_documentdto.printed,
       arch_mv_materialflowresources_documentdto.issend
FROM arch_mv_materialflowresources_documentdto;

alter table arch_materialflowresources_documentdto
    owner to postgres;


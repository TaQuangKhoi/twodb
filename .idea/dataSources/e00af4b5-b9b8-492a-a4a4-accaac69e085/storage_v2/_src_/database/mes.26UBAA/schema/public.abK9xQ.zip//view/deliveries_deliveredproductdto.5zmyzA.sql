create view deliveries_deliveredproductdto
            (id, succession, damagedquantity, deliveredquantity, priceperunit, totalprice, conversion,
             additionalquantity, iswaste, delivery, deliveryid, supplier, productnumber, productname, productunit,
             additionalcode, offernumber, operationnumber, storagelocationnumber, palletnumber, batch,
             productcatalognumber, pallettype, additionalunit)
as
SELECT deliveredproduct.id,
       deliveredproduct.succession,
       deliveredproduct.damagedquantity,
       deliveredproduct.deliveredquantity,
       deliveredproduct.priceperunit,
       deliveredproduct.totalprice,
       deliveredproduct.conversion,
       deliveredproduct.additionalquantity,
       deliveredproduct.iswaste,
       delivery.id                                                                           AS delivery,
       delivery.id::integer                                                                  AS deliveryid,
       delivery.supplier_id                                                                  AS supplier,
       product.number                                                                        AS productnumber,
       product.name                                                                          AS productname,
       product.unit                                                                          AS productunit,
       addcode.code                                                                          AS additionalcode,
       offer.number                                                                          AS offernumber,
       operation.number                                                                      AS operationnumber,
       slocation.number                                                                      AS storagelocationnumber,
       pnumber.number                                                                        AS palletnumber,
       deliveredproduct.batch,
       (SELECT productcatalognumbers_productcatalognumbers.catalognumber
        FROM productcatalognumbers_productcatalognumbers
        WHERE productcatalognumbers_productcatalognumbers.product_id = product.id
          AND productcatalognumbers_productcatalognumbers.company_id = delivery.supplier_id) AS productcatalognumber,
       deliveredproduct.pallettype,
       deliveredproduct.additionalunit
FROM deliveries_deliveredproduct deliveredproduct
         LEFT JOIN deliveries_delivery delivery ON deliveredproduct.delivery_id = delivery.id
         LEFT JOIN basic_product product ON deliveredproduct.product_id = product.id
         LEFT JOIN supplynegotiations_offer offer ON deliveredproduct.offer_id = offer.id
         LEFT JOIN technologies_operation operation ON deliveredproduct.operation_id = operation.id
         LEFT JOIN basic_additionalcode addcode ON deliveredproduct.additionalcode_id = addcode.id
         LEFT JOIN materialflowresources_storagelocation slocation ON deliveredproduct.storagelocation_id = slocation.id
         LEFT JOIN basic_palletnumber pnumber ON deliveredproduct.palletnumber_id = pnumber.id;

alter table deliveries_deliveredproductdto
    owner to postgres;


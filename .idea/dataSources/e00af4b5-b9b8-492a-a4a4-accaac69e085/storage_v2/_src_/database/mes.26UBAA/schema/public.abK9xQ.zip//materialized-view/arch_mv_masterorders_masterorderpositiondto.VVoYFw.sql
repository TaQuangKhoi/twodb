create materialized view arch_mv_masterorders_masterorderpositiondto as
SELECT masterorders_masterorderposition_manyproducts.id,
       masterorders_masterorderposition_manyproducts.masterorderdefinitionnumber,
       masterorders_masterorderposition_manyproducts.masterorderid,
       masterorders_masterorderposition_manyproducts.productid,
       masterorders_masterorderposition_manyproducts.masterorderproductid,
       masterorders_masterorderposition_manyproducts.name,
       masterorders_masterorderposition_manyproducts.number,
       masterorders_masterorderposition_manyproducts.deadline,
       masterorders_masterorderposition_manyproducts.masterorderstatus,
       masterorders_masterorderposition_manyproducts.masterorderpositionstatus,
       masterorders_masterorderposition_manyproducts.masterorderquantity,
       masterorders_masterorderposition_manyproducts.cumulatedmasterorderquantity,
       masterorders_masterorderposition_manyproducts.producedorderquantity,
       masterorders_masterorderposition_manyproducts.lefttorelease,
       masterorders_masterorderposition_manyproducts.comments,
       masterorders_masterorderposition_manyproducts.productnumber,
       masterorders_masterorderposition_manyproducts.productname,
       masterorders_masterorderposition_manyproducts.unit,
       masterorders_masterorderposition_manyproducts.technologyname,
       masterorders_masterorderposition_manyproducts.companyname,
       masterorders_masterorderposition_manyproducts.active,
       masterorders_masterorderposition_manyproducts.companypayer,
       masterorders_masterorderposition_manyproducts.assortmentname,
       masterorders_masterorderposition_manyproducts.state,
       masterorders_masterorderposition_manyproducts.description
FROM arch_masterorders_masterorderposition_manyproducts masterorders_masterorderposition_manyproducts;

alter materialized view arch_mv_masterorders_masterorderpositiondto owner to postgres;


create view productioncounting_trackingoperationproductoutcomponentdto
            (id, productiontrackingid, productnumber, productname, productunit, plannedquantity, producedsum, wastessum,
             remainingquantity, wastesquantity, usedquantity, wastedquantity, batchnumber)
as
WITH quantities AS (SELECT COALESCE(sum(opoc.usedquantity), 0::numeric)   AS producedsum,
                           COALESCE(sum(opoc.wastesquantity), 0::numeric) AS wastessum,
                           pt.order_id,
                           pt.technologyoperationcomponent_id,
                           opoc.product_id
                    FROM productioncounting_trackingoperationproductoutcomponent opoc
                             JOIN productioncounting_productiontracking pt ON pt.id = opoc.productiontracking_id
                    WHERE pt.state::text = '02accepted'::text
                    GROUP BY pt.order_id, pt.technologyoperationcomponent_id, opoc.product_id)
SELECT trackingoperationproductoutcomponent.id,
       productiontracking.id::integer                                        AS productiontrackingid,
       product.number                                                        AS productnumber,
       product.name                                                          AS productname,
       product.unit                                                          AS productunit,
       COALESCE(sum(productioncountingquantity.plannedquantity), 0::numeric) AS plannedquantity,
       min(quantities.producedsum)                                           AS producedsum,
       min(quantities.wastessum)                                             AS wastessum,
       GREATEST(COALESCE(sum(productioncountingquantity.plannedquantity), 0::numeric) - min(quantities.producedsum),
                0::numeric)                                                  AS remainingquantity,
       trackingoperationproductoutcomponent.wastesquantity,
       trackingoperationproductoutcomponent.usedquantity,
       trackingoperationproductoutcomponent.wastedquantity,
       b.number                                                              AS batchnumber
FROM productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON productiontracking.id = trackingoperationproductoutcomponent.productiontracking_id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductoutcomponent.product_id
         LEFT JOIN advancedgenealogy_batch b ON b.id = trackingoperationproductoutcomponent.batch_id
         LEFT JOIN basicproductioncounting_productioncountingquantity productioncountingquantity
                   ON productioncountingquantity.order_id = productiontracking.order_id AND
                      productioncountingquantity.product_id = trackingoperationproductoutcomponent.product_id AND
                      productioncountingquantity.role::text = '02produced'::text
         LEFT JOIN quantities ON quantities.order_id = productiontracking.order_id AND
                                 quantities.product_id = trackingoperationproductoutcomponent.product_id
WHERE productiontracking.technologyoperationcomponent_id IS NULL
GROUP BY trackingoperationproductoutcomponent.id, productiontracking.id, product.number, product.name, product.unit,
         trackingoperationproductoutcomponent.wastesquantity, trackingoperationproductoutcomponent.usedquantity,
         trackingoperationproductoutcomponent.wastedquantity, b.number
UNION
SELECT trackingoperationproductoutcomponent.id,
       productiontracking.id::integer                                        AS productiontrackingid,
       product.number                                                        AS productnumber,
       product.name                                                          AS productname,
       product.unit                                                          AS productunit,
       COALESCE(sum(productioncountingquantity.plannedquantity), 0::numeric) AS plannedquantity,
       min(quantities.producedsum)                                           AS producedsum,
       min(quantities.wastessum)                                             AS wastessum,
       GREATEST(COALESCE(sum(productioncountingquantity.plannedquantity), 0::numeric) - min(quantities.producedsum),
                0::numeric)                                                  AS remainingquantity,
       trackingoperationproductoutcomponent.wastesquantity,
       trackingoperationproductoutcomponent.usedquantity,
       trackingoperationproductoutcomponent.wastedquantity,
       b.number                                                              AS batchnumber
FROM productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON productiontracking.id = trackingoperationproductoutcomponent.productiontracking_id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductoutcomponent.product_id
         LEFT JOIN advancedgenealogy_batch b ON b.id = trackingoperationproductoutcomponent.batch_id
         LEFT JOIN basicproductioncounting_productioncountingquantity productioncountingquantity
                   ON productioncountingquantity.order_id = productiontracking.order_id AND
                      productioncountingquantity.technologyoperationcomponent_id =
                      productiontracking.technologyoperationcomponent_id AND
                      productioncountingquantity.product_id = trackingoperationproductoutcomponent.product_id AND
                      productioncountingquantity.role::text = '02produced'::text
         LEFT JOIN quantities quantities ON quantities.order_id = productiontracking.order_id AND
                                            quantities.technologyoperationcomponent_id =
                                            productiontracking.technologyoperationcomponent_id AND
                                            quantities.product_id = trackingoperationproductoutcomponent.product_id
WHERE productiontracking.technologyoperationcomponent_id IS NOT NULL
GROUP BY trackingoperationproductoutcomponent.id, productiontracking.id, product.number, product.name, product.unit,
         trackingoperationproductoutcomponent.wastesquantity, trackingoperationproductoutcomponent.usedquantity,
         trackingoperationproductoutcomponent.wastedquantity, b.number,
         productiontracking.technologyoperationcomponent_id;

alter table productioncounting_trackingoperationproductoutcomponentdto
    owner to postgres;


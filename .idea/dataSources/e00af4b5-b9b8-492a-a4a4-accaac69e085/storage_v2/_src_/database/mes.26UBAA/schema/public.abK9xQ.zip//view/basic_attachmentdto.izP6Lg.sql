create view basic_attachmentdto
            (pinnedto, pinnedtoobjectidentifier, pinnedtoobjectidentifiername, pinnedtoobjectid, pinnedtomodelname,
             attachment, name, size, ext, id, pinnedtocorrespondingview)
as
SELECT '01products'::text                 AS pinnedto,
       product.number                     AS pinnedtoobjectidentifier,
       product.name                       AS pinnedtoobjectidentifiername,
       product.id::integer                AS pinnedtoobjectid,
       'basic_product'::text              AS pinnedtomodelname,
       productattachment.attachment,
       productattachment.name,
       productattachment.size,
       upper(productattachment.ext::text) AS ext,
       row_number() OVER ()               AS id,
       'basic/productDetails'::text       AS pinnedtocorrespondingview
FROM basic_productattachment productattachment
         LEFT JOIN basic_product product ON productattachment.product_id = product.id
UNION ALL
SELECT '02technologies'::text                 AS pinnedto,
       technology.number                      AS pinnedtoobjectidentifier,
       technology.name                        AS pinnedtoobjectidentifiername,
       technology.id::integer                 AS pinnedtoobjectid,
       'technologies_technology'::text        AS pinnedtomodelname,
       technologyattachment.attachment,
       technologyattachment.name,
       technologyattachment.size,
       upper(technologyattachment.ext::text)  AS ext,
       1000000 + row_number() OVER ()         AS id,
       'technologies/technologyDetails'::text AS pinnedtocorrespondingview
FROM technologies_technologyattachment technologyattachment
         LEFT JOIN technologies_technology technology ON technologyattachment.technology_id = technology.id
UNION ALL
SELECT '03parts'::text                             AS pinnedto,
       machinepart.number                          AS pinnedtoobjectidentifier,
       machinepart.name                            AS pinnedtoobjectidentifiername,
       machinepart.id::integer                     AS pinnedtoobjectid,
       'basic_product'::text                       AS pinnedtomodelname,
       machinepartattachment.attachment,
       machinepartattachment.name,
       machinepartattachment.size,
       upper(machinepartattachment.ext::text)      AS ext,
       2000000 + row_number() OVER ()              AS id,
       'cmmsMachineParts/machinePartDetails'::text AS pinnedtocorrespondingview
FROM cmmsmachineparts_machinepartattachment machinepartattachment
         LEFT JOIN basic_product machinepart ON machinepartattachment.product_id = machinepart.id
UNION ALL
SELECT '04components'::text                   AS pinnedto,
       subassembly.number                     AS pinnedtoobjectidentifier,
       subassembly.name                       AS pinnedtoobjectidentifiername,
       subassembly.id::integer                AS pinnedtoobjectid,
       'basic_product'::text                  AS pinnedtomodelname,
       subassemblyattachment.attachment,
       subassemblyattachment.name,
       subassemblyattachment.size,
       upper(subassemblyattachment.ext::text) AS ext,
       3000000 + row_number() OVER ()         AS id,
       'basic/subassemblyDetails'::text       AS pinnedtocorrespondingview
FROM basic_subassemblyattachment subassemblyattachment
         LEFT JOIN basic_subassembly subassembly ON subassemblyattachment.subassembly_id = subassembly.id;

alter table basic_attachmentdto
    owner to postgres;


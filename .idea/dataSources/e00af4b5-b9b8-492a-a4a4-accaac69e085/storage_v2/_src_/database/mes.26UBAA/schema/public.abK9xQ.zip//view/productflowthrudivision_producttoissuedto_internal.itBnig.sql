create view productflowthrudivision_producttoissuedto_internal(id, location_id, product_id, quantity) as
SELECT row_number() OVER ()         AS id,
       resource.location_id,
       resource.product_id::integer AS product_id,
       sum(resource.quantity)       AS quantity
FROM materialflowresources_resource resource
GROUP BY resource.location_id, resource.product_id;

alter table productflowthrudivision_producttoissuedto_internal
    owner to postgres;


create function generate_pallet_externalnumber() returns text
    language plpgsql
as
$$
DECLARE
	_pattern text;
	_sequence_name text;
	_sequence_value numeric;
	_tmp text;
	_seq text;
	_externalnumber text;
BEGIN
	_pattern := '#seq';

	select nextval('goodfood_pallet_externalnumber_seq') into _sequence_value;

	_seq := to_char(_sequence_value, 'fm000000');
	if _seq like '%#%' then
		_seq := _sequence_value;
	end if;

	_externalnumber := _pattern;
	_externalnumber := replace(_externalnumber, '#seq', _seq);

	RETURN _externalnumber;
END;
$$;

alter function generate_pallet_externalnumber() owner to postgres;


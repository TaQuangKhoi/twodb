create function generate_and_set_resource_number(_time timestamp without time zone) returns text
    language plpgsql
as
$$
DECLARE
	_pattern text;
	_year numeric;
	_sequence_name text;
	_sequence_value numeric;
	_tmp text;
	_seq text;
	_number text;
BEGIN
	_pattern := '#year/#seq';
	_year := extract(year from _time);

	_sequence_name := 'materialflowresources_resource_number_' || _year;

	SELECT sequence_name into _tmp FROM information_schema.sequences where sequence_schema = 'public'
		and sequence_name = _sequence_name;
	if _tmp is null then
		execute 'CREATE SEQUENCE ' || _sequence_name || ';';
	end if;

	select nextval(_sequence_name) into _sequence_value;

	_seq := to_char(_sequence_value, 'fm00000');
	if _seq like '%#%' then
		_seq := _sequence_value;
	end if;

	_number := _pattern;
	_number := replace(_number, '#year', _year::text);
	_number := replace(_number, '#seq', _seq);

	RETURN _number;
END;
$$;

alter function generate_and_set_resource_number(timestamp) owner to postgres;


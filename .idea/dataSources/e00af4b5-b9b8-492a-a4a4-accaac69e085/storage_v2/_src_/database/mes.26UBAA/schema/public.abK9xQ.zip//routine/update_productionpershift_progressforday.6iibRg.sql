create function update_productionpershift_progressforday() returns void
    language plpgsql
as
$$
DECLARE
    progressforday record;
BEGIN
    FOR progressforday IN SELECT * FROM productionpershift_progressforday
    LOOP
        UPDATE productionpershift_progressforday
        SET productionpershift_id = (SELECT pps.id FROM productionpershift_progressforday pfd
				LEFT JOIN technologies_technologyoperationcomponent toc ON toc.id = pfd.technologyoperationcomponent_id
				LEFT JOIN orders_order ord ON ord.technology_id = toc.technology_id
				LEFT JOIN productionpershift_productionpershift pps ON pps.order_id = ord.id
				WHERE pfd.id = progressforday.id LIMIT 1)
        WHERE id = progressforday.id;
    END LOOP;
END;
$$;

alter function update_productionpershift_progressforday() owner to postgres;


create view orders_operationaltaskdto
            (id, number, name, description, type, state, startdate, finishdate, staffname, productionlinename,
             workstationname, orderid, ordernumber, tocid, technologyoperationcomponentnodenumber,
             technologyoperationcomponentissubcontracting, productnumber, productname, productunit, plannedquantity,
             usedquantity, remainingquantity, doneinpercentage, opertaskflagpercentexecutionwithcolor,
             percentageofexecutioncellcolor)
as
SELECT operationaltask.id,
       operationaltask.number,
       operationaltask.name,
       operationaltask.description,
       operationaltask.type,
       operationaltask.state,
       operationaltask.startdate,
       operationaltask.finishdate,
       (staff.surname::text || ' '::text) || staff.name::text AS staffname,
       productionline.name                                    AS productionlinename,
       workstation.number                                     AS workstationname,
       ordersorder.id::integer                                AS orderid,
       ordersorder.number                                     AS ordernumber,
       technologyoperationcomponent.id::integer               AS tocid,
       technologyoperationcomponent.nodenumber                AS technologyoperationcomponentnodenumber,
       technologyoperationcomponent.issubcontracting          AS technologyoperationcomponentissubcontracting,
       product.number::text                                   AS productnumber,
       product.name::text                                     AS productname,
       NULL::text                                             AS productunit,
       NULL::numeric                                          AS plannedquantity,
       NULL::numeric                                          AS usedquantity,
       NULL::numeric                                          AS remainingquantity,
       NULL::numeric                                          AS doneinpercentage,
       NULL::numeric                                          AS opertaskflagpercentexecutionwithcolor,
       NULL::character varying                                AS percentageofexecutioncellcolor
FROM orders_operationaltask operationaltask
         LEFT JOIN basic_staff staff ON staff.id = operationaltask.staff_id
         LEFT JOIN productionlines_productionline productionline
                   ON productionline.id = operationaltask.productionline_id
         LEFT JOIN basic_workstation workstation ON workstation.id = operationaltask.workstation_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = operationaltask.order_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationaltask.technologyoperationcomponent_id
         LEFT JOIN technologies_operationproductoutcomponent operationproductoutcomponent
                   ON operationproductoutcomponent.operationcomponent_id = technologyoperationcomponent.id
         LEFT JOIN basic_product product ON product.id = operationaltask.product_id
WHERE operationaltask.type::text = '01otherCase'::text
UNION ALL
SELECT operationaltask.id,
       operationaltask.number,
       operationaltask.name,
       operationaltask.description,
       operationaltask.type,
       operationaltask.state,
       operationaltask.startdate,
       operationaltask.finishdate,
       (staff.surname::text || ' '::text) || staff.name::text AS staffname,
       productionline.name                                    AS productionlinename,
       workstation.number                                     AS workstationname,
       ordersorder.id::integer                                AS orderid,
       ordersorder.number                                     AS ordernumber,
       technologyoperationcomponent.id::integer               AS tocid,
       technologyoperationcomponent.nodenumber                AS technologyoperationcomponentnodenumber,
       technologyoperationcomponent.issubcontracting          AS technologyoperationcomponentissubcontracting,
       product.number::text                                   AS productnumber,
       product.name::text                                     AS productname,
       product.unit::text                                     AS productunit,
       NULL::numeric                                          AS plannedquantity,
       NULL::numeric                                          AS usedquantity,
       NULL::numeric                                          AS remainingquantity,
       NULL::numeric                                          AS doneinpercentage,
       CASE
           WHEN (SELECT basic_parameter.opertaskflagpercentexecutionwithcolor
                 FROM basic_parameter
                 LIMIT 1) THEN 1::numeric
           ELSE 0::numeric
           END                                                AS opertaskflagpercentexecutionwithcolor,
       'red-cell'::character varying(255)                     AS percentageofexecutioncellcolor
FROM orders_operationaltask operationaltask
         LEFT JOIN basic_staff staff ON staff.id = operationaltask.staff_id
         LEFT JOIN productionlines_productionline productionline
                   ON productionline.id = operationaltask.productionline_id
         LEFT JOIN basic_workstation workstation ON workstation.id = operationaltask.workstation_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = operationaltask.order_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationaltask.technologyoperationcomponent_id
         LEFT JOIN technologies_operationproductoutcomponent operationproductoutcomponent
                   ON operationproductoutcomponent.operationcomponent_id = technologyoperationcomponent.id
         LEFT JOIN basic_product product ON product.id = operationaltask.product_id
         LEFT JOIN orders_scheduleposition scheduleposition ON scheduleposition.id = operationaltask.scheduleposition_id
WHERE ordersorder.state::text = '01pending'::text
  AND operationaltask.scheduleposition_id IS NULL
  AND operationaltask.type::text = '02executionOperationInOrder'::text
UNION ALL
SELECT operationaltask.id,
       operationaltask.number,
       operationaltask.name,
       operationaltask.description,
       operationaltask.type,
       operationaltask.state,
       operationaltask.startdate,
       operationaltask.finishdate,
       (staff.surname::text || ' '::text) || staff.name::text AS staffname,
       productionline.name                                    AS productionlinename,
       workstation.number                                     AS workstationname,
       ordersorder.id::integer                                AS orderid,
       ordersorder.number                                     AS ordernumber,
       technologyoperationcomponent.id::integer               AS tocid,
       technologyoperationcomponent.nodenumber                AS technologyoperationcomponentnodenumber,
       technologyoperationcomponent.issubcontracting          AS technologyoperationcomponentissubcontracting,
       product.number::text                                   AS productnumber,
       product.name::text                                     AS productname,
       product.unit::text                                     AS productunit,
       scheduleposition.quantity                              AS plannedquantity,
       0::numeric                                             AS usedquantity,
       scheduleposition.quantity                              AS remainingquantity,
       0::numeric                                             AS doneinpercentage,
       CASE
           WHEN (SELECT basic_parameter.opertaskflagpercentexecutionwithcolor
                 FROM basic_parameter
                 LIMIT 1) THEN 1::numeric
           ELSE 0::numeric
           END                                                AS opertaskflagpercentexecutionwithcolor,
       'red-cell'::character varying(255)                     AS percentageofexecutioncellcolor
FROM orders_operationaltask operationaltask
         LEFT JOIN basic_staff staff ON staff.id = operationaltask.staff_id
         LEFT JOIN productionlines_productionline productionline
                   ON productionline.id = operationaltask.productionline_id
         LEFT JOIN basic_workstation workstation ON workstation.id = operationaltask.workstation_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = operationaltask.order_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationaltask.technologyoperationcomponent_id
         LEFT JOIN technologies_operationproductoutcomponent operationproductoutcomponent
                   ON operationproductoutcomponent.operationcomponent_id = technologyoperationcomponent.id
         LEFT JOIN basic_product product ON product.id = operationaltask.product_id
         LEFT JOIN orders_scheduleposition scheduleposition ON scheduleposition.id = operationaltask.scheduleposition_id
WHERE ordersorder.state::text = '01pending'::text
  AND operationaltask.scheduleposition_id IS NOT NULL
  AND operationaltask.type::text = '02executionOperationInOrder'::text
UNION ALL
SELECT operationaltask.id,
       operationaltask.number,
       operationaltask.name,
       operationaltask.description,
       operationaltask.type,
       operationaltask.state,
       operationaltask.startdate,
       operationaltask.finishdate,
       (staff.surname::text || ' '::text) || staff.name::text                                     AS staffname,
       productionline.name                                                                        AS productionlinename,
       workstation.number                                                                         AS workstationname,
       ordersorder.id::integer                                                                    AS orderid,
       ordersorder.number                                                                         AS ordernumber,
       technologyoperationcomponent.id::integer                                                   AS tocid,
       technologyoperationcomponent.nodenumber                                                    AS technologyoperationcomponentnodenumber,
       technologyoperationcomponent.issubcontracting                                              AS technologyoperationcomponentissubcontracting,
       product.number::text                                                                       AS productnumber,
       product.name::text                                                                         AS productname,
       product.unit::text                                                                         AS productunit,
       productioncountingquantitydto.plannedquantity,
       GREATEST(productioncountingquantitydto.producedquantity, 0::numeric)                       AS usedquantity,
       GREATEST(COALESCE(productioncountingquantitydto.plannedquantity, 0::numeric) -
                COALESCE(productioncountingquantitydto.producedquantity, 0::numeric), 0::numeric) AS remainingquantity,
       ceil(COALESCE(productioncountingquantitydto.producedquantity, 0::numeric) * 100::numeric /
            productioncountingquantitydto.plannedquantity)                                        AS doneinpercentage,
       CASE
           WHEN (SELECT basic_parameter.opertaskflagpercentexecutionwithcolor
                 FROM basic_parameter
                 LIMIT 1) AND operationaltask.type::text = '02executionOperationInOrder'::text THEN 1::numeric
           ELSE 0::numeric
           END                                                                                    AS opertaskflagpercentexecutionwithcolor,
       CASE
           WHEN (COALESCE(productioncountingquantitydto.producedquantity, 0::numeric) * 100::numeric /
                 productioncountingquantitydto.plannedquantity) >= 100::numeric
               THEN 'green-cell'::character varying(255)
           WHEN (COALESCE(productioncountingquantitydto.producedquantity, 0::numeric) * 100::numeric /
                 productioncountingquantitydto.plannedquantity) = 0::numeric THEN 'red-cell'::character varying(255)
           ELSE 'yellow-cell'::character varying(255)
           END                                                                                    AS percentageofexecutioncellcolor
FROM orders_operationaltask operationaltask
         LEFT JOIN basic_staff staff ON staff.id = operationaltask.staff_id
         LEFT JOIN productionlines_productionline productionline
                   ON productionline.id = operationaltask.productionline_id
         LEFT JOIN basic_workstation workstation ON workstation.id = operationaltask.workstation_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = operationaltask.order_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationaltask.technologyoperationcomponent_id
         LEFT JOIN technologies_operationproductoutcomponent operationproductoutcomponent
                   ON operationproductoutcomponent.operationcomponent_id = technologyoperationcomponent.id
         LEFT JOIN basic_product product ON product.id = operationaltask.product_id
         LEFT JOIN basicproductioncounting_productioncountingquantitydto productioncountingquantitydto
                   ON productioncountingquantitydto.orderid = ordersorder.id AND
                      productioncountingquantitydto.tocid = technologyoperationcomponent.id AND
                      productioncountingquantitydto.role::text = '02produced'::text AND
                      (productioncountingquantitydto.typeofmaterial::text = '02intermediate'::text OR
                       productioncountingquantitydto.typeofmaterial::text = '03finalProduct'::text)
WHERE ordersorder.state::text <> '01pending'::text
  AND operationaltask.type::text = '02executionOperationInOrder'::text;

alter table orders_operationaltaskdto
    owner to postgres;


create view materialflowresources_resourcecorrectiondto
            (id, createdate, productnumber, productname, resourcenumber, correctionnumber, quantitycorrected,
             pricecorrected, batchcorrected, expirationdatecorrected, storagelocationcorrected, palletnumbercorrected,
             typeofpalletcorrected, deliverynumber, location_id, locationnumber, newpalletnumber, oldpalletnumber,
             newstoragelocationnumber, oldstoragelocationnumber)
as
SELECT correction.id,
       correction.createdate,
       product.number                                                                                                 AS productnumber,
       product.name                                                                                                   AS productname,
       correction.resourcenumber,
       correction.number                                                                                              AS correctionnumber,
       correction.oldquantity <> correction.newquantity                                                               AS quantitycorrected,
       COALESCE(correction.oldprice, 0::numeric) <>
       COALESCE(correction.newprice, 0::numeric)                                                                      AS pricecorrected,
       COALESCE(correction.oldbatch, ''::character varying)::text <>
       COALESCE(correction.newbatch, ''::character varying)::text                                                     AS batchcorrected,
       COALESCE(correction.oldexpirationdate, '1900-01-01'::date) <>
       COALESCE(correction.newexpirationdate, '1900-01-01'::date)                                                     AS expirationdatecorrected,
       COALESCE(correction.oldstoragelocation_id, 0::bigint) <>
       COALESCE(correction.newstoragelocation_id, 0::bigint)                                                          AS storagelocationcorrected,
       COALESCE(correction.oldpalletnumber_id, 0::bigint) <>
       COALESCE(correction.newpalletnumber_id, 0::bigint)                                                             AS palletnumbercorrected,
       COALESCE(correction.oldtypeofpallet, ''::character varying)::text <>
       COALESCE(correction.newtypeofpallet, ''::character varying)::text                                              AS typeofpalletcorrected,
       correction.deliverynumber,
       correction.location_id::integer                                                                                AS location_id,
       _location.number                                                                                               AS locationnumber,
       newpallet.number                                                                                               AS newpalletnumber,
       oldpallet.number                                                                                               AS oldpalletnumber,
       new_storagelocation.number                                                                                     AS newstoragelocationnumber,
       old_storagelocation.number                                                                                     AS oldstoragelocationnumber
FROM materialflowresources_resourcecorrection correction
         JOIN basic_product product ON correction.product_id = product.id
         LEFT JOIN materialflowresources_resource resource ON correction.resource_id = resource.id
         LEFT JOIN materialflow_location _location ON correction.location_id = _location.id
         LEFT JOIN basic_palletnumber newpallet ON correction.newpalletnumber_id = newpallet.id
         LEFT JOIN basic_palletnumber oldpallet ON correction.oldpalletnumber_id = oldpallet.id
         LEFT JOIN materialflowresources_storagelocation new_storagelocation
                   ON correction.newstoragelocation_id = new_storagelocation.id
         LEFT JOIN materialflowresources_storagelocation old_storagelocation
                   ON correction.oldstoragelocation_id = old_storagelocation.id;

alter table materialflowresources_resourcecorrectiondto
    owner to postgres;


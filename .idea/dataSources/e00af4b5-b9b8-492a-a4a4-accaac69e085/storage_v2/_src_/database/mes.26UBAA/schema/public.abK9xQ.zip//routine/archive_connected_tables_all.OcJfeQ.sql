create function archive_connected_tables_all() returns void
    language plpgsql
as
$$
DECLARE
    _masterOrder RECORD;
    _goodfoodLabel RECORD;
    _statesMessage RECORD;
    _goodfoodPallet RECORD;
    _printLabelsHelper RECORD;
    _order RECORD;
    _orderstatechange RECORD;
    _ordertimecalculation RECORD;
    _productionpershift RECORD;
    _progressforday RECORD;
    _productiontracking RECORD;
    _anomaly RECORD;
    _labelstatechange RECORD;
    _palletstatechange RECORD;
    _productiontrackingstatechange RECORD;
    _trackingoperationproductincomponent RECORD;
    _trackingoperationproductoutcomponent RECORD;
    _repairorder RECORD;
    _anomalyproductiontrackingentryhelper RECORD;
    _extrusionprotocol RECORD;
    _extrusionprotocolstatechange RECORD;
    _extrusionaddedmixentry RECORD;
    _extrusionpouring RECORD;
    _extrusiontakenoffmixentry RECORD;
    _confectionprotocol RECORD;
    _confectionfilmproduct RECORD;
    _confectionprotocolstatechange RECORD;
    _costcalculation RECORD;
    _bproductioncountingquantity RECORD;
    _basicproductioncounting RECORD;
    _avglaborcostcalcfororder RECORD;
    _atrackingrecord RECORD;
    _document_position RECORD;
    _document RECORD;
BEGIN
    SET session_replication_role = 'replica';

    FOR _masterOrder IN SELECT * FROM arch_masterorders_masterorder where archived = false
        LOOP
            -- masterorders_masterorder
            INSERT INTO arch_assignmenttoshift_multiassignmenttoshift SELECT * FROM assignmenttoshift_multiassignmenttoshift WHERE masterorder_id = _masterOrder.id;
            INSERT INTO arch_assignmenttoshift_staffassignmenttoshift SELECT * FROM assignmenttoshift_staffassignmenttoshift WHERE masterorder_id = _masterOrder.id;
            INSERT INTO arch_goodfood_label SELECT * FROM goodfood_label WHERE masterorder_id = _masterOrder.id;
            INSERT INTO arch_goodfood_printedlabel SELECT * FROM goodfood_printedlabel WHERE masterorder_id = _masterOrder.id;
            INSERT INTO arch_integrationbartender_printlabelshelper SELECT * FROM integrationbartender_printlabelshelper WHERE masterorder_id = _masterOrder.id;
            INSERT INTO arch_masterorders_masterorderproduct SELECT * FROM masterorders_masterorderproduct WHERE masterorder_id = _masterOrder.id;
            -- goodfood_label
            FOR _goodfoodLabel IN SELECT * FROM arch_goodfood_label WHERE archived = false
                LOOP
                    INSERT INTO arch_goodfood_labelstatechange SELECT * FROM goodfood_labelstatechange WHERE label_id = _goodfoodLabel.id;

                    INSERT INTO arch_goodfood_pallet SELECT * FROM goodfood_pallet WHERE label_id = _goodfoodLabel.id ORDER BY secondpallet_id DESC;
                    FOR _goodfoodPallet IN SELECT * FROM arch_goodfood_pallet
                        LOOP
                            INSERT INTO arch_goodfood_palletstatechange SELECT * FROM goodfood_palletstatechange WHERE pallet_id = _goodfoodPallet.id;
                        END LOOP;
                END LOOP;
            FOR _labelstatechange IN SELECT * FROM arch_goodfood_labelstatechange WHERE archived = false
                LOOP
                    INSERT INTO arch_states_message SELECT * FROM states_message WHERE labelstatechange_id = _labelstatechange.id;
                END LOOP;
            FOR _palletstatechange IN SELECT * FROM arch_goodfood_palletstatechange WHERE archived = false
                LOOP
                    INSERT INTO arch_states_message SELECT * FROM states_message WHERE palletstatechange_id = _palletstatechange.id;
                END LOOP;
            -- arch_integrationbartender_printlabelshelper
            FOR _printLabelsHelper IN SELECT * FROM arch_integrationbartender_printlabelshelper WHERE archived = false
                LOOP
                    INSERT INTO arch_integrationbartender_sendtoprint SELECT * FROM integrationbartender_sendtoprint WHERE printlabelshelper_id = _printLabelsHelper.id;
                END LOOP;
        END LOOP;
    -- arch_orders_order
    FOR _order IN SELECT * FROM arch_orders_order WHERE archived = false
        LOOP
            --RAISE NOTICE 'Order : %' , _order.number;

            INSERT INTO arch_orders_orderstatechange SELECT * FROM orders_orderstatechange WHERE order_id = _order.id;
            INSERT INTO arch_orders_reasontypecorrectiondatefrom SELECT * FROM orders_reasontypecorrectiondatefrom WHERE order_id = _order.id;
            INSERT INTO arch_orders_reasontypecorrectiondateto SELECT * FROM orders_reasontypecorrectiondateto WHERE order_id = _order.id;
            INSERT INTO arch_orders_reasontypedeviationeffectiveend SELECT * FROM orders_reasontypedeviationeffectiveend WHERE order_id = _order.id;
            INSERT INTO arch_orders_reasontypedeviationeffectivestart SELECT * FROM orders_reasontypedeviationeffectivestart WHERE order_id = _order.id;
            INSERT INTO arch_orders_typeofcorrectioncauses SELECT * FROM orders_typeofcorrectioncauses WHERE order_id = _order.id;
            INSERT INTO arch_technologies_barcodeoperationcomponent SELECT * FROM technologies_barcodeoperationcomponent WHERE order_id = _order.id;
            INSERT INTO arch_technologies_technologyoperationcomponentmergeproductin SELECT * FROM technologies_technologyoperationcomponentmergeproductin WHERE order_id = _order.id;
            INSERT INTO arch_technologies_technologyoperationcomponentmergeproductout SELECT * FROM technologies_technologyoperationcomponentmergeproductout WHERE order_id = _order.id;
            INSERT INTO arch_stoppage_stoppage SELECT * FROM stoppage_stoppage WHERE order_id = _order.id;
            INSERT INTO arch_urcmaterialavailability_requiredcomponent SELECT * FROM urcmaterialavailability_requiredcomponent WHERE order_id = _order.id;
            INSERT INTO arch_simplematerialbalance_simplematerialbalanceorderscomponent SELECT * FROM simplematerialbalance_simplematerialbalanceorderscomponent WHERE order_id = _order.id;
            INSERT INTO arch_productionscheduling_ordertimecalculation SELECT * FROM productionscheduling_ordertimecalculation WHERE order_id = _order.id;
            INSERT INTO arch_productionpershift_productionpershift SELECT * FROM productionpershift_productionpershift WHERE order_id = _order.id;
            INSERT INTO arch_productioncounting_productiontrackingreport SELECT * FROM productioncounting_productiontrackingreport WHERE order_id = _order.id;
            INSERT INTO arch_productioncounting_productiontracking SELECT * FROM productioncounting_productiontracking WHERE order_id = _order.id;
            INSERT INTO arch_productflowthrudivision_materialavailability SELECT * FROM productflowthrudivision_materialavailability WHERE order_id = _order.id;
            INSERT INTO arch_orders_operationaltask SELECT * FROM orders_operationaltask WHERE order_id = _order.id;
            INSERT INTO arch_goodfood_extrusionprotocol SELECT * FROM goodfood_extrusionprotocol WHERE order_id = _order.id;
            INSERT INTO arch_goodfood_confectionprotocol SELECT * FROM goodfood_confectionprotocol WHERE order_id = _order.id;
            INSERT INTO arch_costnormsformaterials_technologyinstoperproductincomp SELECT * FROM costnormsformaterials_technologyinstoperproductincomp WHERE order_id = _order.id;
            INSERT INTO arch_costcalculation_costcalculation SELECT * FROM costcalculation_costcalculation WHERE order_id = _order.id;
            INSERT INTO arch_basicproductioncounting_basicproductioncounting SELECT * FROM basicproductioncounting_basicproductioncounting WHERE order_id = _order.id;
            INSERT INTO arch_basicproductioncounting_productioncountingquantity SELECT * FROM basicproductioncounting_productioncountingquantity WHERE order_id = _order.id;
            INSERT INTO arch_basicproductioncounting_productioncountingoperationrun SELECT * FROM basicproductioncounting_productioncountingoperationrun WHERE order_id = _order.id;
            INSERT INTO arch_avglaborcostcalcfororder_avglaborcostcalcfororder SELECT * FROM avglaborcostcalcfororder_avglaborcostcalcfororder  WHERE order_id = _order.id;
            INSERT INTO arch_advancedgenealogy_trackingrecord SELECT * FROM advancedgenealogy_trackingrecord  WHERE order_id = _order.id;
            INSERT INTO arch_materialflowresources_document SELECT * FROM materialflowresources_document WHERE order_id = _order.id;
        END LOOP;
    --RAISE NOTICE '--------->	arch_orders_orderstatechange';

    -- arch_orders_orderstatechange
    FOR _orderstatechange IN SELECT * FROM arch_orders_orderstatechange WHERE archived = false
        LOOP
            INSERT INTO arch_states_message SELECT * FROM states_message WHERE orderstatechange_id = _orderstatechange.id;
            INSERT INTO arch_orders_reasontypeofchangingorderstate SELECT * FROM orders_reasontypeofchangingorderstate WHERE orderstatechange_id = _orderstatechange.id;
        END LOOP;
    --RAISE NOTICE '--------->	arch_productionscheduling_ordertimecalculation';

    -- arch_productionscheduling_ordertimecalculation
    FOR _ordertimecalculation IN SELECT * FROM arch_productionscheduling_ordertimecalculation WHERE archived = false
        LOOP
            INSERT INTO arch_productionscheduling_opercomptimecalculation SELECT * FROM productionscheduling_opercomptimecalculation WHERE ordertimecalculation_id = _ordertimecalculation.id;
        END LOOP;
    --RAISE NOTICE '--------->	arch_productionpershift_productionpershift';

    -- arch_productionpershift_productionpershift
    FOR _productionpershift IN SELECT * FROM arch_productionpershift_productionpershift WHERE archived = false
        LOOP
            INSERT INTO arch_productionpershift_progressforday SELECT * FROM productionpershift_progressforday WHERE productionpershift_id = _productionpershift.id;
            INSERT INTO arch_productionpershift_reasontypeofcorrectionplan SELECT * FROM productionpershift_reasontypeofcorrectionplan WHERE productionpershift_id = _productionpershift.id;
        END LOOP;
    --RAISE NOTICE '--------->	arch_productionpershift_progressforday';

    -- arch_productionpershift_progressforday
    FOR _progressforday IN SELECT * FROM arch_productionpershift_progressforday WHERE archived = false
        LOOP
            INSERT INTO arch_productionpershift_dailyprogress SELECT * FROM productionpershift_dailyprogress WHERE progressforday_id = _progressforday.id;
        END LOOP;
    --RAISE NOTICE '--------->	arch_productioncounting_productiontracking';

    -- arch_productioncounting_productiontracking
    FOR _productiontracking IN SELECT * FROM arch_productioncounting_productiontracking WHERE archived = false
        LOOP
            INSERT INTO arch_productioncounting_anomaly SELECT * FROM productioncounting_anomaly WHERE productiontracking_id = _productiontracking.id;
            INSERT INTO arch_productioncounting_productiontrackingstatechange SELECT * FROM productioncounting_productiontrackingstatechange WHERE productiontracking_id = _productiontracking.id;
            INSERT INTO arch_productioncounting_staffworktime SELECT * FROM productioncounting_staffworktime WHERE productionrecord_id = _productiontracking.id;
            INSERT INTO arch_productioncounting_trackingoperationproductincomponent SELECT * FROM productioncounting_trackingoperationproductincomponent WHERE productiontracking_id = _productiontracking.id;
            INSERT INTO arch_productioncounting_trackingoperationproductoutcomponent SELECT * FROM productioncounting_trackingoperationproductoutcomponent WHERE productiontracking_id = _productiontracking.id;
            INSERT INTO arch_repairs_repairorder SELECT * FROM repairs_repairorder WHERE productiontracking_id = _productiontracking.id;

        END LOOP;
    FOR _productiontrackingstatechange IN SELECT * FROM arch_productioncounting_productiontrackingstatechange WHERE archived = false
        LOOP
            INSERT INTO arch_states_message SELECT * FROM states_message WHERE productiontrackingstatechange_id = _productiontrackingstatechange.id;
        END LOOP;
    -- arch_productioncounting_anomaly
    FOR _anomaly IN SELECT * FROM arch_productioncounting_anomaly WHERE archived = false
        LOOP
            INSERT INTO arch_productioncounting_anomalyexplanation SELECT * FROM productioncounting_anomalyexplanation WHERE anomaly_id = _anomaly.id;
        END LOOP;
    -- arch_productioncounting_trackingoperationproductincomponent
    FOR _trackingoperationproductincomponent IN SELECT * FROM arch_productioncounting_trackingoperationproductincomponent WHERE archived = false
        LOOP
            INSERT INTO arch_productioncounting_anomalyproductiontrackingentryhelper SELECT * FROM productioncounting_anomalyproductiontrackingentryhelper WHERE trackingoperationproductincomponent_id = _trackingoperationproductincomponent.id;
            INSERT INTO arch_productioncounting_settechnologyincomponents SELECT * FROM productioncounting_settechnologyincomponents WHERE trackingoperationproductincomponent_id = _trackingoperationproductincomponent.id;
            INSERT INTO arch_repairs_repairorderproduct SELECT * FROM repairs_repairorderproduct WHERE trackingoperationproductincomponent_id = _trackingoperationproductincomponent.id;
        END LOOP;
    -- arch_productioncounting_trackingoperationproductoutcomponent
    FOR _trackingoperationproductoutcomponent IN SELECT * FROM arch_productioncounting_trackingoperationproductoutcomponent  WHERE archived = false
        LOOP
            INSERT INTO arch_productioncounting_settrackingoperationproductincomponents SELECT * FROM productioncounting_settrackingoperationproductincomponents WHERE trackingoperationproductoutcomponent_id = _trackingoperationproductoutcomponent.id;
        END LOOP;
    -- arch_repairs_repairorder
    FOR _repairorder IN SELECT * FROM arch_repairs_repairorder  WHERE archived = false
        LOOP
            INSERT INTO arch_repairs_repairorderstatechange SELECT * FROM repairs_repairorderstatechange WHERE repairorder_id = _repairorder.id;
            INSERT INTO arch_repairs_repairorderworktime SELECT * FROM repairs_repairorderworktime WHERE repairorder_id = _repairorder.id;
        END LOOP;
    -- arch_productioncounting_anomalyproductiontrackingentryhelper
    FOR _anomalyproductiontrackingentryhelper IN SELECT * FROM arch_productioncounting_anomalyproductiontrackingentryhelper WHERE archived = false
        LOOP
            INSERT INTO arch_productioncounting_anomalyreasoncontainer SELECT * FROM productioncounting_anomalyreasoncontainer WHERE anomalyproductiontrackingentryhelper_id = _anomalyproductiontrackingentryhelper.id;
        END LOOP;
    -- arch_goodfood_extrusionprotocol
    FOR _extrusionprotocol IN SELECT * FROM arch_goodfood_extrusionprotocol WHERE archived = false
        LOOP
            INSERT INTO arch_goodfood_extrusionaddedmixentry SELECT * FROM goodfood_extrusionaddedmixentry WHERE extrusionprotocol_id = _extrusionprotocol.id;
            INSERT INTO arch_goodfood_extrusionpouring SELECT * FROM goodfood_extrusionpouring WHERE extrusionprotocol_id = _extrusionprotocol.id;
            INSERT INTO arch_goodfood_extrusionprotocolcorrect SELECT * FROM goodfood_extrusionprotocolcorrect WHERE extrusionprotocol_id = _extrusionprotocol.id;
            INSERT INTO arch_goodfood_extrusionprotocolstatechange SELECT * FROM goodfood_extrusionprotocolstatechange WHERE extrusionprotocol_id = _extrusionprotocol.id;
            INSERT INTO arch_goodfood_extrusionsouse SELECT * FROM goodfood_extrusionsouse WHERE extrusionprotocol_id = _extrusionprotocol.id;
            INSERT INTO arch_goodfood_extrusiontakenoffmixentry SELECT * FROM goodfood_extrusiontakenoffmixentry WHERE extrusionprotocol_id = _extrusionprotocol.id;

        END LOOP;
    -- arch_goodfood_extrusionprotocolstatechange
    FOR _extrusionprotocolstatechange IN SELECT * FROM arch_goodfood_extrusionprotocolstatechange WHERE archived = false
        LOOP
            INSERT INTO arch_states_message SELECT * FROM states_message WHERE extrusionprotocolstatechange_id = _extrusionprotocolstatechange.id;
        END LOOP;
    -- arch_goodfood_extrusionaddedmixentry
    FOR _extrusionaddedmixentry IN SELECT * FROM arch_goodfood_extrusionaddedmixentry WHERE archived = false
        LOOP
            INSERT INTO arch_goodfood_extrusionaddedmixingredient SELECT * FROM goodfood_extrusionaddedmixingredient WHERE extrusionaddedmixentry_id = _extrusionaddedmixentry.id;
        END LOOP;
    -- arch_goodfood_extrusionpouring
    FOR _extrusionpouring IN SELECT * FROM arch_goodfood_extrusionpouring  WHERE archived = false
        LOOP
            INSERT INTO arch_goodfood_extrusionpouringingredient SELECT * FROM goodfood_extrusionpouringingredient WHERE extrusionpouring_id = _extrusionpouring.id;
            INSERT INTO arch_goodfood_extrusionpouringmix SELECT * FROM goodfood_extrusionpouringmix WHERE extrusionpouring_id = _extrusionpouring.id;
        END LOOP;
    -- arch_goodfood_extrusiontakenoffmixentry
    FOR _extrusiontakenoffmixentry IN SELECT * FROM arch_goodfood_extrusiontakenoffmixentry WHERE archived = false
        LOOP
            INSERT INTO arch_goodfood_extrusiontakenoffmixingredient SELECT * FROM goodfood_extrusiontakenoffmixingredient WHERE extrusiontakenoffmixentry_id = _extrusiontakenoffmixentry.id;
        END LOOP;
    -- arch_goodfood_confectionprotocol
    FOR _confectionprotocol IN SELECT * FROM arch_goodfood_confectionprotocol WHERE archived = false
        LOOP
            INSERT INTO arch_goodfood_confectionadditionalinputproduct SELECT * FROM goodfood_confectionadditionalinputproduct WHERE confectionprotocol_id = _confectionprotocol.id;
            INSERT INTO arch_goodfood_confectionfilmproduct SELECT * FROM goodfood_confectionfilmproduct WHERE confectionprotocol_id = _confectionprotocol.id;
            INSERT INTO arch_goodfood_confectioninputproduct SELECT * FROM goodfood_confectioninputproduct WHERE confectionprotocol_id = _confectionprotocol.id;
            INSERT INTO arch_goodfood_confectionprotocolcorrect SELECT * FROM goodfood_confectionprotocolcorrect WHERE confectionprotocol_id = _confectionprotocol.id;
            INSERT INTO arch_goodfood_confectionprotocolstatechange SELECT * FROM goodfood_confectionprotocolstatechange WHERE confectionprotocol_id = _confectionprotocol.id;
            INSERT INTO arch_goodfood_confectionremainderinputproduct SELECT * FROM goodfood_confectionremainderinputproduct WHERE confectionprotocol_id = _confectionprotocol.id;
            INSERT INTO arch_goodfood_confectionstaff SELECT * FROM goodfood_confectionstaff WHERE confectionprotocol_id = _confectionprotocol.id;
        END LOOP;
    -- arch_goodfood_confectionfilmproduct
    FOR _confectionfilmproduct IN SELECT * FROM arch_goodfood_confectionfilmproduct WHERE archived = false
        LOOP
            INSERT INTO arch_goodfood_confectionfilmproductentry SELECT * FROM goodfood_confectionfilmproductentry WHERE confectionfilmproduct_id = _confectionfilmproduct.id;
        END LOOP;
    -- arch_goodfood_confectionprotocolstatechange
    FOR _confectionprotocolstatechange  IN SELECT * FROM arch_goodfood_confectionprotocolstatechange WHERE archived = false
        LOOP
            INSERT INTO arch_states_message SELECT * FROM states_message WHERE confectionprotocolstatechange_id = _confectionprotocolstatechange.id;
        END LOOP;
    -- arch_costcalculation_costcalculation
    FOR _costcalculation IN SELECT * FROM arch_costcalculation_costcalculation WHERE archived = false
        LOOP
            INSERT INTO arch_costcalculation_componentcost SELECT * FROM costcalculation_componentcost WHERE costcalculation_id = _costcalculation.id;
            INSERT INTO arch_costnormsforoperation_calculationoperationcomponent SELECT * FROM costnormsforoperation_calculationoperationcomponent WHERE costcalculation_id = _costcalculation.id;
        END LOOP;
    -- arch_basicproductioncounting_productioncountingquantity
    FOR _bproductioncountingquantity IN SELECT * FROM arch_basicproductioncounting_productioncountingquantity WHERE archived = false
        LOOP
            INSERT INTO arch_productioncounting_productioncountingquantitysetcomponent SELECT * FROM productioncounting_productioncountingquantitysetcomponent WHERE productioncountingquantity_id = _bproductioncountingquantity.id;
        END LOOP;
    -- arch_avglaborcostcalcfororder_avglaborcostcalcfororder
    FOR _avglaborcostcalcfororder IN SELECT * FROM arch_avglaborcostcalcfororder_avglaborcostcalcfororder WHERE archived = false
        LOOP
            INSERT INTO arch_avglaborcostcalcfororder_assignmentworkertoshift SELECT * FROM avglaborcostcalcfororder_assignmentworkertoshift WHERE avglaborcostcalcfororder_id = _avglaborcostcalcfororder.id;
        END LOOP;
    -- arch_advancedgenealogy_trackingrecord
    FOR _atrackingrecord IN SELECT * FROM arch_advancedgenealogy_trackingrecord WHERE archived = false
        LOOP
            INSERT INTO arch_advancedgenealogy_trackingrecord SELECT * FROM advancedgenealogy_trackingrecord WHERE trackingrecord_id = _atrackingrecord.id;
            INSERT INTO arch_advancedgenealogy_usedbatchsimple SELECT * FROM advancedgenealogy_usedbatchsimple WHERE trackingrecord_id = _atrackingrecord.id;
            INSERT INTO arch_advancedgenealogyfororders_genealogyproductincomponent SELECT * FROM advancedgenealogyfororders_genealogyproductincomponent WHERE trackingrecord_id = _atrackingrecord.id;

        END LOOP;
    FOR _document IN SELECT * FROM arch_materialflowresources_document WHERE archived = false
        LOOP
            INSERT INTO arch_esilco_importpositionerror SELECT * FROM esilco_importpositionerror WHERE document_id = _document.id;
            INSERT INTO arch_materialflowresources_position SELECT * FROM materialflowresources_position WHERE document_id = _document.id;
            INSERT INTO arch_productflowthrudivision_issue SELECT * FROM productflowthrudivision_issue WHERE document_id = _document.id;
            INSERT INTO arch_productflowthrudivision_producttoissuecorrection SELECT * FROM productflowthrudivision_producttoissuecorrection WHERE accountwithreservation_id = _document.id;
        END LOOP;
    FOR _document_position IN SELECT * FROM arch_materialflowresources_position WHERE archived = false
        LOOP
            INSERT INTO arch_materialflowresources_reservation SELECT * FROM materialflowresources_reservation WHERE position_id = _document_position.id;
        END LOOP;

    SET session_replication_role = 'origin';

END;
$$;

alter function archive_connected_tables_all() owner to postgres;


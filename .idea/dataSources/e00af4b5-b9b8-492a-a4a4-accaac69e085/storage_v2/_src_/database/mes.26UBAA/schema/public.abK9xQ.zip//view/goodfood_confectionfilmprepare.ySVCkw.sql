create view goodfood_confectionfilmprepare
            (protocolnumber, dayofshiftstart, confectionprotocolstate, ordernumber, productionlinenumber, productnumber,
             cullquantity)
as
SELECT confectionprotocol.number AS protocolnumber,
       confectionprotocol.dayofshiftstart,
       confectionprotocol.state  AS confectionprotocolstate,
       ordersorder.number        AS ordernumber,
       productionline.number     AS productionlinenumber,
       product.number            AS productnumber,
       confectionfilmproductentry.cullquantity
FROM goodfood_confectionprotocol confectionprotocol
         JOIN productionlines_productionline productionline ON productionline.id = confectionprotocol.productionline_id
         JOIN orders_order ordersorder ON ordersorder.id = confectionprotocol.order_id
         JOIN goodfood_confectionfilmproduct confectionfilmproduct
              ON confectionfilmproduct.confectionprotocol_id = confectionprotocol.id
         LEFT JOIN goodfood_confectionfilmproductentry confectionfilmproductentry
                   ON confectionfilmproduct.id = confectionfilmproductentry.confectionfilmproduct_id
         JOIN basic_product product ON product.id = confectionfilmproduct.filmproduct_id
UNION
SELECT confectionprotocol.number AS protocolnumber,
       confectionprotocol.dayofshiftstart,
       confectionprotocol.state  AS confectionprotocolstate,
       ordersorder.number        AS ordernumber,
       productionline.number     AS productionlinenumber,
       product.number            AS productnumber,
       confectioninputproduct.cullquantity
FROM goodfood_confectionprotocol confectionprotocol
         JOIN productionlines_productionline productionline ON productionline.id = confectionprotocol.productionline_id
         JOIN orders_order ordersorder ON ordersorder.id = confectionprotocol.order_id
         JOIN goodfood_confectioninputproduct confectioninputproduct
              ON confectioninputproduct.confectionprotocol_id = confectionprotocol.id
         JOIN basic_product product ON product.id = confectioninputproduct.product_id
UNION
SELECT confectionprotocol.number AS protocolnumber,
       confectionprotocol.dayofshiftstart,
       confectionprotocol.state  AS confectionprotocolstate,
       ordersorder.number        AS ordernumber,
       productionline.number     AS productionlinenumber,
       product.number            AS productnumber,
       confectioninputproduct.cullquantity
FROM goodfood_confectionprotocol confectionprotocol
         JOIN productionlines_productionline productionline ON productionline.id = confectionprotocol.productionline_id
         JOIN orders_order ordersorder ON ordersorder.id = confectionprotocol.order_id
         JOIN goodfood_confectionadditionalinputproduct confectioninputproduct
              ON confectioninputproduct.confectionprotocol_id = confectionprotocol.id
         JOIN basic_product product ON product.id = confectioninputproduct.product_id;

alter table goodfood_confectionfilmprepare
    owner to postgres;


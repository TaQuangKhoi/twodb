create function refreshmaterializedviewforarchive() returns void
    language plpgsql
as
$$
	DECLARE

	BEGIN
		RAISE NOTICE '-- refresh materialized view arch_mv_masterorders_masterorderpositiondto';
		EXECUTE 'refresh materialized view arch_mv_masterorders_masterorderpositiondto;';
		RAISE NOTICE '-- refresh materialized view arch_mv_masterorders_masterorderdto';
		EXECUTE 'refresh materialized view arch_mv_masterorders_masterorderdto;';
		RAISE NOTICE '-- refresh materialized view arch_mv_orders_orderlistdto';
		EXECUTE 'refresh materialized view arch_mv_orders_orderlistdto;';
		RAISE NOTICE '-- refresh materialized view arch_mv_ordersgroups_mordersgroupdto';
		EXECUTE 'refresh materialized view arch_mv_ordersgroups_mordersgroupdto;';
		RAISE NOTICE '-- refresh materialized view arch_mv_productioncounting_productiontrackingdto';
		EXECUTE 'refresh materialized view arch_mv_productioncounting_productiontrackingdto;';
		RAISE NOTICE '-- refresh materialized view arch_mv_materialflowresources_positiondto';
		EXECUTE 'refresh materialized view arch_mv_materialflowresources_positiondto;';
		RAISE NOTICE '-- refresh materialized view mv_arch_materialflowresources_documentdto';
		EXECUTE 'refresh materialized view arch_mv_materialflowresources_documentdto;';
	END;
    $$;

alter function refreshmaterializedviewforarchive() owner to postgres;


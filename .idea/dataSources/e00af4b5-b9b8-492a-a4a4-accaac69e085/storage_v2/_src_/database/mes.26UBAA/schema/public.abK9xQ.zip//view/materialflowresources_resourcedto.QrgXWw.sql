create view materialflowresources_resourcedto
            (id, number, quantity, quantityinadditionalunit, locationnumber, productnumber, productname, productunit,
             givenunit, conversion, reservedquantity, availablequantity, price, value, time, productiondate,
             expirationdate, batch, storagelocationnumber, additionalcode, palletnumber, typeofpallet, username,
             iscorrected, waste, deliverynumber, mergedproductnumberandadditionalcode, location_id,
             positionaddmultihelper_id)
as
SELECT r.id,
       r.number,
       r.quantity,
       r.quantityinadditionalunit,
       location.number        AS locationnumber,
       product.number         AS productnumber,
       product.name           AS productname,
       product.unit           AS productunit,
       r.givenunit,
       r.conversion,
       r.reservedquantity,
       r.availablequantity,
       r.price,
       r.quantity * r.price   AS value,
       r."time",
       r.productiondate,
       r.expirationdate,
       r.batch,
       storagelocation.number AS storagelocationnumber,
       additionalcode.code    AS additionalcode,
       palletnumber.number    AS palletnumber,
       r.typeofpallet,
       r.username,
       r.iscorrected,
       r.waste,
       r.deliverynumber,
       product.number::text ||
       CASE
           WHEN additionalcode.code IS NULL THEN ''::text
           ELSE ' - '::text || additionalcode.code::text
           END                AS mergedproductnumberandadditionalcode,
       r.location_id::integer AS location_id,
       NULL::bigint           AS positionaddmultihelper_id
FROM materialflowresources_resource r
         JOIN materialflow_location location ON location.id = r.location_id
         JOIN basic_product product ON product.id = r.product_id
         LEFT JOIN basic_additionalcode additionalcode ON additionalcode.id = r.additionalcode_id
         LEFT JOIN basic_palletnumber palletnumber ON palletnumber.id = r.palletnumber_id
         LEFT JOIN materialflowresources_storagelocation storagelocation ON storagelocation.id = r.storagelocation_id;

alter table materialflowresources_resourcedto
    owner to postgres;


create view goodfood_confectionfilm
            (id, protocolnumber, dayofshiftstart, confectionprotocolstate, ordernumber, productionlinenumber,
             productnumber, cullquantity)
as
SELECT row_number() OVER () AS id,
       cf.protocolnumber,
       cf.dayofshiftstart,
       cf.confectionprotocolstate,
       cf.ordernumber,
       cf.productionlinenumber,
       cf.productnumber,
       cf.cullquantity
FROM goodfood_confectionfilmprepare cf;

alter table goodfood_confectionfilm
    owner to postgres;


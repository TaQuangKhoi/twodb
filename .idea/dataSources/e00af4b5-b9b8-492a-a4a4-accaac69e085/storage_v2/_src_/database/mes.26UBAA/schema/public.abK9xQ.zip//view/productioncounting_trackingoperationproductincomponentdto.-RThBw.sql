create view productioncounting_trackingoperationproductincomponentdto
            (id, productiontrackingid, productnumber, productname, productunit, productid, plannedquantity,
             usedquantity, obtainedquantity, remainedquantity, effectiveusedquantity, batchnumber, replacement,
             productreplacementnumber, productreplacementid)
as
SELECT trackingoperationproductincomponent.id,
       productiontracking.id::integer                                        AS productiontrackingid,
       product.number                                                        AS productnumber,
       product.name                                                          AS productname,
       product.unit                                                          AS productunit,
       product.id::integer                                                   AS productid,
       COALESCE(sum(productioncountingquantity.plannedquantity), 0::numeric) AS plannedquantity,
       trackingoperationproductincomponent.usedquantity,
       trackingoperationproductincomponent.obtainedquantity,
       trackingoperationproductincomponent.remainedquantity,
       trackingoperationproductincomponent.effectiveusedquantity,
       b.number                                                              AS batchnumber,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM basic_substitutecomponent
                  WHERE basic_substitutecomponent.baseproduct_id = product.id)) > 0 THEN true
           ELSE false
           END                                                               AS replacement,
       productreplacement.number                                             AS productreplacementnumber,
       productreplacement.id::integer                                        AS productreplacementid
FROM productioncounting_trackingoperationproductincomponent trackingoperationproductincomponent
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON productiontracking.id = trackingoperationproductincomponent.productiontracking_id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductincomponent.product_id
         LEFT JOIN basic_product productreplacement
                   ON productreplacement.id = trackingoperationproductincomponent.replacementto_id
         LEFT JOIN advancedgenealogy_batch b ON b.id = trackingoperationproductincomponent.batch_id
         LEFT JOIN basicproductioncounting_productioncountingquantity productioncountingquantity
                   ON productioncountingquantity.order_id = productiontracking.order_id AND
                      productioncountingquantity.product_id = trackingoperationproductincomponent.product_id AND
                      productioncountingquantity.role::text = '01used'::text
WHERE productiontracking.technologyoperationcomponent_id IS NULL
GROUP BY trackingoperationproductincomponent.id, productiontracking.id, product.number, product.name, product.unit,
         product.id, trackingoperationproductincomponent.usedquantity,
         trackingoperationproductincomponent.obtainedquantity, trackingoperationproductincomponent.remainedquantity,
         trackingoperationproductincomponent.effectiveusedquantity, b.number, productreplacement.number,
         productreplacement.id
UNION
SELECT trackingoperationproductincomponent.id,
       productiontracking.id::integer                                        AS productiontrackingid,
       product.number                                                        AS productnumber,
       product.name                                                          AS productname,
       product.unit                                                          AS productunit,
       product.id::integer                                                   AS productid,
       COALESCE(sum(productioncountingquantity.plannedquantity), 0::numeric) AS plannedquantity,
       trackingoperationproductincomponent.usedquantity,
       trackingoperationproductincomponent.obtainedquantity,
       trackingoperationproductincomponent.remainedquantity,
       trackingoperationproductincomponent.effectiveusedquantity,
       b.number                                                              AS batchnumber,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM basic_substitutecomponent
                  WHERE basic_substitutecomponent.baseproduct_id = product.id)) > 0 THEN true
           ELSE false
           END                                                               AS replacement,
       productreplacement.number                                             AS productreplacementnumber,
       productreplacement.id::integer                                        AS productreplacementid
FROM productioncounting_trackingoperationproductincomponent trackingoperationproductincomponent
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON productiontracking.id = trackingoperationproductincomponent.productiontracking_id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductincomponent.product_id
         LEFT JOIN basic_product productreplacement
                   ON productreplacement.id = trackingoperationproductincomponent.replacementto_id
         LEFT JOIN advancedgenealogy_batch b ON b.id = trackingoperationproductincomponent.batch_id
         LEFT JOIN basicproductioncounting_productioncountingquantity productioncountingquantity
                   ON productioncountingquantity.order_id = productiontracking.order_id AND
                      productioncountingquantity.technologyoperationcomponent_id =
                      productiontracking.technologyoperationcomponent_id AND
                      productioncountingquantity.product_id = trackingoperationproductincomponent.product_id AND
                      productioncountingquantity.role::text = '01used'::text
WHERE productiontracking.technologyoperationcomponent_id IS NOT NULL
GROUP BY trackingoperationproductincomponent.id, productiontracking.id, product.number, product.name, product.unit,
         product.id, trackingoperationproductincomponent.usedquantity,
         trackingoperationproductincomponent.obtainedquantity, trackingoperationproductincomponent.remainedquantity,
         trackingoperationproductincomponent.effectiveusedquantity, b.number,
         productiontracking.technologyoperationcomponent_id, productreplacement.number, productreplacement.id;

alter table productioncounting_trackingoperationproductincomponentdto
    owner to postgres;


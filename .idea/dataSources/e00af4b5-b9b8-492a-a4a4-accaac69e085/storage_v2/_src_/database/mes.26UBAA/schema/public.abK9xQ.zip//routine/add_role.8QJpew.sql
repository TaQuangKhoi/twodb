create function add_role(role_name character varying, description character varying) returns void
    language plpgsql
as
$$
   DECLARE
    relationcount bigint;
   BEGIN

    SELECT count(*) INTO relationcount FROM qcadoosecurity_role WHERE identifier = role_name;
    IF relationcount = 0 THEN
        INSERT INTO qcadoosecurity_role (identifier, description) VALUES (role_name, description);
    END IF;

   END;
   $$;

alter function add_role(varchar, varchar) owner to postgres;


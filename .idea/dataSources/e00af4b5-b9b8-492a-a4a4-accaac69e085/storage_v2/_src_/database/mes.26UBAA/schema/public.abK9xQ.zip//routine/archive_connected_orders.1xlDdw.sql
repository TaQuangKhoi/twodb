create function archive_connected_orders() returns void
    language plpgsql
as
$$
	DECLARE
		_arch_order RECORD;
		_order RECORD;
	BEGIN
		FOR _arch_order IN SELECT * FROM arch_orders_order _archo WHERE parent_id is not null AND NOT EXISTS
			(SELECT 1 FROM arch_orders_order _archop WHERE _archo.parent_id = _archop.id )
		LOOP
			FOR _order IN SELECT * FROM orders_order ord  WHERE ord.id = _arch_order.parent_id
			LOOP
				INSERT INTO arch_orders_order SELECT * FROM orders_order WHERE id = _order.id;
			END LOOP;
		END LOOP;
	END;
$$;

alter function archive_connected_orders() owner to postgres;


create function generate_arch_tables(from_table text, parent_table text, depth integer) returns void
    language plpgsql
as
$$
	DECLARE
		table_data RECORD;
		table_references RECORD;
		table_count INTEGER;
		tablearch text;

	BEGIN
		RAISE NOTICE '';
		tablearch = CONCAT('arch_',from_table);
		RAISE NOTICE '-- Generate table: % \ parent %', tablearch,parent_table;
		IF NOT EXISTS (
			SELECT 1 FROM information_schema.tables WHERE table_name = tablearch
		) THEN
			 IF from_table != parent_table AND left(from_table, 5) != 'arch_' AND left(parent_table, 5) != 'arch_' AND depth < 10 THEN
				depth = depth + 1;
				EXECUTE 'CREATE TABLE IF NOT EXISTS ' || tablearch || ' ( like ' || from_table || ' INCLUDING DEFAULTS INCLUDING CONSTRAINTS INCLUDING INDEXES );';

				FOR table_data IN SELECT * FROM list_tablereferences(from_table)
					LOOP
						EXECUTE 'SELECT * FROM generate_arch_tables('''|| table_data.table_name||''', ''' || from_table ||''' , ' || depth ||' );';
					END LOOP;
			END IF;

		ELSE
			RAISE NOTICE '-- TABELA ISTNIEJSE : %', tablearch;
		END IF;
	END;
$$;

alter function generate_arch_tables(text, text, integer) owner to postgres;


create materialized view arch_mv_masterorders_masterorderdto as
SELECT masterorder.id,
       masterorderdefinition.number                                                                  AS masterorderdefinitionnumber,
       masterorder.number,
       masterorder.name,
       masterorder.deadline,
       company.number                                                                                AS company,
       companypayer.number                                                                           AS companypayer,
       COALESCE(orderedpositions.count::integer, 0)                                                  AS orderedpositionquantity,
       COALESCE(cumulatedpositions.count::integer, 0)                                                AS commissionedpositionquantity,
       COALESCE(orderedpositions.count::integer, 0) -
       COALESCE(cumulatedpositions.count::integer, 0)                                                AS quantityforcommission,
       masterorder.masterorderstate,
       masterorder.active,
       masterorder.pipedriveupdate,
       masterorder.state,
       masterorder.externalnumber,
       masterorder.asanataskid,
       masterorder.description
FROM arch_masterorders_masterorder masterorder
         LEFT JOIN masterorders_masterorderdefinition masterorderdefinition
                   ON masterorderdefinition.id = masterorder.masterorderdefinition_id
         LEFT JOIN basic_company company ON company.id = masterorder.company_id
         LEFT JOIN basic_company companypayer ON companypayer.id = masterorder.companypayer_id
         LEFT JOIN (SELECT arch_masterorders_masterorderpositiondto.masterorderid,
                           count(*) AS count
                    FROM arch_masterorders_masterorderpositiondto
                    GROUP BY arch_masterorders_masterorderpositiondto.masterorderid) orderedpositions
                   ON orderedpositions.masterorderid = masterorder.id
         LEFT JOIN (SELECT arch_masterorders_masterorderpositiondto.masterorderid,
                           count(*) AS count
                    FROM arch_masterorders_masterorderpositiondto
                    WHERE arch_masterorders_masterorderpositiondto.cumulatedmasterorderquantity > 0::numeric
                    GROUP BY arch_masterorders_masterorderpositiondto.masterorderid) cumulatedpositions
                   ON cumulatedpositions.masterorderid = masterorder.id;

alter materialized view arch_mv_masterorders_masterorderdto owner to postgres;


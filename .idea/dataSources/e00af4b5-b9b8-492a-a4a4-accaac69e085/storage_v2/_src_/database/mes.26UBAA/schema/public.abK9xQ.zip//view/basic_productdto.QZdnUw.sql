create view basic_productdto
            (id, number, name, globaltypeofmaterial, category, parentname, ean, externalnumber, assortmentname, norm,
             size, hasattachments, additionalcodes, active, unit, additionalunit)
as
SELECT product.id,
       product.number,
       product.name,
       product.globaltypeofmaterial,
       product.category,
       parent.name                             AS parentname,
       product.ean,
       product.externalnumber,
       assortment.name                         AS assortmentname,
       product.norm,
       product.size,
       count(attachment.id) <> 0               AS hasattachments,
       string_agg(code.code::text, ', '::text) AS additionalcodes,
       product.active,
       product.unit,
       product.additionalunit
FROM basic_product product
         LEFT JOIN basic_product parent ON product.parent_id = parent.id
         LEFT JOIN basic_assortment assortment ON product.assortment_id = assortment.id
         LEFT JOIN basic_productattachment attachment ON attachment.product_id = product.id
         LEFT JOIN basic_additionalcode code ON code.product_id = product.id
GROUP BY product.id, parent.name, assortment.name;

alter table basic_productdto
    owner to postgres;


create view ordersupplies_coverageproductdto
            (id, materialrequirementcoverageid, productid, lackfromdate, demandquantity, coveredquantity,
             reservemissingquantity, deliveredquantity, locationsquantity, state, negotiatedquantity, issubcontracted,
             ispurchased, productnumber, productname, productparent, productunit, producttype, planedquantity,
             producequantity, fromselectedorder, entityversion, allproductstype, companyid, companyname, replacement)
as
SELECT coverageproduct.id,
       coverageproduct.materialrequirementcoverage_id::integer AS materialrequirementcoverageid,
       coverageproduct.product_id::integer                     AS productid,
       coverageproduct.lackfromdate,
       coverageproduct.demandquantity,
       coverageproduct.coveredquantity,
       coverageproduct.reservemissingquantity,
       coverageproduct.deliveredquantity,
       coverageproduct.locationsquantity,
       coverageproduct.state,
       coverageproduct.negotiatedquantity,
       coverageproduct.issubcontracted,
       coverageproduct.ispurchased,
       coverageproduct.productnumber,
       coverageproduct.productname,
       _parent.name                                            AS productparent,
       coverageproduct.productunit,
       coverageproduct.producttype,
       coverageproduct.planedquantity,
       coverageproduct.producequantity,
       coverageproduct.fromselectedorder,
       coverageproduct.entityversion,
       coverageproduct.allproductstype,
       coverageproduct.company_id::integer                     AS companyid,
       _company.name                                           AS companyname,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM basic_substitutecomponent
                  WHERE basic_substitutecomponent.baseproduct_id = _product.id)) > 0 THEN true
           ELSE false
           END                                                 AS replacement
FROM ordersupplies_coverageproduct coverageproduct
         JOIN basic_product _product ON _product.id = coverageproduct.product_id
         LEFT JOIN basic_product _parent ON _parent.id = _product.parent_id
         LEFT JOIN basic_company _company ON _company.id = coverageproduct.company_id;

alter table ordersupplies_coverageproductdto
    owner to postgres;


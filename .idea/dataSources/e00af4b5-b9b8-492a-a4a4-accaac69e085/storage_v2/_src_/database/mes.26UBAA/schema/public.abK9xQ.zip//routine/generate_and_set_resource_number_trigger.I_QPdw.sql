create function generate_and_set_resource_number_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
	NEW.number := generate_and_set_resource_number(NEW.time);

	return NEW;
END;
$$;

alter function generate_and_set_resource_number_trigger() owner to postgres;


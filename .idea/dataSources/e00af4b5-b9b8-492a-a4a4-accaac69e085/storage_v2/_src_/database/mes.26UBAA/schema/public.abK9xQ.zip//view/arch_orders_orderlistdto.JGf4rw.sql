create view arch_orders_orderlistdto
            (id, active, number, name, datefrom, dateto, startdate, finishdate, state, externalnumber,
             externalsynchronized, issubcontracted, plannedquantity, donequantity, workplandelivered, deadline,
             ordercategory, plannedquantityforadditionalunit, unitforadditionalunit, productnumber, technologynumber,
             unit, masterordernumber, divisionname, companyname, masterorderdefinitionnumber, existsrepairorders,
             masterorderid, ordersgroupnumber, annotation)
as
SELECT arch_mv_orders_orderlistdto.id,
       arch_mv_orders_orderlistdto.active,
       arch_mv_orders_orderlistdto.number,
       arch_mv_orders_orderlistdto.name,
       arch_mv_orders_orderlistdto.datefrom,
       arch_mv_orders_orderlistdto.dateto,
       arch_mv_orders_orderlistdto.startdate,
       arch_mv_orders_orderlistdto.finishdate,
       arch_mv_orders_orderlistdto.state,
       arch_mv_orders_orderlistdto.externalnumber,
       arch_mv_orders_orderlistdto.externalsynchronized,
       arch_mv_orders_orderlistdto.issubcontracted,
       arch_mv_orders_orderlistdto.plannedquantity,
       arch_mv_orders_orderlistdto.donequantity,
       arch_mv_orders_orderlistdto.workplandelivered,
       arch_mv_orders_orderlistdto.deadline,
       arch_mv_orders_orderlistdto.ordercategory,
       arch_mv_orders_orderlistdto.plannedquantityforadditionalunit,
       arch_mv_orders_orderlistdto.unitforadditionalunit,
       arch_mv_orders_orderlistdto.productnumber,
       arch_mv_orders_orderlistdto.technologynumber,
       arch_mv_orders_orderlistdto.unit,
       arch_mv_orders_orderlistdto.masterordernumber,
       arch_mv_orders_orderlistdto.divisionname,
       arch_mv_orders_orderlistdto.companyname,
       arch_mv_orders_orderlistdto.masterorderdefinitionnumber,
       arch_mv_orders_orderlistdto.existsrepairorders,
       arch_mv_orders_orderlistdto.masterorderid,
       arch_mv_orders_orderlistdto.ordersgroupnumber,
       arch_mv_orders_orderlistdto.annotation
FROM arch_mv_orders_orderlistdto;

alter table arch_orders_orderlistdto
    owner to postgres;


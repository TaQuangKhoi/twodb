create function generate_and_set_confectionprotocol_externalnumber_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
	NEW.externalnumber := generate_confectionprotocol_externalnumber();

	return NEW;
END;
$$;

alter function generate_and_set_confectionprotocol_externalnumber_trigger() owner to postgres;


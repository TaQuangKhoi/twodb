create view basic_subassemblylistdto
            (id, active, number, name, workstationnumber, type, workstationtypenumber, productiondate,
             lastrepairsdate) as
SELECT subassembly.id,
       subassembly.active,
       subassembly.number,
       subassembly.name,
       workstation.number     AS workstationnumber,
       subassembly.type,
       workstationtype.number AS workstationtypenumber,
       subassembly.productiondate,
       event.maxdate          AS lastrepairsdate
FROM basic_subassembly subassembly
         LEFT JOIN basic_workstation workstation ON subassembly.workstation_id = workstation.id
         JOIN basic_workstationtype workstationtype ON subassembly.workstationtype_id = workstationtype.id
         LEFT JOIN (SELECT plannedevent.subassembly_id AS subassemblyid,
                           max(plannedevent.date)      AS maxdate
                    FROM cmmsmachineparts_plannedevent plannedevent
                    WHERE plannedevent.state::text = '05realized'::text
                      AND plannedevent.basedon::text = '01date'::text
                      AND plannedevent.type::text = '02repairs'::text
                    GROUP BY plannedevent.subassembly_id) event ON event.subassemblyid = subassembly.id;

alter table basic_subassemblylistdto
    owner to postgres;


create view materialflowresources_storagelocationdto_internal
            (locationnumber, storagelocationnumber, productnumber, productname, additionalcode, resourcequantity,
             productunit, quantityinadditionalunit, productadditionalunit, location_id)
as
SELECT location.number                                                                                    AS locationnumber,
       storagelocation.number                                                                             AS storagelocationnumber,
       COALESCE(product.number, storageproduct.number)                                                    AS productnumber,
       COALESCE(product.name, storageproduct.name)                                                        AS productname,
       resourcecode.code                                                                                  AS additionalcode,
       COALESCE(sum(resource.quantity), 0::numeric)                                                       AS resourcequantity,
       COALESCE(product.unit, storageproduct.unit)                                                        AS productunit,
       COALESCE(sum(resource.quantityinadditionalunit), 0::numeric)                                       AS quantityinadditionalunit,
       COALESCE(product.additionalunit, product.unit, storageproduct.additionalunit,
                storageproduct.unit)                                                                      AS productadditionalunit,
       location.id::integer                                                                               AS location_id
FROM materialflowresources_storagelocation storagelocation
         JOIN materialflow_location location ON storagelocation.location_id = location.id
         LEFT JOIN materialflowresources_resource resource ON resource.storagelocation_id = storagelocation.id
         LEFT JOIN basic_product product ON product.id = resource.product_id
         LEFT JOIN basic_product storageproduct ON storageproduct.id = storagelocation.product_id
         LEFT JOIN basic_additionalcode resourcecode ON resourcecode.id = resource.additionalcode_id
WHERE storagelocation.active = true
GROUP BY location.number, location.id, storagelocation.number, (COALESCE(product.number, storageproduct.number)),
         (COALESCE(product.name, storageproduct.name)), resourcecode.code,
         (COALESCE(product.unit, storageproduct.unit)),
         (COALESCE(product.additionalunit, product.unit, storageproduct.additionalunit, storageproduct.unit));

alter table materialflowresources_storagelocationdto_internal
    owner to postgres;


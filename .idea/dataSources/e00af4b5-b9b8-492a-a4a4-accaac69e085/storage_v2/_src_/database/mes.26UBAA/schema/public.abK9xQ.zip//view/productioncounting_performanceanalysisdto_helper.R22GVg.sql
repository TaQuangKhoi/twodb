create view productioncounting_performanceanalysisdto_helper
            (dailyperformance, productionlinequantity, staff_id, timerangefromwithouttime) as
SELECT CASE
           WHEN min(helper.labortimesum) = 0::double precision THEN 0::numeric
           ELSE (sub.dailyperformance::numeric::double precision / sum(helper.labortimesum))::numeric(14, 2)
           END AS dailyperformance,
       sub.productionlinequantity,
       sub.staff_id,
       sub.timerangefromwithouttime
FROM (SELECT 100 * sum(performanceanalysisdetaildto.timebasedonnorms)       AS dailyperformance,
             count(DISTINCT performanceanalysisdetaildto.productionline_id) AS productionlinequantity,
             performanceanalysisdetaildto.staff_id,
             performanceanalysisdetaildto.timerangefromwithouttime
      FROM productioncounting_performanceanalysisdetaildto performanceanalysisdetaildto
      GROUP BY performanceanalysisdetaildto.staff_id, performanceanalysisdetaildto.timerangefromwithouttime) sub
         LEFT JOIN productioncounting_performanceanalysislabortimesumdto_helper helper
                   ON helper.staff_id = sub.staff_id AND helper.timerangefromwithouttime = sub.timerangefromwithouttime
GROUP BY sub.staff_id, sub.timerangefromwithouttime, sub.productionlinequantity, sub.dailyperformance;

alter table productioncounting_performanceanalysisdto_helper
    owner to postgres;


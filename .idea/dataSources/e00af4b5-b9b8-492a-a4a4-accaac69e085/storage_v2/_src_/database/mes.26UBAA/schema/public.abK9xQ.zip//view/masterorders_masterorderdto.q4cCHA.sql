create view masterorders_masterorderdto
            (id, masterorderdefinitionnumber, number, name, deadline, company, companypayer, orderedpositionquantity,
             commissionedpositionquantity, quantityforcommission, masterorderstate, active, pipedriveupdate, state,
             externalnumber, asanataskid, description)
as
SELECT masterorder.id,
       masterorderdefinition.number                                                                  AS masterorderdefinitionnumber,
       masterorder.number,
       masterorder.name,
       masterorder.deadline,
       company.number                                                                                AS company,
       companypayer.number                                                                           AS companypayer,
       COALESCE(orderedpositions.count::integer, 0)                                                  AS orderedpositionquantity,
       COALESCE(cumulatedpositions.count::integer, 0)                                                AS commissionedpositionquantity,
       COALESCE(orderedpositions.count::integer, 0) -
       COALESCE(cumulatedpositions.count::integer, 0)                                                AS quantityforcommission,
       masterorder.masterorderstate,
       masterorder.active,
       masterorder.pipedriveupdate,
       masterorder.state,
       masterorder.externalnumber,
       masterorder.asanataskid,
       masterorder.description
FROM masterorders_masterorder masterorder
         LEFT JOIN masterorders_masterorderdefinition masterorderdefinition
                   ON masterorderdefinition.id = masterorder.masterorderdefinition_id
         LEFT JOIN basic_company company ON company.id = masterorder.company_id
         LEFT JOIN basic_company companypayer ON companypayer.id = masterorder.companypayer_id
         LEFT JOIN (SELECT masterorders_masterorderpositiondto.masterorderid,
                           count(*) AS count
                    FROM masterorders_masterorderpositiondto
                    GROUP BY masterorders_masterorderpositiondto.masterorderid) orderedpositions
                   ON orderedpositions.masterorderid = masterorder.id
         LEFT JOIN (SELECT masterorders_masterorderpositiondto.masterorderid,
                           count(*) AS count
                    FROM masterorders_masterorderpositiondto
                    WHERE masterorders_masterorderpositiondto.cumulatedmasterorderquantity > 0::numeric
                    GROUP BY masterorders_masterorderpositiondto.masterorderid) cumulatedpositions
                   ON cumulatedpositions.masterorderid = masterorder.id;

alter table masterorders_masterorderdto
    owner to postgres;


create view productioncounting_performanceanalysislabortimesumdto_helper(staff_id, timerangefromwithouttime, labortimesum) as
SELECT performanceanalysisdetaildto.staff_id,
       performanceanalysisdetaildto.timerangefromwithouttime,
       CASE
           WHEN min(performanceanalysisdetaildto.labortimesum) <> max(performanceanalysisdetaildto.labortimesum)
               THEN 0::double precision
           ELSE min(performanceanalysisdetaildto.labortimesum)
           END AS labortimesum
FROM productioncounting_performanceanalysisdetaildto performanceanalysisdetaildto
GROUP BY performanceanalysisdetaildto.staff_id, performanceanalysisdetaildto.timerangefromwithouttime,
         performanceanalysisdetaildto.shift_id, performanceanalysisdetaildto.productionline_id;

alter table productioncounting_performanceanalysislabortimesumdto_helper
    owner to postgres;


create view basicproductioncounting_producedquantity_withdraft
            (producedquantity, order_id, product_id, technologyoperationcomponent_id) as
SELECT sum(topoc.usedquantity) AS producedquantity,
       pt.order_id,
       topoc.product_id,
       pt.technologyoperationcomponent_id
FROM productioncounting_trackingoperationproductoutcomponent topoc
         JOIN productioncounting_productiontracking pt ON pt.id = topoc.productiontracking_id
WHERE pt.state::text = '02accepted'::text
   OR pt.state::text = '01draft'::text
GROUP BY pt.order_id, topoc.product_id, pt.technologyoperationcomponent_id;

alter table basicproductioncounting_producedquantity_withdraft
    owner to postgres;


create view technologies_operationproductincomponentdto
            (id, operationcomponentid, product_id, productid, productnumber, productname, productunit, quantity,
             priority, itemnumberintheexplodedview, value, operationname, nodenumber, technologyid, technologyname,
             technologystate, technologynumber, mastertechnology, activetechnology, technologytype,
             hasacceptedtechnology, hascheckedtechnology)
as
SELECT opic.id,
       toc.id::integer     AS operationcomponentid,
       product.id          AS product_id,
       product.id::integer AS productid,
       product.number      AS productnumber,
       product.name        AS productname,
       product.unit        AS productunit,
       opic.quantity,
       opic.priority,
       opic.itemnumberintheexplodedview,
       opic.value,
       op.name             AS operationname,
       toc.nodenumber,
       tech.id::integer    AS technologyid,
       tech.name           AS technologyname,
       tech.state          AS technologystate,
       tech.number         AS technologynumber,
       tech.master         AS mastertechnology,
       tech.active         AS activetechnology,
       tech.technologytype,
       count(at.id) > 0    AS hasacceptedtechnology,
       count(ct.id) > 0    AS hascheckedtechnology
FROM technologies_operationproductincomponent opic
         LEFT JOIN technologies_technologyoperationcomponent toc ON toc.id = opic.operationcomponent_id
         LEFT JOIN technologies_operation op ON op.id = toc.operation_id
         LEFT JOIN basic_product product ON product.id = opic.product_id
         LEFT JOIN technologies_technology tech ON tech.id = toc.technology_id
         LEFT JOIN technologies_technology at
                   ON at.product_id = opic.product_id AND at.technologytype IS NULL AND at.active = true AND
                      at.state::text = '02accepted'::text
         LEFT JOIN technologies_technology ct
                   ON ct.product_id = opic.product_id AND ct.technologytype IS NULL AND ct.active = true AND
                      ct.state::text = '05checked'::text
GROUP BY opic.id, toc.id, product.id, product.number, product.name, product.unit, opic.quantity, opic.priority,
         opic.itemnumberintheexplodedview, tech.name, tech.number, tech.state, tech.master, op.name, tech.active,
         tech.technologytype, tech.id;

alter table technologies_operationproductincomponentdto
    owner to postgres;


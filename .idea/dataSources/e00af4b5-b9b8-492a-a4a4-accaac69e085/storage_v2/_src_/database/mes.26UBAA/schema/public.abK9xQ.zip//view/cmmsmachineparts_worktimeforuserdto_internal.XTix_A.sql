create view cmmsmachineparts_worktimeforuserdto_internal
            (username, startdate, finishdate, duration, eventnumber, eventtype, objectnumber, actionname) as
SELECT u.username,
       swt.effectiveexecutiontimestart                            AS startdate,
       swt.effectiveexecutiontimeend                              AS finishdate,
       swt.labortime                                              AS duration,
       me.number                                                  AS eventnumber,
       me.type                                                    AS eventtype,
       COALESCE(s.number, w.number, p.number, d.number, f.number) AS objectnumber,
       NULL::character varying                                    AS actionname
FROM cmmsmachineparts_staffworktime swt
         JOIN qcadoosecurity_user u ON swt.worker_id = u.staff_id
         JOIN cmmsmachineparts_maintenanceevent me ON me.id = swt.maintenanceevent_id
         JOIN basic_factory f ON me.factory_id = f.id
         JOIN basic_division d ON me.division_id = d.id
         LEFT JOIN productionlines_productionline p ON me.productionline_id = p.id
         LEFT JOIN basic_workstation w ON me.workstation_id = w.id
         LEFT JOIN basic_subassembly s ON me.subassembly_id = s.id
UNION ALL
SELECT u.username,
       per.startdate,
       per.finishdate,
       per.duration,
       pe.number                                                  AS eventnumber,
       pe.type                                                    AS eventtype,
       COALESCE(s.number, w.number, p.number, d.number, f.number) AS objectnumber,
       a.name                                                     AS actionname
FROM cmmsmachineparts_plannedeventrealization per
         JOIN qcadoosecurity_user u ON per.worker_id = u.staff_id
         JOIN cmmsmachineparts_plannedevent pe ON pe.id = per.plannedevent_id
         JOIN basic_factory f ON pe.factory_id = f.id
         JOIN basic_division d ON pe.division_id = d.id
         LEFT JOIN productionlines_productionline p ON pe.productionline_id = p.id
         LEFT JOIN basic_workstation w ON pe.workstation_id = w.id
         LEFT JOIN basic_subassembly s ON pe.subassembly_id = s.id
         LEFT JOIN cmmsmachineparts_actionforplannedevent afpe ON per.action_id = afpe.id
         LEFT JOIN cmmsmachineparts_action a ON afpe.action_id = a.id;

alter table cmmsmachineparts_worktimeforuserdto_internal
    owner to postgres;


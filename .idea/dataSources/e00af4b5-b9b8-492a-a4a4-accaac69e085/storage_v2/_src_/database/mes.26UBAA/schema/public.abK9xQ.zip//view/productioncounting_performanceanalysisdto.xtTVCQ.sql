create view productioncounting_performanceanalysisdto
            (id, active, productionline_id, productionlinenumber, staff_id, staffname, timebasedonnormssum,
             labortimesum, timedeviation, performance, shift_id, shiftname, timerangefrom, timerangeto, donequantity,
             productionlinequantity, assortmentquantity, dailyperformance)
as
SELECT row_number() OVER ()                                                     AS id,
       bool_or(performanceanalysisdetaildto.active)                             AS active,
       performanceanalysisdetaildto.productionline_id,
       performanceanalysisdetaildto.productionlinenumber,
       performanceanalysisdetaildto.staff_id,
       performanceanalysisdetaildto.staffname,
       COALESCE(sum(performanceanalysisdetaildto.timebasedonnorms)::integer, 0) AS timebasedonnormssum,
       CASE
           WHEN min(performanceanalysisdetaildto.labortimesum) <> max(performanceanalysisdetaildto.labortimesum) THEN 0
           ELSE min(performanceanalysisdetaildto.labortimesum)::integer
           END                                                                  AS labortimesum,
       CASE
           WHEN min(performanceanalysisdetaildto.labortimesum) <> max(performanceanalysisdetaildto.labortimesum)
               THEN COALESCE(sum(performanceanalysisdetaildto.timebasedonnorms), 0::bigint)::integer
           ELSE (COALESCE(sum(performanceanalysisdetaildto.timebasedonnorms)::integer, 0)::double precision -
                 min(performanceanalysisdetaildto.labortimesum))::integer
           END                                                                  AS timedeviation,
       CASE
           WHEN min(performanceanalysisdetaildto.labortimesum) <> max(performanceanalysisdetaildto.labortimesum) THEN 0::numeric
           ELSE ((100::numeric * sum(performanceanalysisdetaildto.timebasedonnorms)::numeric)::double precision /
                 min(performanceanalysisdetaildto.labortimesum))::numeric(14, 2)
           END                                                                  AS performance,
       performanceanalysisdetaildto.shift_id,
       performanceanalysisdetaildto.shiftname,
       performanceanalysisdetaildto.timerangefromwithouttime                    AS timerangefrom,
       performanceanalysisdetaildto.timerangetowithouttime                      AS timerangeto,
       sum(performanceanalysisdetaildto.donequantity)                           AS donequantity,
       min(helper.productionlinequantity)::integer                              AS productionlinequantity,
       count(DISTINCT performanceanalysisdetaildto.assortment_id)::integer      AS assortmentquantity,
       min(helper.dailyperformance)::numeric(14, 2)                             AS dailyperformance
FROM productioncounting_performanceanalysisdetaildto performanceanalysisdetaildto
         LEFT JOIN productioncounting_performanceanalysisdto_helper helper
                   ON performanceanalysisdetaildto.staff_id = helper.staff_id AND
                      performanceanalysisdetaildto.timerangefromwithouttime = helper.timerangefromwithouttime
GROUP BY performanceanalysisdetaildto.productionline_id, performanceanalysisdetaildto.productionlinenumber,
         performanceanalysisdetaildto.staff_id, performanceanalysisdetaildto.staffname,
         performanceanalysisdetaildto.shift_id, performanceanalysisdetaildto.shiftname,
         performanceanalysisdetaildto.timerangefromwithouttime, performanceanalysisdetaildto.timerangetowithouttime;

alter table productioncounting_performanceanalysisdto
    owner to postgres;


create function mark_as_archived() returns void
    language plpgsql
as
$$
	DECLARE
		arch_table RECORD;
	BEGIN
		FOR arch_table IN SELECT * FROM information_schema.tables AS t
			WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE'
				AND t.table_name LIKE 'arch_%'
			ORDER BY t.table_name
		LOOP
			EXECUTE 'UPDATE '|| arch_table.table_name ||' SET archived = true WHERE archived = false';
		END LOOP;
	END;
$$;

alter function mark_as_archived() owner to postgres;


create view linechangeovernorms_groupsview
            (number, name, duration, changeovertype, productionlineid, technologygroupfromid, technologygrouptoid,
             technologyfromid, technologytoid, technologyfromnumber, technologytonumber)
as
SELECT norms.number,
       norms.name,
       norms.duration,
       '02forTechnologyGroup'::text AS changeovertype,
       norms.productionline_id      AS productionlineid,
       technologygroupfrom.id       AS technologygroupfromid,
       technologygroupto.id         AS technologygrouptoid,
       technologyfrom.id            AS technologyfromid,
       technologyto.id              AS technologytoid,
       technologyfrom.number        AS technologyfromnumber,
       technologyto.number          AS technologytonumber
FROM linechangeovernorms_linechangeovernorms norms
         LEFT JOIN technologies_technologygroup technologygroupfrom
                   ON technologygroupfrom.id = norms.fromtechnologygroup_id
         LEFT JOIN technologies_technology technologyfrom
                   ON technologyfrom.technologygroup_id = technologygroupfrom.id AND technologyfrom.active = true AND
                      technologyfrom.technologyprototype_id IS NULL
         LEFT JOIN technologies_technologygroup technologygroupto ON technologygroupto.id = norms.totechnologygroup_id
         LEFT JOIN technologies_technology technologyto
                   ON technologyto.technologygroup_id = technologygroupto.id AND technologyto.active = true AND
                      technologyto.technologyprototype_id IS NULL
WHERE norms.changeovertype::text = '02forTechnologyGroup'::text;

alter table linechangeovernorms_groupsview
    owner to postgres;


create view goodfood_printedlabeldto
            (id, printdate, palletcontextoperatorname, palletcontextoperatorsurname, productionlinenumber,
             masterordernumber, productnumber, ssccnumber, active)
as
SELECT printedlabel.id,
       date(printedlabel.createdate) AS printdate,
       staff.name                    AS palletcontextoperatorname,
       staff.surname                 AS palletcontextoperatorsurname,
       productionline.number         AS productionlinenumber,
       masterorder.number            AS masterordernumber,
       product.number                AS productnumber,
       printedlabel.ssccnumber,
       printedlabel.active
FROM goodfood_printedlabel printedlabel
         JOIN goodfood_palletcontext palletcontext ON palletcontext.id = printedlabel.palletcontext_id
         JOIN basic_staff staff ON staff.id = palletcontext.operator_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = printedlabel.productionline_id
         JOIN masterorders_masterorder masterorder ON masterorder.id = printedlabel.masterorder_id
         JOIN masterorders_masterorderproduct masterorderproduct ON masterorderproduct.masterorder_id = masterorder.id
         JOIN basic_product product ON product.id = masterorderproduct.product_id;

alter table goodfood_printedlabeldto
    owner to postgres;


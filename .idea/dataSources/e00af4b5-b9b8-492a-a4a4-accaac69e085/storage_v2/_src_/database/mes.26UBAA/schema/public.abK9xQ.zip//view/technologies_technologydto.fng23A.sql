create view technologies_technologydto
            (id, name, number, externalsynchronized, master, state, productnumber, productglobaltypeofmaterial,
             technologygroupnumber, divisionname, productname, technologytype, active, standardperformancetechnology,
             generatorname, attachmentsexists, dateandtime, productionlinenumber, assortmentname)
as
SELECT technology.id,
       technology.name,
       technology.number,
       technology.externalsynchronized,
       technology.master,
       technology.state,
       product.number                      AS productnumber,
       product.globaltypeofmaterial        AS productglobaltypeofmaterial,
       tg.number                           AS technologygroupnumber,
       division.name                       AS divisionname,
       product.name                        AS productname,
       technology.technologytype,
       technology.active,
       technology.standardperformancetechnology,
       tcontext.number                     AS generatorname,
       count(technologyattachment.id) <> 0 AS attachmentsexists,
       technologystatechange.dateandtime,
       productionline.number               AS productionlinenumber,
       assortment.name                     AS assortmentname
FROM technologies_technology technology
         LEFT JOIN basic_product product ON technology.product_id = product.id
         LEFT JOIN basic_assortment assortment ON assortment.id = product.assortment_id
         LEFT JOIN basic_division division ON technology.division_id = division.id
         LEFT JOIN technologies_technologygroup tg ON technology.technologygroup_id = tg.id
         LEFT JOIN technologies_technologyattachment technologyattachment
                   ON technologyattachment.technology_id = technology.id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext ON tcontext.id = technology.generatorcontext_id
         LEFT JOIN technologies_technologystatechange technologystatechange
                   ON technologystatechange.technology_id = technology.id AND
                      technologystatechange.status::text = '03successful'::text AND
                      technologystatechange.sourcestate IS NULL AND technologystatechange.targetstate::text = '01draft'::text
         LEFT JOIN productionlines_productionline productionline ON productionline.id = technology.productionline_id
GROUP BY technology.id, product.number, product.globaltypeofmaterial, tg.number, division.name, product.name,
         tcontext.number, technologystatechange.dateandtime, productionline.number, assortment.name;

alter table technologies_technologydto
    owner to postgres;


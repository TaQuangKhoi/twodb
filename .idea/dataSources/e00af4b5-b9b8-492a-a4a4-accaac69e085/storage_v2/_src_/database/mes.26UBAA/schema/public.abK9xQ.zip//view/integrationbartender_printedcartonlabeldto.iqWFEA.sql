create view integrationbartender_printedcartonlabeldto
            (id, createdate, createuser, masterorder_id, masterordernumber, quantity, printer_id, printername) as
SELECT printlabelshelper.id,
       printlabelshelper.createdate,
       printlabelshelper.createuser,
       printlabelshelper.masterorder_id::integer AS masterorder_id,
       masterorder.number                        AS masterordernumber,
       printlabelshelper.quantity,
       printlabelshelper.printer_id::integer     AS printer_id,
       printer.name                              AS printername
FROM integrationbartender_sendtoprint sendtoprint
         JOIN integrationbartender_printlabelshelper printlabelshelper
              ON printlabelshelper.id = sendtoprint.printlabelshelper_id
         JOIN masterorders_masterorder masterorder ON masterorder.id = printlabelshelper.masterorder_id
         JOIN integrationbartender_printer printer ON printer.id = printlabelshelper.printer_id
WHERE NOT (printlabelshelper.id IN (SELECT jointable_label_printlabelshelper.printlabelshelper_id
                                    FROM jointable_label_printlabelshelper
                                    UNION
                                    SELECT jointable_printlabelshelper_printedlabel.printlabelshelper_id
                                    FROM jointable_printlabelshelper_printedlabel
                                    UNION
                                    SELECT jointable_order_printlabelshelper.printlabelshelper_id
                                    FROM jointable_order_printlabelshelper));

alter table integrationbartender_printedcartonlabeldto
    owner to postgres;


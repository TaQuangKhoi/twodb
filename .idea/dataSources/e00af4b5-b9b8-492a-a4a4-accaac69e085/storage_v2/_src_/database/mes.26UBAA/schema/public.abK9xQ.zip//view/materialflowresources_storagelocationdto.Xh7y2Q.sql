create view materialflowresources_storagelocationdto
            (id, locationnumber, storagelocationnumber, productnumber, productname, additionalcode, resourcequantity,
             productunit, quantityinadditionalunit, productadditionalunit, location_id)
as
SELECT row_number() OVER () AS id,
       internal.locationnumber,
       internal.storagelocationnumber,
       internal.productnumber,
       internal.productname,
       internal.additionalcode,
       internal.resourcequantity,
       internal.productunit,
       internal.quantityinadditionalunit,
       internal.productadditionalunit,
       internal.location_id
FROM materialflowresources_storagelocationdto_internal internal;

alter table materialflowresources_storagelocationdto
    owner to postgres;


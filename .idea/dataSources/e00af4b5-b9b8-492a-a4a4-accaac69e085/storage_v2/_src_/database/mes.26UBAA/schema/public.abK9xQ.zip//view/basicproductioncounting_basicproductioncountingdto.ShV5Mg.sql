create view basicproductioncounting_basicproductioncountingdto
            (id, orderid, productnumber, productname, productunit, plannedquantity, usedquantity, producedquantity) as
SELECT bpc.id,
       bpc.order_id::integer AS orderid,
       product.number        AS productnumber,
       product.name          AS productname,
       product.unit          AS productunit,
       o.plannedquantity,
       bpc.usedquantity,
       bpc.producedquantity
FROM basicproductioncounting_basicproductioncounting bpc
         JOIN basic_product product ON product.id = bpc.product_id
         JOIN orders_order o ON o.id = bpc.order_id
WHERE bpc.product_id = o.product_id
UNION
SELECT bpc.id,
       bpc.order_id::integer                          AS orderid,
       product.number                                 AS productnumber,
       product.name                                   AS productname,
       product.unit                                   AS productunit,
       COALESCE(sum(pcq.plannedquantity), 0::numeric) AS plannedquantity,
       bpc.usedquantity,
       bpc.producedquantity
FROM basicproductioncounting_basicproductioncounting bpc
         JOIN basic_product product ON product.id = bpc.product_id
         JOIN orders_order o ON o.id = bpc.order_id
         LEFT JOIN basicproductioncounting_productioncountingquantity pcq
                   ON pcq.order_id = bpc.order_id AND pcq.product_id = bpc.product_id AND pcq.role::text = '01used'::text
WHERE bpc.product_id <> o.product_id
GROUP BY bpc.id, bpc.order_id, product.number, product.name, product.unit, bpc.usedquantity, bpc.producedquantity;

alter table basicproductioncounting_basicproductioncountingdto
    owner to postgres;


create function list_tables()
    returns TABLE(table_name text, count bigint)
    language plpgsql
as
$$
	DECLARE
		table_data RECORD;

	BEGIN
		FOR table_data IN SELECT * FROM information_schema.tables AS t
			WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE'
				AND t.table_name NOT IN ('logdigger_errorlog')
				AND t.table_name NOT LIKE 'jointable%'

			ORDER BY t.table_name
		LOOP

			RETURN QUERY EXECUTE 'SELECT
				cast(' || quote_literal(table_data.table_name) || ' AS text), count(*)
			FROM ' || table_data.table_name;

		END LOOP;
	END;
$$;

alter function list_tables() owner to postgres;


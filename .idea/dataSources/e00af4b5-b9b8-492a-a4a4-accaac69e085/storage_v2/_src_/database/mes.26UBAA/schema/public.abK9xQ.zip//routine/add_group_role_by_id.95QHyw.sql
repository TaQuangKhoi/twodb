create function add_group_role_by_id(groupid bigint, role_name character varying) returns void
    language plpgsql
as
$$
   DECLARE
    roleid bigint;
    relationcount bigint;
   BEGIN
    IF groupid is null THEN
        RAISE EXCEPTION 'Group(%s) not found', groupid;
    END IF;

    SELECT id INTO roleid FROM qcadoosecurity_role WHERE identifier = role_name;
    IF roleid is null THEN
        RAISE EXCEPTION 'Role(%) not found', role_name;
    END IF;

    SELECT count(*) INTO relationcount FROM jointable_group_role WHERE group_id = groupid and role_id = roleid;
    IF relationcount = 0 THEN
        INSERT INTO jointable_group_role (group_id, role_id) VALUES (groupid, roleid);
    END IF;

   END;
   $$;

alter function add_group_role_by_id(bigint, varchar) owner to postgres;


create view materialflowresources_resourcestockdto
            (id, location_id, product_id, orderedquantity, minimumstate, quantity, quantityinadditionalunit,
             reservedquantity, availablequantity, locationnumber, locationname, productnumber, productname, productunit,
             totalvalue, familynumber)
as
WITH minimum_states AS (SELECT warehouseminimalstate_warehouseminimumstate.product_id,
                               warehouseminimalstate_warehouseminimumstate.location_id,
                               sum(warehouseminimalstate_warehouseminimumstate.minimumstate) AS quantity
                        FROM warehouseminimalstate_warehouseminimumstate
                        GROUP BY warehouseminimalstate_warehouseminimumstate.product_id,
                                 warehouseminimalstate_warehouseminimumstate.location_id),
     quantities AS (SELECT materialflowresources_resource.product_id,
                           materialflowresources_resource.location_id,
                           sum(materialflowresources_resource.quantity)                                        AS quantity,
                           sum(materialflowresources_resource.quantityinadditionalunit)                        AS quantityinadditionalunit,
                           sum(materialflowresources_resource.quantity *
                               materialflowresources_resource.price)                                           AS totalvalue
                    FROM materialflowresources_resource
                    GROUP BY materialflowresources_resource.product_id, materialflowresources_resource.location_id),
     reserved_quantities AS (SELECT materialflowresources_reservation.product_id,
                                    materialflowresources_reservation.location_id,
                                    sum(materialflowresources_reservation.quantity) AS quantity
                             FROM materialflowresources_reservation
                             GROUP BY materialflowresources_reservation.product_id,
                                      materialflowresources_reservation.location_id),
     ordered_quantities AS (SELECT dop.product_id,
                                   dd.location_id,
                                   sum(dop.orderedquantity) AS quantity
                            FROM deliveries_orderedproduct dop
                                     JOIN deliveries_delivery dd ON dop.delivery_id = dd.id
                            WHERE dd.active = true
                              AND (dd.state::text = ANY
                                   (ARRAY ['01draft'::character varying::text, '02prepared'::character varying::text, '03duringCorrection'::character varying::text, '05approved'::character varying::text]))
                            GROUP BY dop.product_id, dd.location_id)
SELECT rs.id,
       rs.location_id::integer                                              AS location_id,
       rs.product_id::integer                                               AS product_id,
       COALESCE(oq.quantity, 0::numeric)                                    AS orderedquantity,
       COALESCE(ms.quantity, 0::numeric)                                    AS minimumstate,
       COALESCE(q.quantity, 0::numeric)                                     AS quantity,
       COALESCE(q.quantityinadditionalunit, 0::numeric)                     AS quantityinadditionalunit,
       COALESCE(rq.quantity, 0::numeric)                                    AS reservedquantity,
       COALESCE(q.quantity, 0::numeric) - COALESCE(rq.quantity, 0::numeric) AS availablequantity,
       location.number                                                      AS locationnumber,
       location.name                                                        AS locationname,
       product.number                                                       AS productnumber,
       product.name                                                         AS productname,
       product.unit                                                         AS productunit,
       COALESCE(q.totalvalue, 0::numeric)                                   AS totalvalue,
       family.number                                                        AS familynumber
FROM materialflowresources_resourcestock rs
         LEFT JOIN ordered_quantities oq ON oq.product_id = rs.product_id AND oq.location_id = rs.location_id
         LEFT JOIN minimum_states ms ON ms.product_id = rs.product_id AND ms.location_id = rs.location_id
         LEFT JOIN quantities q ON q.product_id = rs.product_id AND q.location_id = rs.location_id
         LEFT JOIN reserved_quantities rq ON rq.product_id = rs.product_id AND rq.location_id = rs.location_id
         JOIN materialflow_location location ON location.id = rs.location_id
         JOIN basic_product product ON product.id = rs.product_id
         LEFT JOIN basic_product family ON product.parent_id = family.id;

alter table materialflowresources_resourcestockdto
    owner to postgres;


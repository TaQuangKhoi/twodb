create view productioncounting_productiontrackingforproductgroupeddto
            (id, active, order_id, ordernumber, technologyoperationcomponent_id, technologyoperationcomponentnumber,
             operation_id, product_id, productnumber, productunit, plannedquantity, usedquantity, typeofrecord)
as
SELECT row_number() OVER ()                              AS id,
       productiontrackingforproductdto.active,
       productiontrackingforproductdto.order_id,
       productiontrackingforproductdto.ordernumber,
       productiontrackingforproductdto.technologyoperationcomponent_id,
       productiontrackingforproductdto.technologyoperationcomponentnumber,
       productiontrackingforproductdto.operation_id,
       productiontrackingforproductdto.product_id,
       productiontrackingforproductdto.productnumber,
       productiontrackingforproductdto.productunit,
       productiontrackingforproductdto.plannedquantity,
       sum(productiontrackingforproductdto.usedquantity) AS usedquantity,
       productiontrackingforproductdto.typeofrecord
FROM productioncounting_productiontrackingforproductdto productiontrackingforproductdto
GROUP BY productiontrackingforproductdto.active, productiontrackingforproductdto.order_id,
         productiontrackingforproductdto.ordernumber, productiontrackingforproductdto.technologyoperationcomponent_id,
         productiontrackingforproductdto.technologyoperationcomponentnumber,
         productiontrackingforproductdto.operation_id, productiontrackingforproductdto.product_id,
         productiontrackingforproductdto.productnumber, productiontrackingforproductdto.productunit,
         productiontrackingforproductdto.plannedquantity, productiontrackingforproductdto.typeofrecord;

alter table productioncounting_productiontrackingforproductgroupeddto
    owner to postgres;


create view cmmsmachineparts_worktimeforuserdto
            (id, username, startdate, finishdate, duration, eventnumber, eventtype, objectnumber, actionname) as
SELECT row_number() OVER () AS id,
       internal.username,
       internal.startdate,
       internal.finishdate,
       internal.duration,
       internal.eventnumber,
       internal.eventtype,
       internal.objectnumber,
       internal.actionname
FROM cmmsmachineparts_worktimeforuserdto_internal internal;

alter table cmmsmachineparts_worktimeforuserdto
    owner to postgres;


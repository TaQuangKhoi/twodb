create view productioncounting_productiontrackingdraftdto
            (id, number, state, createdate, lasttracking, timerangefrom, timerangeto, active, order_id, ordernumber,
             orderstate, technologyoperationcomponent_id, technologyoperationcomponentnumber, operation_id, shift_id,
             shiftname, staff_id, staffname, division_id, divisionnumber, subcontractor_id, subcontractorname,
             repairorder_id, repairordernumber, correctionnumber, productionline_id, productionlinenumber, ordersgroup,
             productnumber, productunit, usedquantity, companynumber, outproductnumber)
as
SELECT productiontracking.id,
       productiontracking.number,
       productiontracking.state,
       productiontracking.createdate,
       productiontracking.lasttracking,
       productiontracking.timerangefrom,
       productiontracking.timerangeto,
       productiontracking.active,
       ordersorder.id::integer                                                                                  AS order_id,
       ordersorder.number                                                                                       AS ordernumber,
       ordersorder.state                                                                                        AS orderstate,
       technologyoperationcomponent.id::integer                                                                 AS technologyoperationcomponent_id,
       COALESCE((technologyoperationcomponent.nodenumber::text || ' '::text) || operation.name::text,
                ''::text)                                                                                       AS technologyoperationcomponentnumber,
       operation.id::integer                                                                                    AS operation_id,
       shift.id::integer                                                                                        AS shift_id,
       shift.name                                                                                               AS shiftname,
       staff.id::integer                                                                                        AS staff_id,
       (staff.surname::text || ' '::text) || staff.name::text                                                   AS staffname,
       division.id::integer                                                                                     AS division_id,
       division.number                                                                                          AS divisionnumber,
       subcontractor.id::integer                                                                                AS subcontractor_id,
       subcontractor.name                                                                                       AS subcontractorname,
       repairorder.id::integer                                                                                  AS repairorder_id,
       repairorder.number                                                                                       AS repairordernumber,
       productiontrackingcorrection.number                                                                      AS correctionnumber,
       productionline.id::integer                                                                               AS productionline_id,
       productionline.number                                                                                    AS productionlinenumber,
       ordersgroup.number                                                                                       AS ordersgroup,
       concat(product.number, ' - ', product.name)                                                              AS productnumber,
       product.unit                                                                                             AS productunit,
       outcomponent.usedquantity,
       company.number                                                                                           AS companynumber,
       COALESCE((outproduct.number::text || ' - '::text) || outproduct.name::text,
                (product.number::text || ' - '::text) ||
                product.name::text)                                                                             AS outproductnumber
FROM productioncounting_productiontracking productiontracking
         JOIN orders_order ordersorder ON ordersorder.id = productiontracking.order_id
         JOIN basic_product product ON ordersorder.product_id = product.id
         JOIN productionlines_productionline productionline ON productionline.id = ordersorder.productionline_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = productiontracking.technologyoperationcomponent_id
         LEFT JOIN technologies_operation operation ON operation.id = technologyoperationcomponent.operation_id
         LEFT JOIN basic_shift shift ON shift.id = productiontracking.shift_id
         LEFT JOIN basic_staff staff ON staff.id = productiontracking.staff_id
         LEFT JOIN basic_division division ON division.id = productiontracking.division_id
         LEFT JOIN basic_company subcontractor ON subcontractor.id = productiontracking.subcontractor_id
         LEFT JOIN productioncounting_productiontracking productiontrackingcorrection
                   ON productiontrackingcorrection.id = productiontracking.correction_id
         LEFT JOIN repairs_repairorder repairorder ON repairorder.id = productiontracking.repairorder_id
         LEFT JOIN ordersgroups_ordersgroup ordersgroup ON ordersgroup.id = ordersorder.ordersgroup_id
         LEFT JOIN basic_company company ON company.id = ordersorder.company_id
         LEFT JOIN basicproductioncounting_productioncountingquantity pcq ON pcq.order_id = ordersorder.id AND
                                                                             pcq.technologyoperationcomponent_id =
                                                                             technologyoperationcomponent.id AND
                                                                             (pcq.typeofmaterial::text = ANY
                                                                              (ARRAY ['02intermediate'::character varying::text, '03finalProduct'::character varying::text])) AND
                                                                             pcq.role::text = '02produced'::text
         LEFT JOIN basic_product outproduct ON pcq.product_id = outproduct.id
         LEFT JOIN productioncounting_trackingoperationproductoutcomponent outcomponent
                   ON (outcomponent.product_id = outproduct.id OR outcomponent.product_id = product.id) AND
                      productiontracking.id = outcomponent.productiontracking_id
WHERE productiontracking.state::text = '01draft'::text;

alter table productioncounting_productiontrackingdraftdto
    owner to postgres;


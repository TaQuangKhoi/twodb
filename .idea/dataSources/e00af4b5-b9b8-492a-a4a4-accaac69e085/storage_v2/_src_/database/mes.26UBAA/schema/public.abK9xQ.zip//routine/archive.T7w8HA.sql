create function archive(_rows integer) returns void
    language plpgsql
as
$$
	BEGIN
		RAISE NOTICE 'Start - archive';
		EXECUTE 'SELECT archive_data('||_rows||');';
		EXECUTE 'SELECT remove_archived_data();';
		EXECUTE 'SELECT mark_as_archived();';
		RAISE NOTICE 'End - archive';

	END;
$$;

alter function archive(integer) owner to postgres;


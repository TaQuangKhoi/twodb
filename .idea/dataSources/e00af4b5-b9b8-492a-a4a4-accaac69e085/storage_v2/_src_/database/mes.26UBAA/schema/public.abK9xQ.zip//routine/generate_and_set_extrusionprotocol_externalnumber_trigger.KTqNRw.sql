create function generate_and_set_extrusionprotocol_externalnumber_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
	NEW.externalnumber := generate_extrusionprotocol_externalnumber();

	return NEW;
END;
$$;

alter function generate_and_set_extrusionprotocol_externalnumber_trigger() owner to postgres;


create view productioncounting_trackingoperationproductcomponentdto
            (id, productiontracking_id, product_id, productnumber, productunit, plannedquantity, usedquantity,
             batchnumber, typeofrecord)
as
SELECT row_number() OVER () AS id,
       trackingoperationproductcomponentdto.productiontracking_id,
       trackingoperationproductcomponentdto.product_id,
       trackingoperationproductcomponentdto.productnumber,
       trackingoperationproductcomponentdto.productunit,
       trackingoperationproductcomponentdto.plannedquantity,
       trackingoperationproductcomponentdto.usedquantity,
       trackingoperationproductcomponentdto.batchnumber,
       trackingoperationproductcomponentdto.typeofrecord
FROM (SELECT trackingoperationproductincomponentdto.productiontracking_id,
             trackingoperationproductincomponentdto.product_id,
             trackingoperationproductincomponentdto.productnumber,
             trackingoperationproductincomponentdto.productunit,
             trackingoperationproductincomponentdto.plannedquantity,
             trackingoperationproductincomponentdto.usedquantity,
             trackingoperationproductincomponentdto.batchnumber,
             '01in'::text AS typeofrecord
      FROM productioncounting_trackingoperationproductincomponenthelper trackingoperationproductincomponentdto
      UNION
      SELECT trackingoperationproductoutcomponentdto.productiontracking_id,
             trackingoperationproductoutcomponentdto.product_id,
             trackingoperationproductoutcomponentdto.productnumber,
             trackingoperationproductoutcomponentdto.productunit,
             trackingoperationproductoutcomponentdto.plannedquantity,
             trackingoperationproductoutcomponentdto.usedquantity,
             trackingoperationproductoutcomponentdto.batchnumber,
             '02out'::text AS typeofrecord
      FROM productioncounting_trackingoperationproductoutcomponenthelper trackingoperationproductoutcomponentdto) trackingoperationproductcomponentdto;

alter table productioncounting_trackingoperationproductcomponentdto
    owner to postgres;


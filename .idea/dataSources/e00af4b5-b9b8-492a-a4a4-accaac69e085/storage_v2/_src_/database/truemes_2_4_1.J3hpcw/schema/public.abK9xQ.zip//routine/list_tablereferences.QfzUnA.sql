create function list_tablereferences(foreign_table_name text)
    returns TABLE(table_name text, column_name text)
    language plpgsql
as
$$
	BEGIN
		RETURN QUERY EXECUTE 'SELECT
			cast(tc.table_name AS text),
			cast(kcu.column_name AS text)
		FROM information_schema.table_constraints AS tc
		JOIN information_schema.key_column_usage AS kcu
			ON kcu.table_name = tc.table_name
			AND kcu.constraint_name = tc.constraint_name
		JOIN information_schema.constraint_column_usage AS ccu
			ON ccu.constraint_name = tc.constraint_name
		WHERE
			tc.table_schema = ' || quote_literal('public') || ' AND tc.constraint_type = ' || quote_literal('FOREIGN KEY') ||
			' AND tc.table_name NOT LIKE ' || quote_literal('jointable%') ||
			' AND ccu.table_name = ' || quote_literal(foreign_table_name) ||
		' GROUP BY tc.table_name, kcu.column_name';
	END;
$$;

alter function list_tablereferences(text) owner to postgres;


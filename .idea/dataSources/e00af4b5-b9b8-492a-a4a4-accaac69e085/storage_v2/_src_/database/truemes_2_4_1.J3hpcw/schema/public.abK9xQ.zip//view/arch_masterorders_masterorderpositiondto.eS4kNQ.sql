create view arch_masterorders_masterorderpositiondto
            (id, masterorderdefinitionnumber, masterorderid, productid, masterorderproductid, name, number, deadline,
             masterorderstatus, masterorderpositionstatus, masterorderquantity, cumulatedmasterorderquantity,
             producedorderquantity, lefttorelease, comments, productnumber, productname, unit, technologyname,
             companyname, active, companypayer, assortmentname, state, description)
as
SELECT arch_mv_masterorders_masterorderpositiondto.id,
       arch_mv_masterorders_masterorderpositiondto.masterorderdefinitionnumber,
       arch_mv_masterorders_masterorderpositiondto.masterorderid,
       arch_mv_masterorders_masterorderpositiondto.productid,
       arch_mv_masterorders_masterorderpositiondto.masterorderproductid,
       arch_mv_masterorders_masterorderpositiondto.name,
       arch_mv_masterorders_masterorderpositiondto.number,
       arch_mv_masterorders_masterorderpositiondto.deadline,
       arch_mv_masterorders_masterorderpositiondto.masterorderstatus,
       arch_mv_masterorders_masterorderpositiondto.masterorderpositionstatus,
       arch_mv_masterorders_masterorderpositiondto.masterorderquantity,
       arch_mv_masterorders_masterorderpositiondto.cumulatedmasterorderquantity,
       arch_mv_masterorders_masterorderpositiondto.producedorderquantity,
       arch_mv_masterorders_masterorderpositiondto.lefttorelease,
       arch_mv_masterorders_masterorderpositiondto.comments,
       arch_mv_masterorders_masterorderpositiondto.productnumber,
       arch_mv_masterorders_masterorderpositiondto.productname,
       arch_mv_masterorders_masterorderpositiondto.unit,
       arch_mv_masterorders_masterorderpositiondto.technologyname,
       arch_mv_masterorders_masterorderpositiondto.companyname,
       arch_mv_masterorders_masterorderpositiondto.active,
       arch_mv_masterorders_masterorderpositiondto.companypayer,
       arch_mv_masterorders_masterorderpositiondto.assortmentname,
       arch_mv_masterorders_masterorderpositiondto.state,
       arch_mv_masterorders_masterorderpositiondto.description
FROM arch_mv_masterorders_masterorderpositiondto;

alter table arch_masterorders_masterorderpositiondto
    owner to postgres;


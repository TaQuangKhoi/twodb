create view ordersupplies_productioncountingquantityinput
            (id, orderid, startdate, orderstate, productid, operationid, technologyoperationcomponentid,
             plannedquantity, usedquantity, quantity, eventtype, producttype, orderproductid)
as
SELECT pcq.id,
       o.id::integer                                                                                            AS orderid,
       o.startdate,
       o.state                                                                                                  AS orderstate,
       product.id::integer                                                                                      AS productid,
       toc.operation_id::integer                                                                                AS operationid,
       pcq.technologyoperationcomponent_id::integer                                                             AS technologyoperationcomponentid,
       pcq.plannedquantity,
       COALESCE(pcq.usedquantity, 0::numeric)                                                                   AS usedquantity,
       GREATEST(pcq.plannedquantity - COALESCE(pcq.usedquantity, 0::numeric),
                0::numeric)                                                                                     AS quantity,
       '04orderInput'::text                                                                                     AS eventtype,
       COALESCE(coverageproducttype.producttype::character varying(255),
                '01component'::character varying(255))                                                          AS producttype,
       o.product_id::integer                                                                                    AS orderproductid
FROM basicproductioncounting_productioncountingquantity pcq
         JOIN orders_order o ON o.id = pcq.order_id
         JOIN basic_product product ON product.id = pcq.product_id
         LEFT JOIN technologies_technologyoperationcomponent toc ON pcq.technologyoperationcomponent_id = toc.id
         LEFT JOIN ordersupplies_coverageproducttypedto coverageproducttype
                   ON coverageproducttype.productid = pcq.product_id
WHERE pcq.role::text = '01used'::text
  AND (pcq.typeofmaterial::text = ANY (ARRAY ['01component'::character varying::text]))
  AND (o.state::text = ANY
       (ARRAY ['01pending'::character varying::text, '02accepted'::character varying::text, '03inProgress'::character varying::text, '06interrupted'::character varying::text]))
  AND o.active = true
  AND o.typeofproductionrecording::text = '02cumulated'::text
UNION
SELECT pcq.id,
       o.id::integer                                                                                            AS orderid,
       o.startdate,
       o.state                                                                                                  AS orderstate,
       product.id::integer                                                                                      AS productid,
       toc.operation_id::integer                                                                                AS operationid,
       pcq.technologyoperationcomponent_id::integer                                                             AS technologyoperationcomponentid,
       pcq.plannedquantity,
       COALESCE(pcq.usedquantity, 0::numeric)                                                                   AS usedquantity,
       GREATEST(pcq.plannedquantity - COALESCE(pcq.usedquantity, 0::numeric),
                0::numeric)                                                                                     AS quantity,
       '03operationInput'::text                                                                                 AS eventtype,
       COALESCE(coverageproducttype.producttype::character varying(255),
                '01component'::character varying(255))                                                          AS producttype,
       o.product_id::integer                                                                                    AS orderproductid
FROM basicproductioncounting_productioncountingquantity pcq
         JOIN orders_order o ON o.id = pcq.order_id
         JOIN basic_product product ON product.id = pcq.product_id
         JOIN technologies_technologyoperationcomponent toc ON pcq.technologyoperationcomponent_id = toc.id
         LEFT JOIN ordersupplies_coverageproducttypedto coverageproducttype
                   ON coverageproducttype.productid = pcq.product_id
WHERE pcq.role::text = '01used'::text
  AND (pcq.typeofmaterial::text = ANY (ARRAY ['01component'::character varying::text]))
  AND (o.state::text = ANY
       (ARRAY ['01pending'::character varying::text, '02accepted'::character varying::text, '03inProgress'::character varying::text, '06interrupted'::character varying::text]))
  AND o.active = true
  AND o.typeofproductionrecording::text = '03forEach'::text;

alter table ordersupplies_productioncountingquantityinput
    owner to postgres;


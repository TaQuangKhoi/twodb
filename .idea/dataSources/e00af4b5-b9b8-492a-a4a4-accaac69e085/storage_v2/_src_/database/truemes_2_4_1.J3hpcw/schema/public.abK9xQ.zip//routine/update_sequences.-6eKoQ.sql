create function update_sequences() returns void
    language plpgsql
as
$$
DECLARE
    row record;
BEGIN
    FOR row IN SELECT tablename FROM pg_tables p
                INNER JOIN information_schema.columns c ON p.tablename = c.table_name
                WHERE c.table_schema = 'public' AND p.schemaname = 'public' AND c.column_name = 'id' AND data_type = 'bigint'
    LOOP
        IF EXISTS (SELECT 0 FROM pg_class WHERE relname = '' || quote_ident(row.tablename) || '_id_seq' ) THEN
            EXECUTE 'ALTER TABLE ' || quote_ident(row.tablename) || ' ALTER COLUMN id SET DEFAULT nextval(''' || quote_ident(row.tablename) || '_id_seq'');';
            EXECUTE 'SELECT setval(''' || quote_ident(row.tablename) || '_id_seq'', COALESCE((SELECT MAX(id)+1 FROM ' || quote_ident(row.tablename) || '), 1), false);';
        END IF;
    END LOOP;
END;
$$;

alter function update_sequences() owner to postgres;


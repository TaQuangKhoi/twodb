create function generate_and_set_assignmenttoshift_externalnumber_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
	NEW.externalnumber := generate_assignmenttoshift_externalnumber();

	return NEW;
END;
$$;

alter function generate_and_set_assignmenttoshift_externalnumber_trigger() owner to postgres;


create view deliveries_orderedproductdto
            (id, succession, orderedquantity, priceperunit, totalprice, conversion, additionalquantity, description,
             actualversion, delivery, deliveryid, supplier, deliverydate, deliverystate, deliverynumber, deliveryname,
             deliveryactive, deliverycurrency, suppliername, productnumber, productname, productnorm, productunit,
             additionalcode, mergedproductnumberandadditionalcode, offernumber, negotiationnumber, operationnumber,
             productcatalognumber, deliveredquantity, additionaldeliveredquantity, lefttoreceivequantity,
             additionallefttoreceivequantity, hasattachments, batchnumber, qualitycardnumber, parentproductnumber,
             minimumorderquantity, minimumfamilyorderquantity, minorderquantity, belowminorderquantity)
as
WITH product_attachments AS (SELECT product_1.id              AS productid,
                                    count(attachment.id) <> 0 AS hasattachments
                             FROM basic_product product_1
                                      LEFT JOIN basic_productattachment attachment
                                                ON attachment.product_id = product_1.id
                             GROUP BY product_1.id)
SELECT orderedproduct.id,
       orderedproduct.succession,
       orderedproduct.orderedquantity,
       orderedproduct.priceperunit,
       orderedproduct.totalprice,
       orderedproduct.conversion,
       orderedproduct.additionalquantity,
       orderedproduct.description,
       orderedproduct.actualversion,
       delivery.id                                                                           AS delivery,
       delivery.id::integer                                                                  AS deliveryid,
       delivery.supplier_id                                                                  AS supplier,
       delivery.deliverydate,
       delivery.state                                                                        AS deliverystate,
       delivery.number                                                                       AS deliverynumber,
       delivery.name                                                                         AS deliveryname,
       delivery.active                                                                       AS deliveryactive,
       currency.alphabeticcode                                                               AS deliverycurrency,
       supplier.name                                                                         AS suppliername,
       product.number                                                                        AS productnumber,
       product.name                                                                          AS productname,
       product.norm                                                                          AS productnorm,
       product.unit                                                                          AS productunit,
       additionalcode.code                                                                   AS additionalcode,
       product.number::text ||
       CASE
           WHEN additionalcode.code IS NULL THEN ''::text
           ELSE ' - '::text || additionalcode.code::text
           END                                                                               AS mergedproductnumberandadditionalcode,
       offer.number                                                                          AS offernumber,
       negotiation.number                                                                    AS negotiationnumber,
       operation.number                                                                      AS operationnumber,
       (SELECT productcatalognumbers_productcatalognumbers.catalognumber
        FROM productcatalognumbers_productcatalognumbers
        WHERE productcatalognumbers_productcatalognumbers.product_id = product.id
          AND productcatalognumbers_productcatalognumbers.company_id = delivery.supplier_id) AS productcatalognumber,
       COALESCE(orderedproduct.deliveredquantity, 0::numeric)                                AS deliveredquantity,
       COALESCE(orderedproduct.additionaldeliveredquantity, 0::numeric)                      AS additionaldeliveredquantity,
       CASE
           WHEN (orderedproduct.orderedquantity - COALESCE(orderedproduct.deliveredquantity, 0::numeric)) > 0::numeric
               THEN orderedproduct.orderedquantity - COALESCE(orderedproduct.deliveredquantity, 0::numeric)
           ELSE 0::numeric
           END                                                                               AS lefttoreceivequantity,
       CASE
           WHEN (orderedproduct.additionalquantity - COALESCE(orderedproduct.additionaldeliveredquantity, 0::numeric)) >
                0::numeric THEN orderedproduct.additionalquantity -
                                COALESCE(orderedproduct.additionaldeliveredquantity, 0::numeric)
           ELSE 0::numeric
           END                                                                               AS additionallefttoreceivequantity,
       attachments.hasattachments,
       batch.number                                                                          AS batchnumber,
       qualitycard.number                                                                    AS qualitycardnumber,
       parentproduct.number                                                                  AS parentproductnumber,
       companyproduct.minimumorderquantity,
       companyproductsfamily.minimumorderquantity                                            AS minimumfamilyorderquantity,
       CASE
           WHEN companyproduct.minimumorderquantity IS NOT NULL THEN companyproduct.minimumorderquantity
           ELSE companyproductsfamily.minimumorderquantity
           END                                                                               AS minorderquantity,
       CASE
           WHEN companyproduct.minimumorderquantity IS NULL AND companyproductsfamily.minimumorderquantity IS NULL
               THEN false
           WHEN companyproduct.minimumorderquantity IS NOT NULL AND
                companyproduct.minimumorderquantity <= orderedproduct.orderedquantity THEN false
           WHEN companyproductsfamily.minimumorderquantity IS NOT NULL AND
                companyproductsfamily.minimumorderquantity <= orderedproduct.orderedquantity THEN false
           ELSE true
           END                                                                               AS belowminorderquantity
FROM deliveries_orderedproduct orderedproduct
         LEFT JOIN deliveries_delivery delivery ON delivery.id = orderedproduct.delivery_id
         LEFT JOIN basic_currency currency ON currency.id = delivery.currency_id
         LEFT JOIN basic_company supplier ON supplier.id = delivery.supplier_id
         LEFT JOIN basic_product product ON product.id = orderedproduct.product_id
         LEFT JOIN basic_product parentproduct ON product.parent_id = parentproduct.id
         LEFT JOIN deliveries_companyproduct companyproduct
                   ON product.id = companyproduct.product_id AND supplier.id = companyproduct.company_id
         LEFT JOIN deliveries_companyproductsfamily companyproductsfamily
                   ON parentproduct.id = companyproductsfamily.product_id AND
                      supplier.id = companyproductsfamily.company_id
         LEFT JOIN supplynegotiations_offer offer ON offer.id = orderedproduct.offer_id
         LEFT JOIN supplynegotiations_negotiation negotiation ON negotiation.id = offer.negotiation_id
         LEFT JOIN technologies_operation operation ON operation.id = orderedproduct.operation_id
         LEFT JOIN basic_additionalcode additionalcode ON additionalcode.id = orderedproduct.additionalcode_id
         LEFT JOIN product_attachments attachments ON attachments.productid = product.id
         LEFT JOIN advancedgenealogy_batch batch ON batch.id = orderedproduct.batch_id
         LEFT JOIN technologies_qualitycard qualitycard ON qualitycard.id = orderedproduct.qualitycard_id;

alter table deliveries_orderedproductdto
    owner to postgres;


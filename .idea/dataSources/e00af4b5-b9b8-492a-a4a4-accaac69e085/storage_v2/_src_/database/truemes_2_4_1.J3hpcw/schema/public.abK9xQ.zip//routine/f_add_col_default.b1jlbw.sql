create function f_add_col_default(_tbl regclass, _col text, _type text, _default text) returns boolean
    language plpgsql
as
$$
BEGIN
   IF EXISTS (SELECT 1 FROM pg_attribute
              WHERE  attrelid = _tbl
              AND    attname = lower(_col)
              AND    NOT attisdropped) THEN
      RETURN FALSE;
   ELSE
      EXECUTE format('ALTER TABLE %s ADD COLUMN %I %s DEFAULT %s', _tbl, lower(_col), _type, _default);
      RETURN TRUE;
   END IF;
END
$$;

alter function f_add_col_default(regclass, text, text, text) owner to postgres;


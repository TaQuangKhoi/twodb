create view ordersupplies_coverageanalysisfororderdto
            (id, componentsproductiondate, coveragedegree, coveredfromtheday, deliverytime, plannedquantity,
             orderedproductnumber, orderedproductname, orderedproductunit, ordername, ordernumber, orderstartdate,
             orderfinishdate, materialrequirementcoverageid)
as
SELECT cafo.id,
       cafo.componentsproductiondate,
       cafo.coveragedegree,
       cafo.coveredfromtheday,
       cafo.deliverytime,
       cafo.plannedquantity,
       op.number                                    AS orderedproductnumber,
       op.name                                      AS orderedproductname,
       op.unit                                      AS orderedproductunit,
       o.name                                       AS ordername,
       o.number                                     AS ordernumber,
       o.startdate                                  AS orderstartdate,
       o.finishdate                                 AS orderfinishdate,
       cafo.materialrequirementcoverage_id::integer AS materialrequirementcoverageid
FROM ordersupplies_coverageanalysisfororder cafo
         LEFT JOIN basic_product op ON op.id = cafo.orderedproduct_id
         LEFT JOIN orders_order o ON o.id = cafo.order_id;

alter table ordersupplies_coverageanalysisfororderdto
    owner to postgres;


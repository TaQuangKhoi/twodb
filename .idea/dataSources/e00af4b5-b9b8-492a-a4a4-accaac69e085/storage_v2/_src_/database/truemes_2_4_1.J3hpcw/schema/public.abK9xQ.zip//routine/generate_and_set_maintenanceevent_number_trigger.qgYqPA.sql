create function generate_and_set_maintenanceevent_number_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
	NEW.number := generate_maintenanceevent_number();

	return NEW;
END;
$$;

alter function generate_and_set_maintenanceevent_number_trigger() owner to postgres;


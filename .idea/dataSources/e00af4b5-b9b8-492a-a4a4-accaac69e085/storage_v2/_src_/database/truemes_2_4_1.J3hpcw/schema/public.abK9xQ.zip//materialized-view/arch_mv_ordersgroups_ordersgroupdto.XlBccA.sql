create materialized view arch_mv_ordersgroups_ordersgroupdto as
WITH technology_group_numbers AS (SELECT o.ordersgroup_id,
                                         string_agg(DISTINCT tg.number::text, ', '::text) AS number
                                  FROM arch_orders_order o
                                           JOIN technologies_technology t ON o.technology_id = t.id
                                           JOIN technologies_technologygroup tg ON t.technologygroup_id = tg.id
                                  WHERE o.ordersgroup_id IS NOT NULL
                                  GROUP BY o.ordersgroup_id),
     performance AS (SELECT o.ordersgroup_id,
                            first_value(tpl.standardperformance)
                            OVER (PARTITION BY o.ordersgroup_id ORDER BY o.id) AS performancenorm
                     FROM arch_orders_order o
                              LEFT JOIN productflowthrudivision_technologyproductionline tpl
                                        ON tpl.technology_id = o.technology_id AND tpl.master)
SELECT DISTINCT ordersgroup.id,
                ordersgroup.active,
                ordersgroup.number,
                assortment.name                                                                                AS assortmentname,
                productionline.number                                                                          AS productionlinenumber,
                ordersgroup.startdate,
                ordersgroup.finishdate,
                ordersgroup.deadline,
                ordersgroup.quantity,
                ordersgroup.producedquantity,
                ordersgroup.remainingquantity,
                ordersgroup.state,
                company.number                                                                                 AS company,
                ordersgroup.remainingquantityinorders,
                COALESCE(ordersgroup.producedquantity, 0::numeric) +
                COALESCE(drafrptquantity.sum, 0::numeric)                                                      AS producedquantitywithdraft,
                COALESCE(ordersgroup.remainingquantityinorders, 0::numeric) -
                COALESCE(drafrptquantity.sum, 0::numeric)                                                      AS remainingquantityinorderswithdraft,
                tgn.number                                                                                     AS technologygroup,
                p.performancenorm,
                masterorder.deadline::date                                                                     AS clientdate
FROM arch_ordersgroups_ordersgroup ordersgroup
         JOIN basic_assortment assortment ON ordersgroup.assortment_id = assortment.id
         JOIN productionlines_productionline productionline ON ordersgroup.productionline_id = productionline.id
         JOIN arch_masterorders_masterorder masterorder ON ordersgroup.masterorder_id = masterorder.id
         LEFT JOIN basic_company company ON company.id = masterorder.company_id
         LEFT JOIN arch_ordersgroups_drafrptquantitydto drafrptquantity ON ordersgroup.id = drafrptquantity.id
         LEFT JOIN technology_group_numbers tgn ON tgn.ordersgroup_id = ordersgroup.id
         LEFT JOIN performance p ON p.ordersgroup_id = ordersgroup.id;

alter materialized view arch_mv_ordersgroups_ordersgroupdto owner to postgres;


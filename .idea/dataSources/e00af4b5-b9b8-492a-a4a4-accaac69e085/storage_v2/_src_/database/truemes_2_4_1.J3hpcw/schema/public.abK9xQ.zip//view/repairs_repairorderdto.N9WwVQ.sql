create view repairs_repairorderdto
            (id, number, state, createdate, startdate, enddate, quantitytorepair, quantityrepaired, lack, active,
             order_id, ordernumber, division_id, divisionnumber, shift_id, shiftname, product_id, productnumber,
             productname, productunit, productiontracking_id, productiontrackingnumber, faulttype)
as
SELECT repairorder.id,
       repairorder.number,
       repairorder.state,
       repairorder.createdate,
       repairorder.startdate,
       repairorder.enddate,
       repairorder.quantitytorepair,
       repairorder.quantityrepaired,
       repairorder.lack,
       repairorder.active,
       orderdto.id::integer              AS order_id,
       orderdto.number                   AS ordernumber,
       division.id::integer              AS division_id,
       division.number                   AS divisionnumber,
       shift.id::integer                 AS shift_id,
       shift.name                        AS shiftname,
       product.id::integer               AS product_id,
       product.number                    AS productnumber,
       product.name                      AS productname,
       product.unit                      AS productunit,
       productiontrackingdto.id::integer AS productiontracking_id,
       productiontrackingdto.number      AS productiontrackingnumber,
       ft.name                           AS faulttype
FROM repairs_repairorder repairorder
         JOIN basic_faulttype ft ON ft.id = repairorder.faulttype_id
         LEFT JOIN orders_orderdto orderdto ON orderdto.id = repairorder.order_id
         LEFT JOIN basic_division division ON division.id = repairorder.division_id
         LEFT JOIN basic_shift shift ON shift.id = repairorder.shift_id
         LEFT JOIN basic_product product ON product.id = repairorder.product_id
         LEFT JOIN productioncounting_productiontracking productiontrackingdto
                   ON productiontrackingdto.id = repairorder.productiontracking_id;

alter table repairs_repairorderdto
    owner to postgres;


create function f_rename_tab(_tabname text, _tabnewname text) returns boolean
    language plpgsql
as
$$
    BEGIN
        EXECUTE format('ALTER TABLE IF EXISTS %s RENAME TO %s', _tabname, lower(_tabnewname));

        RETURN TRUE;
    END
$$;

alter function f_rename_tab(text, text) owner to postgres;


create view basic_staffdto
            (id, active, number, name, surname, post, productionlinenumber, divisionnumber, divisionname,
             workstationnumber, workstationname, workforname, wagegroupnumber)
as
SELECT s.id,
       s.active,
       s.number,
       s.name,
       s.surname,
       s.post,
       pl.number AS productionlinenumber,
       d.number  AS divisionnumber,
       d.name    AS divisionname,
       w.number  AS workstationnumber,
       w.name    AS workstationname,
       c.name    AS workforname,
       wg.number AS wagegroupnumber
FROM basic_staff s
         LEFT JOIN productionlines_productionline pl ON s.productionline_id = pl.id
         LEFT JOIN basic_division d ON s.division_id = d.id
         LEFT JOIN basic_workstation w ON s.workstation_id = w.id
         LEFT JOIN basic_company c ON s.workfor_id = c.id
         LEFT JOIN wagegroups_wagegroup wg ON s.wagegroup_id = wg.id;

alter table basic_staffdto
    owner to postgres;


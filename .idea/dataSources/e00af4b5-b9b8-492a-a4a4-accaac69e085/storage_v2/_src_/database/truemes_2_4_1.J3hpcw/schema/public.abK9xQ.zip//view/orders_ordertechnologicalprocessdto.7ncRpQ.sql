create view orders_ordertechnologicalprocessdto
            (id, number, orderpackid, orderpacknumber, orderid, ordernumber, orderstartdate, productid, productnumber,
             modelname, sizenumber, operationid, operationnumber, technologyoperationcomponentid,
             technologicalprocesslistid, workstationtypenumber, workstationnumber, technologicalprocessid,
             technologicalprocessname, technologicalprocessrateid, quantity, productunit, worker, createdate, date,
             wastesquantity)
as
WITH ordertechnologicalprocesswastes AS (SELECT ordertechnologicalprocesswaste.ordertechnologicalprocess_id,
                                                sum(ordertechnologicalprocesswaste.wastequantity) AS wastesquantity
                                         FROM orders_ordertechnologicalprocesswaste ordertechnologicalprocesswaste
                                         GROUP BY ordertechnologicalprocesswaste.ordertechnologicalprocess_id)
SELECT ordertechnologicalprocess.id,
       ordertechnologicalprocess.number,
       orderpack.id::integer                                                AS orderpackid,
       orderpack.number                                                     AS orderpacknumber,
       ordersorder.id::integer                                              AS orderid,
       ordersorder.number                                                   AS ordernumber,
       ordersorder.startdate                                                AS orderstartdate,
       product.id::integer                                                  AS productid,
       product.number                                                       AS productnumber,
       model.name                                                           AS modelname,
       size.number                                                          AS sizenumber,
       operation.id::integer                                                AS operationid,
       operation.number                                                     AS operationnumber,
       technologyoperationcomponent.id                                      AS technologyoperationcomponentid,
       technologyoperationcomponent.technologicalprocesslist_id             AS technologicalprocesslistid,
       workstationtype.number                                               AS workstationtypenumber,
       workstation.number                                                   AS workstationnumber,
       technologicalprocess.id::integer                                     AS technologicalprocessid,
       technologicalprocess.name                                            AS technologicalprocessname,
       technologicalprocess.technologicalprocessrate_id                     AS technologicalprocessrateid,
       ordertechnologicalprocess.quantity,
       product.unit                                                         AS productunit,
       (staff.surname::text || ' '::text) || staff.name::text               AS worker,
       ordertechnologicalprocess.createdate,
       ordertechnologicalprocess.date,
       COALESCE(ordertechnologicalprocesswastes.wastesquantity, 0::numeric) AS wastesquantity
FROM orders_ordertechnologicalprocess ordertechnologicalprocess
         LEFT JOIN orders_orderpack orderpack ON orderpack.id = ordertechnologicalprocess.orderpack_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = ordertechnologicalprocess.order_id
         LEFT JOIN basic_product product ON product.id = ordertechnologicalprocess.product_id
         LEFT JOIN basic_model model ON model.id = product.model_id
         LEFT JOIN basic_size size ON size.id = product.size_id
         LEFT JOIN technologies_operation operation ON operation.id = ordertechnologicalprocess.operation_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = ordertechnologicalprocess.technologyoperationcomponent_id
         LEFT JOIN technologies_technologicalprocess technologicalprocess
                   ON technologicalprocess.id = ordertechnologicalprocess.technologicalprocess_id
         LEFT JOIN basic_workstationtype workstationtype ON workstationtype.id = technologicalprocess.workstationtype_id
         LEFT JOIN basic_workstation workstation ON workstation.id = technologicalprocess.workstation_id
         LEFT JOIN basic_staff staff ON staff.id = ordertechnologicalprocess.worker_id
         LEFT JOIN ordertechnologicalprocesswastes ordertechnologicalprocesswastes
                   ON ordertechnologicalprocesswastes.ordertechnologicalprocess_id = ordertechnologicalprocess.id;

alter table orders_ordertechnologicalprocessdto
    owner to postgres;


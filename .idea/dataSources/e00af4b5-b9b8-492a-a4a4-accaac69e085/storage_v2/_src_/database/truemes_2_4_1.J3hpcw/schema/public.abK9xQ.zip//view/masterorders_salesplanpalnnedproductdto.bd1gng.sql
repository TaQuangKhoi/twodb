create view masterorders_salesplanpalnnedproductdto(orderid, ordergroupid, salesplanid, productid, plannedquantity) as
SELECT o.id         AS orderid,
       og.id        AS ordergroupid,
       sp.id        AS salesplanid,
       o.product_id AS productid,
       o.plannedquantity
FROM orders_order o
         LEFT JOIN ordersgroups_ordersgroup og ON og.id = o.ordersgroup_id
         LEFT JOIN masterorders_salesplan sp ON sp.id = o.salesplan_id OR sp.id = og.salesplan_id
WHERE sp.id IS NOT NULL;

alter table masterorders_salesplanpalnnedproductdto
    owner to postgres;


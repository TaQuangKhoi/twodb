create function get_currentrate(technologicalprocessrateid bigint, date date, startdate date) returns numeric
    language plpgsql
as
$$
    DECLARE
        currentrate numeric;

    BEGIN
		IF date IS NOT NULL THEN
			SELECT actualrate FROM basic_technologicalprocessrateitem
			WHERE
				technologicalprocessrate_id = technologicalProcessRateId
				AND datefrom < date OR datefrom = date
			ORDER BY dateFrom DESC
			LIMIT 1
			INTO currentrate;
		ELSE
			SELECT actualrate FROM basic_technologicalprocessrateitem
			WHERE
				technologicalprocessrate_id = technologicalProcessRateId
				AND datefrom < startdate OR datefrom = startdate
			ORDER BY dateFrom DESC
			LIMIT 1
			INTO currentrate;
		END IF;

        RETURN currentrate;
    END;
$$;

alter function get_currentrate(bigint, date, date) owner to postgres;


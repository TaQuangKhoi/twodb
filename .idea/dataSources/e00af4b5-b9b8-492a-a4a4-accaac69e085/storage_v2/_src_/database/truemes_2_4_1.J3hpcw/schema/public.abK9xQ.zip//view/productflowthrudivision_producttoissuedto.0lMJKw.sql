create view productflowthrudivision_producttoissuedto
            (id, issuenumber, locationfromnumber, locationtonumber, ordernumber, orderstartdate, state, productnumber,
             productname, demandquantity, orderquantity, quantityperunit, conversion, unitadditional, issuedquantity,
             quantitytoissue, quantitytoissueinaddunit, quantityinlocationfrom, quantityinlocationto, unit, issued,
             productid, additionalcode, storagelocationnumber, correction, locationfrom_id, locationto_id,
             mergedproductnumberandadditionalcode)
as
SELECT producttoissue.id,
       issue.number                                                AS issuenumber,
       locationfrom.number                                         AS locationfromnumber,
       locationto.number                                           AS locationtonumber,
       o.number                                                    AS ordernumber,
       issue.orderstartdate,
       issue.state,
       product.number                                              AS productnumber,
       product.name                                                AS productname,
       producttoissue.demandquantity,
       o.plannedquantity                                           AS orderquantity,
       round(producttoissue.demandquantity / o.plannedquantity, 5) AS quantityperunit,
       producttoissue.conversion,
       product.additionalunit                                      AS unitadditional,
       producttoissue.issuequantity                                AS issuedquantity,
       CASE
           WHEN (producttoissue.demandquantity - producttoissue.issuequantity -
                 COALESCE(producttoissue.correction, 0::numeric)) < 0::numeric THEN 0::numeric
           ELSE producttoissue.demandquantity - producttoissue.issuequantity -
                COALESCE(producttoissue.correction, 0::numeric)
           END                                                     AS quantitytoissue,
       CASE
           WHEN (producttoissue.demandquantity - producttoissue.issuequantity -
                 COALESCE(producttoissue.correction, 0::numeric)) < 0::numeric THEN 0::numeric
           ELSE round((producttoissue.demandquantity - producttoissue.issuequantity -
                       COALESCE(producttoissue.correction, 0::numeric)) * producttoissue.conversion)
           END                                                     AS quantitytoissueinaddunit,
       CASE
           WHEN plu.state::text = 'DISABLED'::text AND warehousestockfrom.quantity IS NULL THEN 0::numeric
           WHEN plu.state::text = 'DISABLED'::text AND warehousestockfrom.quantity IS NOT NULL
               THEN warehousestockfrom.quantity
           WHEN locationfrom.externalnumber IS NULL AND warehousestockfrom.quantity IS NULL THEN 0::numeric
           WHEN locationfrom.externalnumber IS NULL AND warehousestockfrom.quantity IS NOT NULL
               THEN warehousestockfrom.quantity
           WHEN locationfrom.externalnumber IS NOT NULL AND warehousestockfromexternal.locationsquantity IS NULL THEN 0::numeric
           WHEN locationfrom.externalnumber IS NOT NULL AND warehousestockfromexternal.locationsquantity IS NOT NULL
               THEN warehousestockfromexternal.locationsquantity
           ELSE warehousestockfrom.quantity
           END                                                     AS quantityinlocationfrom,
       CASE
           WHEN plu.state::text = 'DISABLED'::text AND warehousestockto.quantity IS NULL THEN 0::numeric
           WHEN plu.state::text = 'DISABLED'::text AND warehousestockto.quantity IS NOT NULL
               THEN warehousestockto.quantity
           WHEN locationfrom.externalnumber IS NULL AND warehousestockto.quantity IS NULL THEN 0::numeric
           WHEN locationfrom.externalnumber IS NULL AND warehousestockto.quantity IS NOT NULL
               THEN warehousestockto.quantity
           WHEN locationfrom.externalnumber IS NOT NULL AND warehousestocktoexternal.locationsquantity IS NULL THEN 0::numeric
           WHEN locationfrom.externalnumber IS NOT NULL AND warehousestocktoexternal.locationsquantity IS NOT NULL
               THEN warehousestocktoexternal.locationsquantity
           ELSE warehousestockfrom.quantity
           END                                                     AS quantityinlocationto,
       product.unit,
       CASE
           WHEN producttoissue.demandquantity <= producttoissue.issuequantity OR
                (producttoissue.demandquantity - producttoissue.issuequantity -
                 COALESCE(producttoissue.correction, 0::numeric)) <= 0::numeric THEN true
           ELSE false
           END                                                     AS issued,
       product.id                                                  AS productid,
       additionalcode.code                                         AS additionalcode,
       storagelocation.number                                      AS storagelocationnumber,
       producttoissue.correction,
       locationfrom.id::integer                                    AS locationfrom_id,
       locationto.id::integer                                      AS locationto_id,
       product.number::text ||
       CASE
           WHEN additionalcode.code IS NULL THEN ''::text
           ELSE ' - '::text || additionalcode.code::text
           END                                                     AS mergedproductnumberandadditionalcode
FROM productflowthrudivision_productstoissue producttoissue
         JOIN qcadooplugin_plugin plu ON plu.identifier::text = 'integration'::text
         LEFT JOIN productflowthrudivision_warehouseissue issue ON producttoissue.warehouseissue_id = issue.id
         LEFT JOIN materialflow_location locationfrom ON issue.placeofissue_id = locationfrom.id
         LEFT JOIN materialflow_location locationto ON producttoissue.location_id = locationto.id
         LEFT JOIN materialflowresources_storagelocation storagelocation
                   ON producttoissue.storagelocation_id = storagelocation.id
         LEFT JOIN orders_order o ON issue.order_id = o.id
         LEFT JOIN basic_product product ON producttoissue.product_id = product.id
         LEFT JOIN basic_additionalcode additionalcode ON producttoissue.additionalcode_id = additionalcode.id
         LEFT JOIN productflowthrudivision_producttoissuedto_internal warehousestockfrom
                   ON warehousestockfrom.product_id = producttoissue.product_id AND
                      warehousestockfrom.location_id = locationfrom.id
         LEFT JOIN productflowthrudivision_producttoissuedto_internal warehousestockto
                   ON warehousestockto.product_id = producttoissue.product_id AND
                      warehousestockto.location_id = locationto.id
         LEFT JOIN productflowthrudivision_productandquantityhelper warehousestockfromexternal
                   ON warehousestockfromexternal.product_id = producttoissue.product_id AND
                      warehousestockfromexternal.location_id = locationfrom.id
         LEFT JOIN productflowthrudivision_productandquantityhelper warehousestocktoexternal
                   ON warehousestocktoexternal.product_id = producttoissue.product_id AND
                      warehousestocktoexternal.location_id = locationto.id
WHERE issue.state::text = ANY (ARRAY ['01draft'::character varying::text, '02inProgress'::character varying::text]);

alter table productflowthrudivision_producttoissuedto
    owner to postgres;


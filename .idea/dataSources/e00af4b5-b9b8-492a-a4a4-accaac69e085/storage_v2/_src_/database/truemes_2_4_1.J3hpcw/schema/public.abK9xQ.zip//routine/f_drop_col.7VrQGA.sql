create function f_drop_col(_tbl regclass, _col text) returns boolean
    language plpgsql
as
$$
    BEGIN
        EXECUTE format('ALTER TABLE %s DROP COLUMN IF EXISTS %I', _tbl, lower(_col));

        RETURN TRUE;
    END
$$;

alter function f_drop_col(regclass, text) owner to postgres;


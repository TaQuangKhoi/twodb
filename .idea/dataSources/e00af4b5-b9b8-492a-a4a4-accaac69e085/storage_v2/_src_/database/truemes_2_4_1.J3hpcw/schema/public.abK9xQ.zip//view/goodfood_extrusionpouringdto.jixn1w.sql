create view goodfood_extrusionpouringdto
            (id, addedquantity, finaladdedquantity, addedquantitymanual, addedquantityrelatesto, extrusionprotocol_id,
             extrusionprotocolid, priority)
as
SELECT pouring.id,
       pouring.addedquantity,
       pouring.finaladdedquantity,
       pouring.addedquantitymanual,
       pouring.addedquantityrelatesto,
       pouring.extrusionprotocol_id,
       pouring.extrusionprotocol_id::integer AS extrusionprotocolid,
       pouring.priority
FROM goodfood_extrusionpouring pouring;

alter table goodfood_extrusionpouringdto
    owner to postgres;


create view advancedgenealogy_batchdto
            (id, batchnumber, state, createuser, createdate, externalnumber, active, productnumber, productname,
             suppliername, hasattachments)
as
SELECT batch.id,
       batch.number              AS batchnumber,
       batch.state,
       batch.createuser,
       batch.createdate,
       batch.externalnumber,
       batch.active,
       product.number            AS productnumber,
       product.name              AS productname,
       company.name              AS suppliername,
       count(attachment.id) <> 0 AS hasattachments
FROM advancedgenealogy_batch batch
         LEFT JOIN advancedgenealogy_batchattachment attachment ON batch.id = attachment.batch_id
         LEFT JOIN basic_product product ON batch.product_id = product.id
         LEFT JOIN basic_company company ON batch.supplier_id = company.id
GROUP BY batch.id, product.number, product.name, company.name;

alter table advancedgenealogy_batchdto
    owner to postgres;


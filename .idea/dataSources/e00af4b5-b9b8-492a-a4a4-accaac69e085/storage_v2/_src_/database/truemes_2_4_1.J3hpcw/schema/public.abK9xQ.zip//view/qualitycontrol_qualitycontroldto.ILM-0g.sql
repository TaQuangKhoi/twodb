create view qualitycontrol_qualitycontroldto
            (id, number, date, controltype, state, qualityrating, product, batch, ordernumber, staff, attachmentsexists,
             description, delivery)
as
SELECT qc.id,
       qc.number,
       qc.date,
       qc.controltype,
       qc.state,
       qc.qualityrating,
       p.number                                           AS product,
       b.number                                           AS batch,
       o.number                                           AS ordernumber,
       (stf.name::text || ' '::text) || stf.surname::text AS staff,
       count(qualitycontrolattachment.id) <> 0            AS attachmentsexists,
       qc.description,
       d.number                                           AS delivery
FROM qualitycontrol_qualitycontrol qc
         JOIN basic_product p ON p.id = qc.product_id
         LEFT JOIN qualitycontrol_qualitycontrolattachment qualitycontrolattachment
                   ON qualitycontrolattachment.qualitycontrol_id = qc.id
         LEFT JOIN advancedgenealogy_batch b ON b.id = qc.batch_id
         LEFT JOIN orders_order o ON o.id = qc.order_id
         LEFT JOIN deliveries_delivery d ON d.id = qc.delivery_id
         LEFT JOIN basic_staff stf ON stf.id = qc.staff_id
GROUP BY qc.id, qc.number, qc.date, qc.controltype, qc.state, qc.qualityrating, p.number, b.number, o.number,
         ((stf.name::text || ' '::text) || stf.surname::text), qc.description, d.number;

alter table qualitycontrol_qualitycontroldto
    owner to postgres;


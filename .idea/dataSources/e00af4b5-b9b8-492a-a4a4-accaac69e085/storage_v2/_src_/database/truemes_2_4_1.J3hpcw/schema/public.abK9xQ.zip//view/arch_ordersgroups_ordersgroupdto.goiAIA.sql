create view arch_ordersgroups_ordersgroupdto
            (id, active, number, assortmentname, productionlinenumber, startdate, finishdate, deadline, quantity,
             producedquantity, remainingquantity, state, company, remainingquantityinorders, producedquantitywithdraft,
             remainingquantityinorderswithdraft, technologygroup, performancenorm, clientdate)
as
SELECT arch_mv_ordersgroups_ordersgroupdto.id,
       arch_mv_ordersgroups_ordersgroupdto.active,
       arch_mv_ordersgroups_ordersgroupdto.number,
       arch_mv_ordersgroups_ordersgroupdto.assortmentname,
       arch_mv_ordersgroups_ordersgroupdto.productionlinenumber,
       arch_mv_ordersgroups_ordersgroupdto.startdate,
       arch_mv_ordersgroups_ordersgroupdto.finishdate,
       arch_mv_ordersgroups_ordersgroupdto.deadline,
       arch_mv_ordersgroups_ordersgroupdto.quantity,
       arch_mv_ordersgroups_ordersgroupdto.producedquantity,
       arch_mv_ordersgroups_ordersgroupdto.remainingquantity,
       arch_mv_ordersgroups_ordersgroupdto.state,
       arch_mv_ordersgroups_ordersgroupdto.company,
       arch_mv_ordersgroups_ordersgroupdto.remainingquantityinorders,
       arch_mv_ordersgroups_ordersgroupdto.producedquantitywithdraft,
       arch_mv_ordersgroups_ordersgroupdto.remainingquantityinorderswithdraft,
       arch_mv_ordersgroups_ordersgroupdto.technologygroup,
       arch_mv_ordersgroups_ordersgroupdto.performancenorm,
       arch_mv_ordersgroups_ordersgroupdto.clientdate
FROM arch_mv_ordersgroups_ordersgroupdto;

alter table arch_ordersgroups_ordersgroupdto
    owner to postgres;


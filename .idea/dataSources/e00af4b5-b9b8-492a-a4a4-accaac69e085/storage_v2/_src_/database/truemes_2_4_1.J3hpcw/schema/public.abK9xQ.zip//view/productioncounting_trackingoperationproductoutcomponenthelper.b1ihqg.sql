create view productioncounting_trackingoperationproductoutcomponenthelper
            (id, productiontracking_id, product_id, productnumber, productname, productunit, plannedquantity,
             usedquantity, batchnumber, producedbatchnumber)
as
SELECT trackingoperationproductoutcomponent.id,
       productiontracking.id::integer AS productiontracking_id,
       product.id::integer            AS product_id,
       product.number                 AS productnumber,
       product.name                   AS productname,
       product.unit                   AS productunit,
       CASE
           WHEN productiontracking.technologyoperationcomponent_id IS NULL
               THEN (SELECT sum(productioncountingquantity_1.plannedquantity) AS sum)
           ELSE (SELECT sum(productioncountingquantity_2.plannedquantity) AS sum)
           END                        AS plannedquantity,
       trackingoperationproductoutcomponent.usedquantity,
       batch.number                   AS batchnumber,
       producedbatch.number           AS producedbatchnumber
FROM productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON productiontracking.id = trackingoperationproductoutcomponent.productiontracking_id
         LEFT JOIN advancedgenealogy_batch producedbatch ON producedbatch.id = productiontracking.batch_id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductoutcomponent.product_id
         LEFT JOIN advancedgenealogy_batch batch ON batch.id = trackingoperationproductoutcomponent.batch_id
         LEFT JOIN basicproductioncounting_productioncountingquantity productioncountingquantity_1
                   ON productioncountingquantity_1.order_id = productiontracking.order_id AND
                      productioncountingquantity_1.product_id = trackingoperationproductoutcomponent.product_id AND
                      productioncountingquantity_1.role::text = '02produced'::text
         LEFT JOIN basicproductioncounting_productioncountingquantity productioncountingquantity_2
                   ON productioncountingquantity_2.order_id = productiontracking.order_id AND
                      productioncountingquantity_2.technologyoperationcomponent_id =
                      productiontracking.technologyoperationcomponent_id AND
                      productioncountingquantity_2.product_id = trackingoperationproductoutcomponent.product_id AND
                      productioncountingquantity_2.role::text = '02produced'::text
WHERE productiontracking.state::text <> ALL
      (ARRAY ['03declined'::text::character varying::text, '04corrected'::text::character varying::text])
GROUP BY trackingoperationproductoutcomponent.id, productiontracking.id, product.id, product.number, product.unit,
         producedbatch.number, trackingoperationproductoutcomponent.usedquantity,
         productiontracking.technologyoperationcomponent_id, batch.number;

alter table productioncounting_trackingoperationproductoutcomponenthelper
    owner to postgres;


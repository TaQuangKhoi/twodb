create view cmmsmachineparts_maintenanceeventlistdto
            (id, number, type, createuser, createdate, state, description, maintenanceeventcontext_id,
             personreceivingname, reportingemployeename, factory_id, factorynumber, division_id, divisionnumber,
             workstationnumber, subassemblynumber, faulttypename, productionlinenumber, highestpriority)
as
SELECT maintenanceevent.id,
       maintenanceevent.number,
       maintenanceevent.type,
       maintenanceevent.createuser,
       maintenanceevent.createdate,
       maintenanceevent.state,
       maintenanceevent.description,
       context.id                                                                     AS maintenanceeventcontext_id,
       (staff.name::text || ' '::text) || staff.surname::text                         AS personreceivingname,
       (reportingemployee.name::text || ' '::text) || reportingemployee.surname::text AS reportingemployeename,
       factory.id::integer                                                            AS factory_id,
       factory.number                                                                 AS factorynumber,
       division.id::integer                                                           AS division_id,
       division.number                                                                AS divisionnumber,
       workstation.number                                                             AS workstationnumber,
       subassembly.number                                                             AS subassemblynumber,
       faulttype.name                                                                 AS faulttypename,
       productionline.number                                                          AS productionlinenumber,
       maintenanceevent.highestpriority
FROM cmmsmachineparts_maintenanceevent maintenanceevent
         LEFT JOIN cmmsmachineparts_maintenanceeventcontext context
                   ON maintenanceevent.maintenanceeventcontext_id = context.id
         LEFT JOIN basic_staff staff ON maintenanceevent.personreceiving_id = staff.id
         LEFT JOIN basic_staff reportingemployee ON maintenanceevent.reportingemployee_id = reportingemployee.id
         LEFT JOIN basic_factory factory ON maintenanceevent.factory_id = factory.id
         LEFT JOIN basic_division division ON maintenanceevent.division_id = division.id
         LEFT JOIN basic_workstation workstation ON maintenanceevent.workstation_id = workstation.id
         LEFT JOIN basic_subassembly subassembly ON maintenanceevent.subassembly_id = subassembly.id
         LEFT JOIN basic_faulttype faulttype ON maintenanceevent.faulttype_id = faulttype.id
         LEFT JOIN productionlines_productionline productionline
                   ON maintenanceevent.productionline_id = productionline.id;

alter table cmmsmachineparts_maintenanceeventlistdto
    owner to postgres;


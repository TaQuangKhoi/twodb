create view productioncounting_productionanalysisdto
            (id, active, productionline_id, productionlinenumber, company_id, companynumber, staff_id, staffname,
             assortment_id, assortmentname, product_id, productnumber, productname, productunit, sizenumber,
             usedquantity, wastesquantity, donequantity, causeofwastes, shift_id, shiftname, timerangefrom, timerangeto,
             generator_id, generatorname, order_id, ordernumber, obtainedmasterordernumber, technologygroupnumber)
as
SELECT row_number() OVER ()                                                                             AS id,
       bool_or(productiontracking.active)                                                               AS active,
       productionline.id::integer                                                                       AS productionline_id,
       productionline.number                                                                            AS productionlinenumber,
       basiccompany.id::integer                                                                         AS company_id,
       basiccompany.number                                                                              AS companynumber,
       staff.id::integer                                                                                AS staff_id,
       (staff.surname::text || ' '::text) || staff.name::text                                           AS staffname,
       assortment.id::integer                                                                           AS assortment_id,
       assortment.name                                                                                  AS assortmentname,
       product.id::integer                                                                              AS product_id,
       product.number                                                                                   AS productnumber,
       product.name                                                                                     AS productname,
       product.unit                                                                                     AS productunit,
       size.number                                                                                      AS sizenumber,
       sum(COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric)::numeric(14, 5))     AS usedquantity,
       sum(COALESCE(trackingoperationproductoutcomponent.wastesquantity,
                    0::numeric)::numeric(14, 5))                                                        AS wastesquantity,
       sum((COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric) +
            COALESCE(trackingoperationproductoutcomponent.wastesquantity, 0::numeric))::numeric(14, 5)) AS donequantity,
       trackingoperationproductoutcomponent.causeofwastes,
       shift.id::integer                                                                                AS shift_id,
       shift.name                                                                                       AS shiftname,
       productiontracking.timerangefrom::date                                                           AS timerangefrom,
       productiontracking.timerangeto::date                                                             AS timerangeto,
       tcontext.id::integer                                                                             AS generator_id,
       tcontext.number                                                                                  AS generatorname,
       ordersorder.id::integer                                                                          AS order_id,
       ordersorder.number                                                                               AS ordernumber,
       COALESCE(masterorder.number, groupmasterorder.number)                                            AS obtainedmasterordernumber,
       technologygroup.number                                                                           AS technologygroupnumber
FROM productioncounting_productiontracking productiontracking
         LEFT JOIN orders_order ordersorder ON ordersorder.id = productiontracking.order_id
         LEFT JOIN basic_company basiccompany ON basiccompany.id = ordersorder.company_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = ordersorder.productionline_id
         LEFT JOIN basic_staff staff ON staff.id = productiontracking.staff_id
         LEFT JOIN productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
                   ON trackingoperationproductoutcomponent.productiontracking_id = productiontracking.id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductoutcomponent.product_id
         LEFT JOIN basic_assortment assortment ON assortment.id = product.assortment_id
         LEFT JOIN basic_size size ON size.id = product.size_id
         LEFT JOIN basic_shift shift ON shift.id = productiontracking.shift_id
         LEFT JOIN technologies_technology technologyprototype
                   ON ordersorder.technologyprototype_id = technologyprototype.id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext
                   ON tcontext.id = technologyprototype.generatorcontext_id
         LEFT JOIN masterorders_masterorder masterorder ON masterorder.id = ordersorder.masterorder_id
         LEFT JOIN ordersgroups_ordersgroup ordersgroup ON ordersgroup.id = ordersorder.ordersgroup_id
         LEFT JOIN masterorders_masterorder groupmasterorder ON groupmasterorder.id = ordersgroup.masterorder_id
         LEFT JOIN technologies_technologygroup technologygroup
                   ON technologyprototype.technologygroup_id = technologygroup.id
WHERE productiontracking.state::text = ANY
      (ARRAY ['01draft'::character varying::text, '02accepted'::character varying::text])
GROUP BY productionline.id, basiccompany.id, staff.id, assortment.id, size.number, product.id, shift.id,
         trackingoperationproductoutcomponent.causeofwastes, (productiontracking.timerangefrom::date),
         (productiontracking.timerangeto::date), ordersorder.id, tcontext.id, masterorder.id, groupmasterorder.id,
         technologygroup.number
UNION ALL
SELECT row_number() OVER ()                                                                             AS id,
       bool_or(productiontracking.active)                                                               AS active,
       productionline.id::integer                                                                       AS productionline_id,
       productionline.number                                                                            AS productionlinenumber,
       basiccompany.id::integer                                                                         AS company_id,
       basiccompany.number                                                                              AS companynumber,
       staff.id::integer                                                                                AS staff_id,
       (staff.surname::text || ' '::text) || staff.name::text                                           AS staffname,
       assortment.id::integer                                                                           AS assortment_id,
       assortment.name                                                                                  AS assortmentname,
       product.id::integer                                                                              AS product_id,
       product.number                                                                                   AS productnumber,
       product.name                                                                                     AS productname,
       product.unit                                                                                     AS productunit,
       size.number                                                                                      AS sizenumber,
       sum(COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric)::numeric(14, 5))     AS usedquantity,
       sum(COALESCE(trackingoperationproductoutcomponent.wastesquantity,
                    0::numeric)::numeric(14, 5))                                                        AS wastesquantity,
       sum((COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric) +
            COALESCE(trackingoperationproductoutcomponent.wastesquantity, 0::numeric))::numeric(14, 5)) AS donequantity,
       trackingoperationproductoutcomponent.causeofwastes,
       shift.id::integer                                                                                AS shift_id,
       shift.name                                                                                       AS shiftname,
       productiontracking.timerangefrom::date                                                           AS timerangefrom,
       productiontracking.timerangeto::date                                                             AS timerangeto,
       tcontext.id::integer                                                                             AS generator_id,
       tcontext.number                                                                                  AS generatorname,
       ordersorder.id::integer                                                                          AS order_id,
       ordersorder.number                                                                               AS ordernumber,
       COALESCE(masterorder.number, groupmasterorder.number)                                            AS obtainedmasterordernumber,
       technologygroup.number                                                                           AS technologygroupnumber
FROM arch_productioncounting_productiontracking productiontracking
         LEFT JOIN arch_orders_order ordersorder ON ordersorder.id = productiontracking.order_id
         LEFT JOIN basic_company basiccompany ON basiccompany.id = ordersorder.company_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = ordersorder.productionline_id
         LEFT JOIN basic_staff staff ON staff.id = productiontracking.staff_id
         LEFT JOIN arch_productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
                   ON trackingoperationproductoutcomponent.productiontracking_id = productiontracking.id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductoutcomponent.product_id
         LEFT JOIN basic_assortment assortment ON assortment.id = product.assortment_id
         LEFT JOIN basic_size size ON size.id = product.size_id
         LEFT JOIN basic_shift shift ON shift.id = productiontracking.shift_id
         LEFT JOIN technologies_technology technologyprototype
                   ON ordersorder.technologyprototype_id = technologyprototype.id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext
                   ON tcontext.id = technologyprototype.generatorcontext_id
         LEFT JOIN arch_masterorders_masterorder masterorder ON masterorder.id = ordersorder.masterorder_id
         LEFT JOIN arch_ordersgroups_ordersgroup ordersgroup ON ordersgroup.id = ordersorder.ordersgroup_id
         LEFT JOIN arch_masterorders_masterorder groupmasterorder ON groupmasterorder.id = ordersgroup.masterorder_id
         LEFT JOIN technologies_technologygroup technologygroup
                   ON technologyprototype.technologygroup_id = technologygroup.id
WHERE productiontracking.state::text = ANY
      (ARRAY ['01draft'::character varying::text, '02accepted'::character varying::text])
GROUP BY productionline.id, basiccompany.id, staff.id, assortment.id, size.number, product.id, shift.id,
         trackingoperationproductoutcomponent.causeofwastes, (productiontracking.timerangefrom::date),
         (productiontracking.timerangeto::date), ordersorder.id, tcontext.id, masterorder.id, groupmasterorder.id,
         technologygroup.number;

alter table productioncounting_productionanalysisdto
    owner to postgres;


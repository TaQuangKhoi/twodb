create view deliveries_deliveredproductdto
            (id, succession, damagedquantity, deliveredquantity, priceperunit, totalprice, conversion,
             additionalquantity, iswaste, delivery, deliveryid, supplier, productnumber, productname, productunit,
             additionalcode, offernumber, operationnumber, storagelocationnumber, palletnumber, batchnumber,
             productcatalognumber, pallettype, additionalunit, damaged, hasreservations, expirationdate)
as
WITH product_reservations AS (SELECT reservation.deliveredproduct_id AS deliveredproductid,
                                     count(reservation.id) <> 0      AS hasreservations
                              FROM deliveries_deliveredproductreservation reservation
                              GROUP BY reservation.deliveredproduct_id)
SELECT deliveredproduct.id,
       deliveredproduct.succession,
       deliveredproduct.damagedquantity,
       deliveredproduct.deliveredquantity,
       deliveredproduct.priceperunit,
       deliveredproduct.totalprice,
       deliveredproduct.conversion,
       deliveredproduct.additionalquantity,
       deliveredproduct.iswaste,
       delivery.id                                                                           AS delivery,
       delivery.id::integer                                                                  AS deliveryid,
       delivery.supplier_id                                                                  AS supplier,
       product.number                                                                        AS productnumber,
       product.name                                                                          AS productname,
       product.unit                                                                          AS productunit,
       additionalcode.code                                                                   AS additionalcode,
       offer.number                                                                          AS offernumber,
       operation.number                                                                      AS operationnumber,
       storagelocation.number                                                                AS storagelocationnumber,
       palletnumber.number                                                                   AS palletnumber,
       batch.number                                                                          AS batchnumber,
       (SELECT productcatalognumbers_productcatalognumbers.catalognumber
        FROM productcatalognumbers_productcatalognumbers
        WHERE productcatalognumbers_productcatalognumbers.product_id = product.id
          AND productcatalognumbers_productcatalognumbers.company_id = delivery.supplier_id) AS productcatalognumber,
       deliveredproduct.pallettype,
       deliveredproduct.additionalunit,
       deliveredproduct.damaged,
       COALESCE(reservations.hasreservations, false)                                         AS hasreservations,
       deliveredproduct.expirationdate
FROM deliveries_deliveredproduct deliveredproduct
         LEFT JOIN deliveries_delivery delivery ON delivery.id = deliveredproduct.delivery_id
         LEFT JOIN basic_product product ON product.id = deliveredproduct.product_id
         LEFT JOIN supplynegotiations_offer offer ON offer.id = deliveredproduct.offer_id
         LEFT JOIN technologies_operation operation ON operation.id = deliveredproduct.operation_id
         LEFT JOIN basic_additionalcode additionalcode ON additionalcode.id = deliveredproduct.additionalcode_id
         LEFT JOIN materialflowresources_storagelocation storagelocation
                   ON storagelocation.id = deliveredproduct.storagelocation_id
         LEFT JOIN basic_palletnumber palletnumber ON palletnumber.id = deliveredproduct.palletnumber_id
         LEFT JOIN advancedgenealogy_batch batch ON batch.id = deliveredproduct.batch_id
         LEFT JOIN product_reservations reservations ON reservations.deliveredproductid = deliveredproduct.id;

alter table deliveries_deliveredproductdto
    owner to postgres;


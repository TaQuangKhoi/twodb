create view materialflowresources_resourcecorrectiondto
            (id, createdate, productnumber, productname, resourcenumber, correctionnumber, quantitycorrected,
             pricecorrected, batchcorrected, expirationdatecorrected, storagelocationcorrected, palletnumbercorrected,
             typeofpalletcorrected, deliverynumber, location_id, locationnumber, newpalletnumber, oldpalletnumber,
             newstoragelocationnumber, oldstoragelocationnumber, attributecorrection, qualityratingcorrected,
             newqualityrating, oldqualityrating)
as
SELECT resourcecorrection.id,
       resourcecorrection.createdate,
       product.number                                                                                         AS productnumber,
       product.name                                                                                           AS productname,
       resourcecorrection.resourcenumber,
       resourcecorrection.number                                                                              AS correctionnumber,
       resourcecorrection.oldquantity <> resourcecorrection.newquantity                                       AS quantitycorrected,
       COALESCE(resourcecorrection.oldprice, 0::numeric) <>
       COALESCE(resourcecorrection.newprice, 0::numeric)                                                      AS pricecorrected,
       COALESCE(resourcecorrection.oldbatch_id, 0::bigint)::text <>
       COALESCE(resourcecorrection.newbatch_id, 0::bigint)::text                                              AS batchcorrected,
       COALESCE(resourcecorrection.oldexpirationdate, '1900-01-01'::date) <>
       COALESCE(resourcecorrection.newexpirationdate, '1900-01-01'::date)                                     AS expirationdatecorrected,
       COALESCE(resourcecorrection.oldstoragelocation_id, 0::bigint) <>
       COALESCE(resourcecorrection.newstoragelocation_id, 0::bigint)                                          AS storagelocationcorrected,
       COALESCE(resourcecorrection.oldpalletnumber_id, 0::bigint) <>
       COALESCE(resourcecorrection.newpalletnumber_id, 0::bigint)                                             AS palletnumbercorrected,
       COALESCE(resourcecorrection.oldtypeofpallet, ''::character varying)::text <>
       COALESCE(resourcecorrection.newtypeofpallet, ''::character varying)::text                              AS typeofpalletcorrected,
       resourcecorrection.deliverynumber,
       resourcecorrection.location_id::integer                                                                AS location_id,
       location.number                                                                                        AS locationnumber,
       newpallet.number                                                                                       AS newpalletnumber,
       oldpallet.number                                                                                       AS oldpalletnumber,
       newstoragelocation.number                                                                              AS newstoragelocationnumber,
       oldstoragelocation.number                                                                              AS oldstoragelocationnumber,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM materialflowresources_resourceattributevalueaftercorrection resourceattributevalue
                  WHERE resourceattributevalue.resourcecorrection_id = resourcecorrection.id)) > 0 THEN true
           WHEN ((SELECT count(*) AS count
                  FROM materialflowresources_resourceattributevaluebeforecorrection resourceattributevalue
                  WHERE resourceattributevalue.resourcecorrection_id = resourcecorrection.id)) > 0 THEN true
           ELSE false
           END                                                                                                AS attributecorrection,
       COALESCE(resourcecorrection.oldqualityrating, ''::character varying)::text <>
       COALESCE(resourcecorrection.newqualityrating, ''::character varying)::text                             AS qualityratingcorrected,
       resourcecorrection.newqualityrating,
       resourcecorrection.oldqualityrating
FROM materialflowresources_resourcecorrection resourcecorrection
         JOIN basic_product product ON product.id = resourcecorrection.product_id
         LEFT JOIN materialflowresources_resource resource ON resource.id = resourcecorrection.resource_id
         LEFT JOIN materialflow_location location ON location.id = resourcecorrection.location_id
         LEFT JOIN basic_palletnumber newpallet ON newpallet.id = resourcecorrection.newpalletnumber_id
         LEFT JOIN basic_palletnumber oldpallet ON oldpallet.id = resourcecorrection.oldpalletnumber_id
         LEFT JOIN materialflowresources_storagelocation newstoragelocation
                   ON newstoragelocation.id = resourcecorrection.newstoragelocation_id
         LEFT JOIN materialflowresources_storagelocation oldstoragelocation
                   ON oldstoragelocation.id = resourcecorrection.oldstoragelocation_id;

alter table materialflowresources_resourcecorrectiondto
    owner to postgres;


create view basic_timetableexceptiondto (id, name, fromdate, todate, type, relatestoprevday, shifts, productionlines) as
SELECT shifttimetableexception.id,
       shifttimetableexception.name,
       shifttimetableexception.fromdate,
       shifttimetableexception.todate,
       shifttimetableexception.type,
       shifttimetableexception.relatestoprevday,
       array_to_string(ARRAY(SELECT shift.name
                             FROM jointable_shift_shifttimetableexception shift_shifttimetableexception
                                      LEFT JOIN basic_shift shift ON shift_shifttimetableexception.shift_id = shift.id
                             WHERE
                                 shift_shifttimetableexception.shifttimetableexception_id = shifttimetableexception.id),
                       ', '::text)                                          AS shifts,
       array_to_string(ARRAY(SELECT productionline.number
                             FROM jointable_productionline_shifttimetableexception productionline_shifttimetableexception
                                      LEFT JOIN productionlines_productionline productionline
                                                ON productionline_shifttimetableexception.productionline_id =
                                                   productionline.id
                             WHERE productionline_shifttimetableexception.shifttimetableexception_id =
                                   shifttimetableexception.id), ', '::text) AS productionlines
FROM basic_shifttimetableexception shifttimetableexception;

alter table basic_timetableexceptiondto
    owner to postgres;


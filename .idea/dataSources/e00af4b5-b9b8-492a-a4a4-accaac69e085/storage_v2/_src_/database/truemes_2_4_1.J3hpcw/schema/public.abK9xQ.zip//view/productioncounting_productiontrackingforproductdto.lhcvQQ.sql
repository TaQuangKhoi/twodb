create view productioncounting_productiontrackingforproductdto
            (id, number, state, createdate, lasttracking, timerangefrom, timerangeto, active, order_id, ordernumber,
             orderstate, orderstartdate, technologyoperationcomponent_id, technologyoperationcomponentnumber,
             operation_id, shift_id, shiftname, staff_id, staffname, division_id, divisionnumber, subcontractor_id,
             subcontractorname, product_id, productnumber, productname, productunit, plannedquantity, usedquantity,
             productiontracking_id, batchnumber, typeofrecord, producedbatchnumber)
as
SELECT row_number() OVER ()                                                           AS id,
       productiontrackingdto.number,
       productiontrackingdto.state,
       productiontrackingdto.createdate,
       productiontrackingdto.lasttracking,
       productiontrackingdto.timerangefrom,
       productiontrackingdto.timerangeto,
       productiontrackingdto.active,
       productiontrackingdto.order_id,
       productiontrackingdto.ordernumber,
       productiontrackingdto.orderstate,
       productiontrackingdto.orderstartdate,
       productiontrackingdto.technologyoperationcomponent_id,
       productiontrackingdto.technologyoperationcomponentnumber,
       productiontrackingdto.operation_id,
       productiontrackingdto.shift_id,
       productiontrackingdto.shiftname,
       productiontrackingdto.staff_id,
       productiontrackingdto.staffname,
       productiontrackingdto.division_id,
       productiontrackingdto.divisionnumber,
       productiontrackingdto.subcontractor_id,
       productiontrackingdto.subcontractorname,
       trackingoperationproductcomponentdto.product_id,
       trackingoperationproductcomponentdto.productnumber,
       trackingoperationproductcomponentdto.productname,
       trackingoperationproductcomponentdto.productunit,
       trackingoperationproductcomponentdto.plannedquantity,
       COALESCE(trackingoperationproductcomponentdto.usedquantity, 0::numeric(14, 5)) AS usedquantity,
       productiontrackingdto.id::integer                                              AS productiontracking_id,
       trackingoperationproductcomponentdto.batchnumber,
       trackingoperationproductcomponentdto.typeofrecord,
       trackingoperationproductcomponentdto.producedbatchnumber
FROM productioncounting_trackingoperationproductcomponentdto trackingoperationproductcomponentdto
         LEFT JOIN productioncounting_productiontrackingdto productiontrackingdto
                   ON productiontrackingdto.id = trackingoperationproductcomponentdto.productiontracking_id;

alter table productioncounting_productiontrackingforproductdto
    owner to postgres;


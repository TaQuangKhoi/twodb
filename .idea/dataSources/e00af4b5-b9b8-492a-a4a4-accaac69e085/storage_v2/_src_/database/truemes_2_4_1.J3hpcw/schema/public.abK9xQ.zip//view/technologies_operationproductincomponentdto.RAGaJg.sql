create view technologies_operationproductincomponentdto
            (id, operationcomponentid, product_id, productid, productnumber, productname, productunit, quantity,
             priority, itemnumberintheexplodedview, operationname, nodenumber, technologyid, technologyname,
             technologystate, technologynumber, mastertechnology, activetechnology, technologytype,
             hasacceptedtechnology, hascheckedtechnology, technologyinputproducttypename,
             differentproductsindifferentsizes, modelname, assortmentname, technologyproductnumber)
as
SELECT operationproductincomponent.id,
       technologyoperationcomponent.id::integer AS operationcomponentid,
       product.id                               AS product_id,
       product.id::integer                      AS productid,
       product.number                           AS productnumber,
       product.name                             AS productname,
       CASE
           WHEN operationproductincomponent.technologyinputproducttype_id IS NULL THEN product.unit
           ELSE operationproductincomponent.givenunit
           END                                  AS productunit,
       operationproductincomponent.quantity,
       operationproductincomponent.priority,
       operationproductincomponent.itemnumberintheexplodedview,
       operation.name                           AS operationname,
       technologyoperationcomponent.nodenumber,
       technology.id::integer                   AS technologyid,
       technology.name                          AS technologyname,
       technology.state                         AS technologystate,
       technology.number                        AS technologynumber,
       technology.master                        AS mastertechnology,
       technology.active                        AS activetechnology,
       technology.technologytype,
       count(technologyaccepted.id) > 0         AS hasacceptedtechnology,
       count(technologychecked.id) > 0          AS hascheckedtechnology,
       technologyinputproducttype.name          AS technologyinputproducttypename,
       operationproductincomponent.differentproductsindifferentsizes,
       model.name                               AS modelname,
       assortment.name                          AS assortmentname,
       technology_product.number                AS technologyproductnumber
FROM technologies_operationproductincomponent operationproductincomponent
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationproductincomponent.operationcomponent_id
         LEFT JOIN technologies_operation operation ON operation.id = technologyoperationcomponent.operation_id
         LEFT JOIN basic_product product ON product.id = operationproductincomponent.product_id
         LEFT JOIN technologies_technology technology ON technology.id = technologyoperationcomponent.technology_id
         LEFT JOIN basic_product technology_product ON technology_product.id = technology.product_id
         LEFT JOIN basic_model model ON model.id = technology_product.model_id
         LEFT JOIN basic_assortment assortment ON assortment.id = technology_product.assortment_id
         LEFT JOIN technologies_technology technologyaccepted
                   ON technologyaccepted.product_id = operationproductincomponent.product_id AND
                      technologyaccepted.technologytype IS NULL AND technologyaccepted.active = true AND
                      technologyaccepted.state::text = '02accepted'::text
         LEFT JOIN technologies_technology technologychecked
                   ON technologychecked.product_id = operationproductincomponent.product_id AND
                      technologychecked.technologytype IS NULL AND technologychecked.active = true AND
                      technologychecked.state::text = '05checked'::text
         LEFT JOIN technologies_technologyinputproducttype technologyinputproducttype
                   ON technologyinputproducttype.id = operationproductincomponent.technologyinputproducttype_id
GROUP BY operationproductincomponent.id, technologyoperationcomponent.id, product.id, product.number, product.name,
         product.unit, operationproductincomponent.quantity, operationproductincomponent.priority,
         operationproductincomponent.itemnumberintheexplodedview, technology.name, technology.number, technology.state,
         technology.master, operation.name, technology.active, technology.technologytype, technology.id,
         technologyinputproducttype.name, technology_product.number, model.name, assortment.name;

alter table technologies_operationproductincomponentdto
    owner to postgres;


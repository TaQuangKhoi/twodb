create function remove_archived_data() returns void
    language plpgsql
as
$$
DECLARE
    _masterOrder RECORD;
    _goodfoodLabel RECORD;
    _statesMessage RECORD;
    _goodfoodPallet RECORD;
    _printLabelsHelper RECORD;
    _order RECORD;
    _orderstatechange RECORD;
    _ordertimecalculation RECORD;
    _productionpershift RECORD;
    _progressforday RECORD;
    _productiontracking RECORD;
    _anomaly RECORD;
    _labelstatechange RECORD;
    _palletstatechange RECORD;
    _productiontrackingstatechange RECORD;
    _trackingoperationproductincomponent RECORD;
    _trackingoperationproductoutcomponent RECORD;
    _repairorder RECORD;
    _anomalyproductiontrackingentryhelper RECORD;
    _extrusionprotocol RECORD;
    _extrusionprotocolstatechange RECORD;
    _extrusionaddedmixentry RECORD;
    _extrusionpouring RECORD;
    _extrusiontakenoffmixentry RECORD;
    _confectionprotocol RECORD;
    _confectionfilmproduct RECORD;
    _confectionprotocolstatechange RECORD;
    _costcalculation RECORD;
    _bproductioncountingquantity RECORD;
    _basicproductioncounting RECORD;
    _avglaborcostcalcfororder RECORD;
    _atrackingrecord RECORD;
    _document_position RECORD;
    _document RECORD;
    _pallet RECORD;
    _label RECORD;
    _orderGroup RECORD;
BEGIN
    RAISE NOTICE 'START remove archived data';
    SET session_replication_role = 'replica';

    FOR _order IN SELECT id, number FROM arch_orders_order WHERE archived = false
        LOOP
            --RAISE NOTICE 'order : %', _order.number;

            FOR _document IN SELECT id, number FROM arch_materialflowresources_document WHERE order_id = _order.id AND archived = false
                LOOP
                    --RAISE NOTICE 'document : %', _document.number;

                    DELETE FROM esilco_importpositionerror WHERE document_id = _document.id;
                    DELETE FROM productflowthrudivision_issue WHERE document_id = _document.id;
                    DELETE FROM productflowthrudivision_producttoissuecorrection WHERE accountwithreservation_id = _document.id;

                    FOR _document_position IN SELECT * FROM arch_materialflowresources_position WHERE archived = false
                        LOOP
                            DELETE FROM materialflowresources_reservation WHERE position_id = _document_position.id;
                        END LOOP;
                    DELETE FROM materialflowresources_position WHERE document_id = _document.id;
                    DELETE FROM materialflowresources_document WHERE id = _document.id;
                END LOOP;

            FOR _atrackingrecord IN SELECT * FROM arch_advancedgenealogy_trackingrecord WHERE order_id = _order.id AND archived = false
                LOOP
                    DELETE FROM advancedgenealogy_trackingrecord WHERE trackingrecord_id = _atrackingrecord.id;
                    DELETE FROM advancedgenealogy_usedbatchsimple WHERE trackingrecord_id = _atrackingrecord.id;
                    DELETE FROM advancedgenealogyfororders_genealogyproductincomponent WHERE trackingrecord_id = _atrackingrecord.id;
                    DELETE FROM advancedgenealogy_trackingrecord WHERE id = _atrackingrecord.id;
                END LOOP;

            FOR _avglaborcostcalcfororder IN SELECT * FROM arch_avglaborcostcalcfororder_avglaborcostcalcfororder WHERE order_id = _order.id AND archived = false
                LOOP
                    DELETE FROM avglaborcostcalcfororder_assignmentworkertoshift WHERE avglaborcostcalcfororder_id = _avglaborcostcalcfororder.id;
                    DELETE FROM avglaborcostcalcfororder_avglaborcostcalcfororder WHERE id = _avglaborcostcalcfororder.id;
                END LOOP;

            FOR _bproductioncountingquantity IN SELECT * FROM arch_basicproductioncounting_productioncountingquantity WHERE order_id = _order.id AND archived = false
                LOOP
                    DELETE FROM productioncounting_productioncountingquantitysetcomponent WHERE productioncountingquantity_id = _bproductioncountingquantity.id;
                END LOOP;

            FOR _costcalculation IN SELECT * FROM arch_costcalculation_costcalculation WHERE order_id = _order.id AND archived = false
                LOOP
                    DELETE FROM costcalculation_componentcost WHERE costcalculation_id = _costcalculation.id;
                    DELETE FROM costnormsforoperation_calculationoperationcomponent WHERE costcalculation_id = _costcalculation.id;
                    DELETE FROM costcalculation_costcalculation WHERE id = _costcalculation.id;
                END LOOP;

            FOR _confectionprotocol IN SELECT * FROM arch_goodfood_confectionprotocol WHERE order_id = _order.id AND archived = false
                LOOP
                    FOR _confectionfilmproduct IN SELECT * FROM arch_goodfood_confectionfilmproduct WHERE confectionprotocol_id = _confectionprotocol.id AND archived = false
                        LOOP
                            DELETE FROM goodfood_confectionfilmproductentry WHERE confectionfilmproduct_id = _confectionfilmproduct.id;
                            DELETE FROM goodfood_confectionfilmproduct WHERE id = _confectionfilmproduct.id;
                        END LOOP;
                    FOR _confectionprotocolstatechange  IN SELECT * FROM arch_goodfood_confectionprotocolstatechange WHERE confectionprotocol_id = _confectionprotocol.id AND archived = false
                        LOOP
                            DELETE FROM states_message WHERE confectionprotocolstatechange_id = _confectionprotocolstatechange.id;
                            DELETE FROM goodfood_confectionprotocolstatechange WHERE id = _confectionprotocolstatechange.id;
                        END LOOP;
                    DELETE FROM goodfood_confectionadditionalinputproduct WHERE confectionprotocol_id = _confectionprotocol.id;
                    DELETE FROM goodfood_confectioninputproduct WHERE confectionprotocol_id = _confectionprotocol.id;
                    DELETE FROM goodfood_confectionprotocolcorrect WHERE confectionprotocol_id = _confectionprotocol.id;
                    DELETE FROM goodfood_confectionremainderinputproduct WHERE confectionprotocol_id = _confectionprotocol.id;
                    DELETE FROM goodfood_confectionstaff WHERE confectionprotocol_id = _confectionprotocol.id;
                END LOOP;

            FOR _extrusionprotocol IN SELECT * FROM arch_goodfood_extrusionprotocol WHERE order_id = _order.id AND archived = false
                LOOP
                    FOR _extrusionprotocolstatechange IN SELECT * FROM arch_goodfood_extrusionprotocolstatechange WHERE extrusionprotocol_id = _extrusionprotocol.id AND archived = false
                        LOOP
                            DELETE FROM states_message WHERE extrusionprotocolstatechange_id = _extrusionprotocolstatechange.id;
                            DELETE FROM goodfood_extrusionprotocolstatechange WHERE id = _extrusionprotocolstatechange.id;
                        END LOOP;

                    FOR _extrusiontakenoffmixentry IN SELECT * FROM arch_goodfood_extrusiontakenoffmixentry WHERE extrusionprotocol_id = _extrusionprotocol.id AND archived = false
                        LOOP
                            DELETE FROM goodfood_extrusiontakenoffmixingredient WHERE extrusiontakenoffmixentry_id = _extrusiontakenoffmixentry.id;
                            DELETE FROM goodfood_extrusiontakenoffmixentry WHERE id = _extrusiontakenoffmixentry.id;
                        END LOOP;

                    FOR _extrusionpouring IN SELECT * FROM arch_goodfood_extrusionpouring WHERE extrusionprotocol_id = _extrusionprotocol.id AND archived = false
                        LOOP
                            DELETE FROM goodfood_extrusionpouringingredient WHERE extrusionpouring_id = _extrusionpouring.id;
                            DELETE FROM goodfood_extrusionpouringmix WHERE extrusionpouring_id = _extrusionpouring.id;
                            DELETE FROM goodfood_extrusionpouring WHERE id = _extrusionpouring.id;
                        END LOOP;

                    FOR _extrusionaddedmixentry IN SELECT * FROM arch_goodfood_extrusionaddedmixentry WHERE extrusionprotocol_id = _extrusionprotocol.id AND archived = false
                        LOOP
                            DELETE FROM goodfood_extrusionaddedmixingredient WHERE extrusionaddedmixentry_id = _extrusionaddedmixentry.id;
                            DELETE FROM goodfood_extrusionaddedmixentry WHERE id = _extrusionaddedmixentry.id;

                        END LOOP;

                    DELETE FROM goodfood_extrusionprotocolcorrect WHERE extrusionprotocol_id = _extrusionprotocol.id;
                    DELETE FROM goodfood_extrusionsouse WHERE extrusionprotocol_id = _extrusionprotocol.id;
                END LOOP;
            FOR _productiontracking IN SELECT * FROM arch_productioncounting_productiontracking WHERE order_id = _order.id AND archived = false
                LOOP
                    FOR _trackingoperationproductincomponent IN SELECT * FROM arch_productioncounting_trackingoperationproductincomponent WHERE productiontracking_id = _productiontracking.id AND archived = false
                        LOOP
                            FOR _anomalyproductiontrackingentryhelper IN SELECT * FROM arch_productioncounting_anomalyproductiontrackingentryhelper WHERE trackingoperationproductincomponent_id = _trackingoperationproductincomponent.id AND archived = false
                                LOOP
                                    DELETE FROM productioncounting_anomalyreasoncontainer WHERE anomalyproductiontrackingentryhelper_id = _anomalyproductiontrackingentryhelper.id;
                                    DELETE FROM productioncounting_anomalyproductiontrackingentryhelper WHERE id = _anomalyproductiontrackingentryhelper.id;
                                END LOOP;
                            DELETE FROM productioncounting_settechnologyincomponents WHERE trackingoperationproductincomponent_id = _trackingoperationproductincomponent.id;
                            DELETE FROM repairs_repairorderproduct WHERE trackingoperationproductincomponent_id = _trackingoperationproductincomponent.id;
                            DELETE FROM productioncounting_trackingoperationproductincomponent WHERE id = _trackingoperationproductincomponent.id;

                        END LOOP;
                    FOR _repairorder IN SELECT * FROM arch_repairs_repairorder WHERE productiontracking_id = _productiontracking.id AND archived = false
                        LOOP
                            DELETE FROM repairs_repairorderstatechange WHERE repairorder_id = _repairorder.id;
                            DELETE FROM repairs_repairorderworktime WHERE repairorder_id = _repairorder.id;
                            DELETE FROM repairs_repairorder WHERE id = _repairorder.id;
                        END LOOP;
                    FOR _trackingoperationproductoutcomponent IN SELECT * FROM arch_productioncounting_trackingoperationproductoutcomponent WHERE productiontracking_id = _productiontracking.id AND archived = false
                        LOOP
                            DELETE FROM productioncounting_settrackingoperationproductincomponents WHERE trackingoperationproductoutcomponent_id = _trackingoperationproductoutcomponent.id;
                            DELETE FROM productioncounting_trackingoperationproductoutcomponent WHERE id = _trackingoperationproductoutcomponent.id;
                        END LOOP;
                    FOR _anomaly IN SELECT * FROM arch_productioncounting_anomaly WHERE productiontracking_id = _productiontracking.id AND archived = false
                        LOOP
                            DELETE FROM productioncounting_anomalyexplanation WHERE anomaly_id = _anomaly.id;
                            DELETE FROM productioncounting_anomaly WHERE id = _anomaly.id;
                        END LOOP;

                    FOR _productiontrackingstatechange IN SELECT * FROM arch_productioncounting_productiontrackingstatechange WHERE productiontracking_id = _productiontracking.id AND archived = false
                        LOOP
                            DELETE FROM states_message WHERE productiontrackingstatechange_id = _productiontrackingstatechange.id;
                            DELETE FROM productioncounting_productiontrackingstatechange WHERE id = _productiontrackingstatechange.id;
                        END LOOP;
                    DELETE FROM productioncounting_staffworktime WHERE productionrecord_id = _productiontracking.id;
                    DELETE FROM productioncounting_trackingoperationproductincomponent WHERE productiontracking_id = _productiontracking.id;
                END LOOP;
            FOR _productionpershift IN SELECT * FROM arch_productionpershift_productionpershift WHERE order_id = _order.id AND archived = false
                LOOP
                    FOR _progressforday IN SELECT * FROM arch_productionpershift_progressforday WHERE productionpershift_id = _productionpershift.id AND archived = false
                        LOOP
                            DELETE FROM productionpershift_dailyprogress WHERE progressforday_id = _progressforday.id;
                            DELETE FROM productionpershift_progressforday WHERE id = _progressforday.id;
                        END LOOP;
                    DELETE FROM productionpershift_reasontypeofcorrectionplan WHERE productionpershift_id = _productionpershift.id;
                END LOOP;
            FOR _ordertimecalculation IN SELECT * FROM arch_productionscheduling_ordertimecalculation WHERE order_id = _order.id AND archived = false
                LOOP
                    DELETE FROM productionscheduling_opercomptimecalculation WHERE ordertimecalculation_id = _ordertimecalculation.id;
                    DELETE FROM productionscheduling_ordertimecalculation WHERE id = _ordertimecalculation.id;
                END LOOP;
            FOR _orderstatechange IN SELECT * FROM arch_orders_orderstatechange WHERE order_id = _order.id AND archived = false
                LOOP
                    DELETE FROM states_message WHERE orderstatechange_id = _orderstatechange.id;
                    DELETE FROM orders_reasontypeofchangingorderstate WHERE orderstatechange_id = _orderstatechange.id;
                    DELETE FROM orders_orderstatechange WHERE id = _orderstatechange.id;
                END LOOP;

            DELETE FROM basicproductioncounting_productioncountingoperationrun WHERE  order_id = _order.id;
            DELETE FROM basicproductioncounting_productioncountingquantity WHERE  order_id = _order.id;
            DELETE FROM basicproductioncounting_basicproductioncounting WHERE order_id = _order.id;
            DELETE FROM costnormsformaterials_technologyinstoperproductincomp WHERE order_id = _order.id;
            DELETE FROM goodfood_confectionprotocol WHERE order_id = _order.id;
            DELETE FROM goodfood_extrusionprotocol WHERE order_id = _order.id;
            DELETE FROM orders_operationaltask WHERE order_id = _order.id;
            DELETE FROM productflowthrudivision_materialavailability WHERE order_id = _order.id;
            DELETE FROM productioncounting_productiontracking WHERE order_id = _order.id;
            DELETE FROM productionpershift_productionpershift WHERE order_id = _order.id;
            DELETE FROM simplematerialbalance_simplematerialbalanceorderscomponent WHERE order_id = _order.id;
            DELETE FROM urcmaterialavailability_requiredcomponent WHERE order_id = _order.id;
            DELETE FROM stoppage_stoppage WHERE order_id = _order.id;
            DELETE FROM technologies_technologyoperationcomponentmergeproductout WHERE order_id = _order.id;
            DELETE FROM technologies_technologyoperationcomponentmergeproductin WHERE order_id = _order.id;
            DELETE FROM technologies_barcodeoperationcomponent WHERE order_id = _order.id;
            DELETE FROM orders_typeofcorrectioncauses WHERE order_id = _order.id;
            DELETE FROM orders_reasontypedeviationeffectiveend WHERE order_id = _order.id;
            DELETE FROM orders_reasontypedeviationeffectivestart WHERE order_id = _order.id;
            DELETE FROM orders_reasontypecorrectiondateto WHERE order_id = _order.id;
            DELETE FROM orders_reasontypecorrectiondatefrom WHERE order_id = _order.id;
            DELETE FROM orders_order WHERE id = _order.id;
        END LOOP;

    FOR _orderGroup IN SELECT * FROM arch_ordersgroups_ordersgroup WHERE archived = false
        LOOP
            DELETE FROM ordersgroups_ordersgroup WHERE id = _orderGroup.id;
        END LOOP;

    FOR _masterOrder IN SELECT * FROM arch_masterorders_masterorder where archived = false
        LOOP

            DELETE FROM goodfood_printedlabel WHERE masterorder_id = _masterOrder.id;

            FOR _printLabelsHelper IN SELECT * FROM arch_integrationbartender_printlabelshelper WHERE masterorder_id = _masterOrder.id AND archived = false
                LOOP
                    DELETE FROM integrationbartender_sendtoprint WHERE printlabelshelper_id = _printLabelsHelper.id;
                    DELETE FROM integrationbartender_printlabelshelper WHERE id = _printLabelsHelper.id;
                END LOOP;

            FOR _goodfoodLabel IN SELECT * FROM arch_goodfood_label WHERE masterorder_id = _masterOrder.id AND archived = false
                LOOP
                    FOR _pallet IN SELECT * FROM arch_goodfood_pallet WHERE label_id = _goodfoodLabel.id
                        LOOP
                            FOR _palletstatechange IN SELECT * FROM arch_goodfood_palletstatechange WHERE pallet_id = _pallet.id AND archived = false
                                LOOP
                                    DELETE FROM states_message WHERE palletstatechange_id = _palletstatechange.id;
                                    DELETE FROM goodfood_palletstatechange WHERE id = _palletstatechange.id;
                                END LOOP;
                            DELETE FROM goodfood_pallet WHERE id = _pallet.id;
                        END LOOP;

                    FOR _labelstatechange IN SELECT * FROM arch_goodfood_labelstatechange WHERE label_id = _goodfoodLabel.id AND archived = false
                        LOOP
                            DELETE FROM states_message WHERE labelstatechange_id = _labelstatechange.id;
                            DELETE FROM goodfood_labelstatechange WHERE id = _labelstatechange.id;
                        END LOOP;
                    DELETE FROM goodfood_label WHERE id = _goodfoodLabel.id;
                END LOOP;

            DELETE FROM assignmenttoshift_staffassignmenttoshift WHERE masterorder_id = _masterOrder.id;
            DELETE FROM assignmenttoshift_multiassignmenttoshift WHERE masterorder_id = _masterOrder.id;
            DELETE FROM masterorders_masterorderproduct WHERE masterorder_id = _masterOrder.id;
            DELETE FROM masterorders_masterorder WHERE id = _masterOrder.id;
        END LOOP;

    SET session_replication_role = 'origin';

    RAISE NOTICE 'FINISH remove archived data';


END;
$$;

alter function remove_archived_data() owner to postgres;


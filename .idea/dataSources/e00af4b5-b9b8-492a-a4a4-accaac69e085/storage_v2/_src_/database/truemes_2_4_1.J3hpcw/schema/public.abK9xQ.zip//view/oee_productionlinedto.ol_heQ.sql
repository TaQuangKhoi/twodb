create view oee_productionlinedto(id, number, name, active, divisions) as
SELECT productionline.id,
       productionline.number,
       productionline.name,
       productionline.active,
       string_agg(division.number::text, ', '::text) AS divisions
FROM productionlines_productionline productionline
         LEFT JOIN jointable_division_productionline division_productionline
                   ON division_productionline.productionline_id = productionline.id
         LEFT JOIN basic_division division ON division.id = division_productionline.division_id
GROUP BY productionline.id, productionline.number, productionline.name, productionline.active;

alter table oee_productionlinedto
    owner to postgres;


create view linechangeovernorms_ordersnormview
            (id, number, orderid, normnumber, normname, duration, technologyfromnumber, technologytonumber) as
SELECT (o.id::text || ', '::text) || norms.number::text AS id,
       o.number,
       o.id                                             AS orderid,
       norms.number                                     AS normnumber,
       norms.name                                       AS normname,
       norms.duration,
       norms.technologyfromnumber,
       norms.technologytonumber
FROM orders_order o
         LEFT JOIN linechangeovernorms_normflatview norms ON norms.technologytoid = o.technologyprototype_id AND
                                                             norms.technnolgyfromid =
                                                             ((SELECT ord.technologyprototype_id
                                                               FROM orders_order ord
                                                               WHERE ord.active = true
                                                                 AND ord.productionline_id = o.productionline_id
                                                                 AND ord.finishdate < o.finishdate
                                                                 AND (ord.state::text <> ALL
                                                                      (ARRAY ['05declined'::character varying::text, '07abandoned'::character varying::text]))
                                                               ORDER BY ord.finishdate DESC
                                                               LIMIT 1))
WHERE o.active = true
  AND o.finishdate > (now() - '1 mon'::interval)
  AND norms.number IS NOT NULL
  AND (norms.productionlineid IS NOT NULL AND norms.productionlineid = o.productionline_id OR
       norms.productionlineid IS NULL)
ORDER BY norms.productionlineid, norms.changeovertype;

alter table linechangeovernorms_ordersnormview
    owner to postgres;


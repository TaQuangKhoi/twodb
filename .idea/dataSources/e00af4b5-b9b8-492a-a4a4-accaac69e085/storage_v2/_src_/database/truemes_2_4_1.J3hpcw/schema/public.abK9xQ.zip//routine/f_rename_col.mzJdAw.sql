create function f_rename_col(_tbl regclass, _colname text, _colnewname text) returns boolean
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_attribute
        WHERE attrelid = _tbl
            AND attname = lower(_colnewname)
            AND NOT attisdropped) THEN
      RETURN FALSE;
   ELSE
      EXECUTE format('ALTER TABLE %s RENAME COLUMN %s TO %s', _tbl, lower(_colname), lower(_colnewname));

      RETURN TRUE;
   END IF;
END
$$;

alter function f_rename_col(regclass, text, text) owner to postgres;


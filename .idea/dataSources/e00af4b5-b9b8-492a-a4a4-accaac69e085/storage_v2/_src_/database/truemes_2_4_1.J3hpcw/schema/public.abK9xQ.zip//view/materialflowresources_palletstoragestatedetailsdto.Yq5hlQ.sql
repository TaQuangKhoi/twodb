create view materialflowresources_palletstoragestatedetailsdto
            (id, active, resourcenumber, productnumber, productname, additionalcode, quantity, unit, additionalquantity,
             additionalunit, expirationdate, palletnumber, palletnumberactive, typeofpallet, storagelocationnumber,
             locationnumber, location_id, palletid)
as
SELECT resource.id,
       true                              AS active,
       resource.number                   AS resourcenumber,
       product.number                    AS productnumber,
       product.name                      AS productname,
       additionalcode.code               AS additionalcode,
       resource.quantity,
       product.unit,
       resource.quantityinadditionalunit AS additionalquantity,
       resource.givenunit                AS additionalunit,
       resource.expirationdate,
       palletnumber.number               AS palletnumber,
       palletnumber.active               AS palletnumberactive,
       resource.typeofpallet,
       storagelocation.number            AS storagelocationnumber,
       location.number                   AS locationnumber,
       location.id::integer              AS location_id,
       resource.palletnumber_id          AS palletid
FROM materialflowresources_resource resource
         LEFT JOIN basic_product product ON product.id = resource.product_id
         LEFT JOIN basic_additionalcode additionalcode ON additionalcode.id = resource.additionalcode_id
         LEFT JOIN basic_palletnumber palletnumber ON palletnumber.id = resource.palletnumber_id
         LEFT JOIN materialflowresources_storagelocation storagelocation
                   ON storagelocation.id = resource.storagelocation_id
         LEFT JOIN materialflow_location location ON location.id = resource.location_id
WHERE resource.palletnumber_id IS NOT NULL
ORDER BY palletnumber.number;

alter table materialflowresources_palletstoragestatedetailsdto
    owner to postgres;


create view arch_productioncounting_productiontrackingdto
            (id, number, state, createdate, lasttracking, timerangefrom, timerangeto, active, order_id, ordernumber,
             orderstate, technologyoperationcomponent_id, technologyoperationcomponentnumber, operation_id, shift_id,
             shiftname, staff_id, staffname, division_id, divisionnumber, subcontractor_id, subcontractorname,
             repairorder_id, repairordernumber, correctionnumber, productionline_id, productionlinenumber, ordersgroup,
             productnumber, productunit, usedquantity, companynumber, outproductnumber)
as
SELECT arch_mv_productioncounting_productiontrackingdto.id,
       arch_mv_productioncounting_productiontrackingdto.number,
       arch_mv_productioncounting_productiontrackingdto.state,
       arch_mv_productioncounting_productiontrackingdto.createdate,
       arch_mv_productioncounting_productiontrackingdto.lasttracking,
       arch_mv_productioncounting_productiontrackingdto.timerangefrom,
       arch_mv_productioncounting_productiontrackingdto.timerangeto,
       arch_mv_productioncounting_productiontrackingdto.active,
       arch_mv_productioncounting_productiontrackingdto.order_id,
       arch_mv_productioncounting_productiontrackingdto.ordernumber,
       arch_mv_productioncounting_productiontrackingdto.orderstate,
       arch_mv_productioncounting_productiontrackingdto.technologyoperationcomponent_id,
       arch_mv_productioncounting_productiontrackingdto.technologyoperationcomponentnumber,
       arch_mv_productioncounting_productiontrackingdto.operation_id,
       arch_mv_productioncounting_productiontrackingdto.shift_id,
       arch_mv_productioncounting_productiontrackingdto.shiftname,
       arch_mv_productioncounting_productiontrackingdto.staff_id,
       arch_mv_productioncounting_productiontrackingdto.staffname,
       arch_mv_productioncounting_productiontrackingdto.division_id,
       arch_mv_productioncounting_productiontrackingdto.divisionnumber,
       arch_mv_productioncounting_productiontrackingdto.subcontractor_id,
       arch_mv_productioncounting_productiontrackingdto.subcontractorname,
       arch_mv_productioncounting_productiontrackingdto.repairorder_id,
       arch_mv_productioncounting_productiontrackingdto.repairordernumber,
       arch_mv_productioncounting_productiontrackingdto.correctionnumber,
       arch_mv_productioncounting_productiontrackingdto.productionline_id,
       arch_mv_productioncounting_productiontrackingdto.productionlinenumber,
       arch_mv_productioncounting_productiontrackingdto.ordersgroup,
       arch_mv_productioncounting_productiontrackingdto.productnumber,
       arch_mv_productioncounting_productiontrackingdto.productunit,
       arch_mv_productioncounting_productiontrackingdto.usedquantity,
       arch_mv_productioncounting_productiontrackingdto.companynumber,
       arch_mv_productioncounting_productiontrackingdto.outproductnumber
FROM arch_mv_productioncounting_productiontrackingdto;

alter table arch_productioncounting_productiontrackingdto
    owner to postgres;


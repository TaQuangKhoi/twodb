create view integrationscales_scaledto(id, name, comment, type, ip, productionlines) as
SELECT scale.id,
       scale.name,
       scale.comment,
       scale.type,
       concat_ws(':'::text, scale.ip, scale.port) AS ip,
       string_agg(pl.number::text, ', '::text)    AS productionlines
FROM integrationscales_scale scale
         LEFT JOIN integrationscales_productionlineforscale ps ON ps.scale_id = scale.id
         LEFT JOIN productionlines_productionline pl ON ps.productionline_id = pl.id
GROUP BY scale.id;

alter table integrationscales_scaledto
    owner to postgres;


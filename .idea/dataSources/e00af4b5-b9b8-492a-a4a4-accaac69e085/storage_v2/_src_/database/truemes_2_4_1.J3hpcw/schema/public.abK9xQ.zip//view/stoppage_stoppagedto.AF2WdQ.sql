create view stoppage_stoppagedto
            (id, ordernumber, orderstate, productiontrackingnumber, productiontrackingstate, reasonname, description,
             duration, datefrom, dateto, productionlinenumber, workstationnumber, staffname, divisionnumber)
as
SELECT stoppage.id,
       o.number                                               AS ordernumber,
       o.state                                                AS orderstate,
       pt.number                                              AS productiontrackingnumber,
       pt.state                                               AS productiontrackingstate,
       sr.name                                                AS reasonname,
       stoppage.description,
       stoppage.duration,
       stoppage.datefrom,
       stoppage.dateto,
       pl.number                                              AS productionlinenumber,
       workstation.number                                     AS workstationnumber,
       (staff.name::text || ' '::text) || staff.surname::text AS staffname,
       COALESCE(ptd.number, od.number)                        AS divisionnumber
FROM stoppage_stoppage stoppage
         JOIN orders_order o ON o.id = stoppage.order_id
         JOIN stoppage_stoppagereason sr ON sr.id = stoppage.reason_id
         LEFT JOIN productioncounting_productiontracking pt ON pt.id = stoppage.productiontracking_id
         LEFT JOIN productionlines_productionline pl ON pl.id = o.productionline_id
         LEFT JOIN basic_workstation workstation ON workstation.id = pt.workstation_id
         LEFT JOIN basic_staff staff ON staff.id = pt.staff_id
         LEFT JOIN basic_division ptd ON ptd.id = pt.division_id
         LEFT JOIN basic_division od ON od.id = o.division_id;

alter table stoppage_stoppagedto
    owner to postgres;


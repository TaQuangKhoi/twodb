create view goodfood_extrusionprotocoldto
            (id, active, number, dayofshiftstart, extrusioncontextshift, extrusioncontextplace, productionlinenumber,
             productionlinename, ordernumber, extrusioncontextoperatorname, extrusioncontextoperatorsurname, state,
             iscorrected, generationdate)
as
SELECT ep.id,
       ep.active,
       ep.number,
       ep.dayofshiftstart,
       shift.name             AS extrusioncontextshift,
       extrusioncontext.place AS extrusioncontextplace,
       productionline.number  AS productionlinenumber,
       productionline.name    AS productionlinename,
       o.number               AS ordernumber,
       staff.name             AS extrusioncontextoperatorname,
       staff.surname          AS extrusioncontextoperatorsurname,
       ep.state,
       ep.iscorrected,
       ep.generationdate
FROM goodfood_extrusionprotocol ep
         JOIN productionlines_productionline productionline ON ep.productionline_id = productionline.id
         JOIN orders_order o ON ep.order_id = o.id
         LEFT JOIN goodfood_extrusioncontext extrusioncontext ON ep.extrusioncontext_id = extrusioncontext.id
         LEFT JOIN basic_shift shift ON extrusioncontext.shift_id = shift.id
         LEFT JOIN basic_staff staff ON extrusioncontext.operator_id = staff.id;

alter table goodfood_extrusionprotocoldto
    owner to postgres;


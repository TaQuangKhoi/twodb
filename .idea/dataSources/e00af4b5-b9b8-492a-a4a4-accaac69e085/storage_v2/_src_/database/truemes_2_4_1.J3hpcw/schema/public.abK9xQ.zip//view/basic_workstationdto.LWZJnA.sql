create view basic_workstationdto
            (id, active, number, name, workstationtype, division, wnknumber, staff, dateofadmission, dateofwithdrawal,
             productionline)
as
SELECT w.id,
       w.active,
       w.number,
       w.name,
       wt.name                                            AS workstationtype,
       d.number                                           AS division,
       w.wnknumber,
       (stf.name::text || ' '::text) || stf.surname::text AS staff,
       w.dateofadmission,
       w.dateofwithdrawal,
       pl.name                                            AS productionline
FROM basic_workstation w
         LEFT JOIN basic_workstationtype wt ON wt.id = w.workstationtype_id
         LEFT JOIN basic_division d ON w.division_id = d.id
         LEFT JOIN basic_staff stf ON stf.id = w.staff_id
         LEFT JOIN productionlines_productionline pl ON w.productionline_id = pl.id;

alter table basic_workstationdto
    owner to postgres;


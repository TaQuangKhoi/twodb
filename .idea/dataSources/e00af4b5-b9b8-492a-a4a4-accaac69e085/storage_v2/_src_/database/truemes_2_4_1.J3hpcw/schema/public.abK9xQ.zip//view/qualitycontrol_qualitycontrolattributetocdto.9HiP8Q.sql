create view qualitycontrol_qualitycontrolattributetocdto
            (id, technologyoperationcomponentid, technologyoperationcomponent_id, qualitycontrolattribute_id, moment,
             priority, attributenumber, attributename, attributedatatype, attributevaluetype)
as
SELECT qcatoc.id,
       qcatoc.technologyoperationcomponent_id::integer AS technologyoperationcomponentid,
       qcatoc.technologyoperationcomponent_id,
       qcatoc.qualitycontrolattribute_id,
       qcatoc.moment,
       qca.priority,
       a.number                                        AS attributenumber,
       a.name                                          AS attributename,
       a.datatype                                      AS attributedatatype,
       a.valuetype                                     AS attributevaluetype
FROM qualitycontrol_qualitycontrolattributetoc qcatoc
         JOIN qualitycontrol_qualitycontrolattribute qca ON qcatoc.qualitycontrolattribute_id = qca.id
         JOIN basic_attribute a ON qca.attribute_id = a.id;

alter table qualitycontrol_qualitycontrolattributetocdto
    owner to postgres;


create view materialflowresources_resourcestockdto
            (id, location_id, product_id, locationnumber, locationname, productnumber, productname,
             productglobaltypeofmaterial, productunit, familynumber, minimumstate, quantity, quantityinadditionalunit,
             totalvalue, orderedquantity, reservedquantity, availablequantity, blockedforqualitycontrol)
as
WITH minimum_states AS (SELECT warehouseminimumstate.product_id,
                               warehouseminimumstate.location_id,
                               sum(warehouseminimumstate.minimumstate) AS quantity
                        FROM warehouseminimalstate_warehouseminimumstate warehouseminimumstate
                        GROUP BY warehouseminimumstate.product_id, warehouseminimumstate.location_id),
     quantities AS (SELECT resource.product_id,
                           resource.location_id,
                           resource.blockedforqualitycontrol,
                           sum(resource.quantity)                  AS quantity,
                           sum(resource.quantityinadditionalunit)  AS quantityinadditionalunit,
                           sum(resource.quantity * resource.price) AS totalvalue
                    FROM materialflowresources_resource resource
                    GROUP BY resource.product_id, resource.location_id, resource.blockedforqualitycontrol),
     reserved_quantities AS (SELECT reservation.product_id,
                                    reservation.location_id,
                                    sum(reservation.quantity) AS quantity
                             FROM materialflowresources_reservation reservation
                             GROUP BY reservation.product_id, reservation.location_id),
     ordered_quantities AS (SELECT orderedproduct.product_id,
                                   delivery.location_id,
                                   sum(orderedproduct.orderedquantity) AS quantity
                            FROM deliveries_orderedproduct orderedproduct
                                     JOIN deliveries_delivery delivery ON delivery.id = orderedproduct.delivery_id
                            WHERE delivery.active = true
                              AND (delivery.state::text = ANY
                                   (ARRAY ['01draft'::character varying::text, '02prepared'::character varying::text, '03duringCorrection'::character varying::text, '05approved'::character varying::text]))
                            GROUP BY orderedproduct.product_id, delivery.location_id)
SELECT resourcestock.id,
       resourcestock.location_id::integer                                                             AS location_id,
       resourcestock.product_id::integer                                                              AS product_id,
       location.number                                                                                AS locationnumber,
       location.name                                                                                  AS locationname,
       product.number                                                                                 AS productnumber,
       product.name                                                                                   AS productname,
       product.globaltypeofmaterial                                                                   AS productglobaltypeofmaterial,
       product.unit                                                                                   AS productunit,
       family.number                                                                                  AS familynumber,
       COALESCE(minimum_states.quantity, 0::numeric)                                                  AS minimumstate,
       COALESCE(quantities.quantity, 0::numeric)                                                      AS quantity,
       COALESCE(quantities.quantityinadditionalunit, 0::numeric)                                      AS quantityinadditionalunit,
       COALESCE(quantities.totalvalue, 0::numeric)                                                    AS totalvalue,
       COALESCE(ordered_quantities.quantity, 0::numeric)                                              AS orderedquantity,
       COALESCE(reserved_quantities.quantity, 0::numeric)                                             AS reservedquantity,
       COALESCE(quantities.quantity, 0::numeric) -
       COALESCE(reserved_quantities.quantity, 0::numeric)                                             AS availablequantity,
       quantities.blockedforqualitycontrol
FROM materialflowresources_resourcestock resourcestock
         JOIN materialflow_location location ON location.id = resourcestock.location_id
         JOIN basic_product product ON product.id = resourcestock.product_id
         LEFT JOIN basic_product family ON product.parent_id = family.id
         LEFT JOIN minimum_states minimum_states ON minimum_states.product_id = resourcestock.product_id AND
                                                    minimum_states.location_id = resourcestock.location_id
         LEFT JOIN quantities quantities ON quantities.product_id = resourcestock.product_id AND
                                            quantities.location_id = resourcestock.location_id
         LEFT JOIN ordered_quantities ordered_quantities ON ordered_quantities.product_id = resourcestock.product_id AND
                                                            ordered_quantities.location_id = resourcestock.location_id
         LEFT JOIN reserved_quantities reserved_quantities
                   ON reserved_quantities.product_id = resourcestock.product_id AND
                      reserved_quantities.location_id = resourcestock.location_id;

alter table materialflowresources_resourcestockdto
    owner to postgres;


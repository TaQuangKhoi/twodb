create function generate_and_set_operational_task_number_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
	NEW.number := generate_operational_task_number();
	IF NEW.name is null THEN
		NEW.name := NEW.number;
END IF;

return NEW;
END;
$$;

alter function generate_and_set_operational_task_number_trigger() owner to postgres;


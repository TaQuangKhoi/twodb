create view productioncounting_lackdto
            (id, trackingoperationproductoutcomponentid, lackquantity, productunit, reasons) as
SELECT lack.id,
       lack.trackingoperationproductoutcomponent_id::integer AS                     trackingoperationproductoutcomponentid,
       lack.lackquantity,
       product.unit AS                                                              productunit,
       array_to_string(ARRAY(SELECT (lackreason.causeofwastes::text || ' - '::text) ||
                                    COALESCE(lackreason.description, ''::character varying)::text
                             FROM productioncounting_lackreason lackreason
                                      LEFT JOIN productioncounting_lack l ON lackreason.lack_id = l.id
                             WHERE lackreason.lack_id = lack.id), '</br>'::text) AS reasons
FROM productioncounting_lack lack
         LEFT JOIN productioncounting_trackingoperationproductoutcomponent tooc
                   ON tooc.id = lack.trackingoperationproductoutcomponent_id
         LEFT JOIN basic_product product ON product.id = tooc.product_id;

alter table productioncounting_lackdto
    owner to postgres;


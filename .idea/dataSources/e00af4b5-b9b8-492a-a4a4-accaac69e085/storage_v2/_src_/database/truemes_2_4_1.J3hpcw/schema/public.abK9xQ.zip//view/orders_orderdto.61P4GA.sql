create view orders_orderdto (id, active, number, name, state, typeofproductionrecording, plannedquantity) as
SELECT orders_order.id,
       orders_order.active,
       orders_order.number,
       orders_order.name,
       orders_order.state,
       orders_order.typeofproductionrecording,
       orders_order.plannedquantity
FROM orders_order;

alter table orders_orderdto
    owner to postgres;


create function f_add_col(_tbl regclass, _col text, _type regtype) returns boolean
    language plpgsql
as
$$
BEGIN
   IF EXISTS (SELECT 1 FROM pg_attribute
              WHERE  attrelid = _tbl
              AND    attname = lower(_col)
              AND    NOT attisdropped) THEN
      RETURN FALSE;
   ELSE
      EXECUTE format('ALTER TABLE %s ADD COLUMN %I %s', _tbl, lower(_col), _type);
      RETURN TRUE;
   END IF;
END
$$;

alter function f_add_col(regclass, text, regtype) owner to postgres;


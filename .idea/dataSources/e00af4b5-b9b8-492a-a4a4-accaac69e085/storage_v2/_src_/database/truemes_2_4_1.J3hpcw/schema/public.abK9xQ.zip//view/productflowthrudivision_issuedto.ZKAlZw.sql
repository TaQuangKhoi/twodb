create view productflowthrudivision_issuedto
            (id, warehouseissuenumber, productname, productnumber, productunit, additionalcodecode, demandquantity,
             issuequantity, locationtoquantity, quantityperunit, locationsquantity, additionaldemandquantity, issued,
             conversion, dateofissued, warehouseissuestate, locationnumber, locationid, storagelocationnumber,
             documentnumber, documentstate)
as
SELECT issue.id,
       warehouseissue.number  AS warehouseissuenumber,
       product.name           AS productname,
       product.number         AS productnumber,
       product.unit           AS productunit,
       additionalcode.code    AS additionalcodecode,
       issue.demandquantity,
       issue.issuequantity,
       issue.locationtoquantity,
       issue.quantityperunit,
       issue.locationsquantity,
       issue.additionaldemandquantity,
       issue.issued,
       issue.conversion,
       issue.dateofissued,
       warehouseissue.state   AS warehouseissuestate,
       _location.number       AS locationnumber,
       _location.id::integer  AS locationid,
       storagelocation.number AS storagelocationnumber,
       _document.number       AS documentnumber,
       _document.state        AS documentstate
FROM productflowthrudivision_issue issue
         LEFT JOIN productflowthrudivision_warehouseissue warehouseissue ON warehouseissue.id = issue.warehouseissue_id
         LEFT JOIN basic_product product ON product.id = issue.product_id
         LEFT JOIN basic_additionalcode additionalcode ON additionalcode.id = issue.additionalcode_id
         LEFT JOIN materialflow_location _location ON _location.id = issue.location_id
         LEFT JOIN materialflowresources_storagelocation storagelocation
                   ON storagelocation.id = issue.storagelocation_id
         LEFT JOIN materialflowresources_document _document ON _document.id = issue.document_id;

alter table productflowthrudivision_issuedto
    owner to postgres;


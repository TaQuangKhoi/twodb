create view integrationbartender_printedpalletlabeldto
            (id, createdate, createuser, ssccnumber, printlabelshelper_id, printer_id, printername) as
SELECT row_number() OVER ()                  AS id,
       sendtoprint.createdate,
       sendtoprint.createuser,
       ssccnumber.ssccnumber,
       printlabelshelper.id::integer         AS printlabelshelper_id,
       printlabelshelper.printer_id::integer AS printer_id,
       printer.name                          AS printername
FROM integrationbartender_sendtoprint sendtoprint
         JOIN integrationbartender_printlabelshelper printlabelshelper
              ON printlabelshelper.id = sendtoprint.printlabelshelper_id
         JOIN LATERAL unnest(string_to_array(printlabelshelper.ssccnumbers, ', '::text)) ssccnumber(ssccnumber) ON true
         JOIN integrationbartender_printer printer ON printer.id = printlabelshelper.printer_id
WHERE (printlabelshelper.id IN (SELECT jointable_palletlabel_printlabelshelper.printlabelshelper_id
                                FROM jointable_palletlabel_printlabelshelper
                                UNION
                                SELECT jointable_printlabelshelper_printedlabel.printlabelshelper_id
                                FROM jointable_printlabelshelper_printedlabel));

alter table integrationbartender_printedpalletlabeldto
    owner to postgres;


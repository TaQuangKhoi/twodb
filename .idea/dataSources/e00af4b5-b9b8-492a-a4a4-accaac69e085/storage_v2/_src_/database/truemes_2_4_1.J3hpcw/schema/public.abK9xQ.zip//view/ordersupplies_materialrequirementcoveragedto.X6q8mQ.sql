create view ordersupplies_materialrequirementcoveragedto(id, number, coveragetodate, actualdate, generateddate, generatedby) as
SELECT ordersupplies_materialrequirementcoverage.id,
       ordersupplies_materialrequirementcoverage.number,
       ordersupplies_materialrequirementcoverage.coveragetodate,
       ordersupplies_materialrequirementcoverage.actualdate,
       ordersupplies_materialrequirementcoverage.generateddate,
       ordersupplies_materialrequirementcoverage.generatedby
FROM ordersupplies_materialrequirementcoverage
WHERE ordersupplies_materialrequirementcoverage.saved = true;

alter table ordersupplies_materialrequirementcoveragedto
    owner to postgres;


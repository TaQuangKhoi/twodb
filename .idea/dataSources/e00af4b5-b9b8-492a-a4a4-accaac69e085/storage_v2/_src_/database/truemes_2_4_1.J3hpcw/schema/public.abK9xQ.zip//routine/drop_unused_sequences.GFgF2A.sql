create function drop_unused_sequences() returns void
    language plpgsql
as
$$
    DECLARE
        row record;
        _yymm text;

    BEGIN
        _yymm := to_char(current_timestamp - interval '6 month', 'YYMM');
        FOR row IN SELECT sequence_name FROM information_schema.sequences where sequence_schema = 'public'
            and sequence_name LIKE 'masterorders_master_order_number_%'
        LOOP
            IF substring(row.sequence_name FROM '[0-9]+') < _yymm THEN
                EXECUTE 'DROP SEQUENCE ' || quote_ident(row.sequence_name) || ';';
            END IF;
        END LOOP;

    END;
$$;

alter function drop_unused_sequences() owner to postgres;


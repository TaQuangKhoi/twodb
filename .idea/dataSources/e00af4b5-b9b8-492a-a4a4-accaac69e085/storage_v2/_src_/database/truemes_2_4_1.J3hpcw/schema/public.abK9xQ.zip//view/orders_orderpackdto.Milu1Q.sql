create view orders_orderpackdto
            (id, orderid, number, ordernumber, orderproduct, orderstate, size, orderquantity, quantity, unit, state) as
SELECT oop.id,
       o.id::integer     AS orderid,
       oop.number,
       o.number          AS ordernumber,
       p.number          AS orderproduct,
       o.state           AS orderstate,
       s.number          AS size,
       o.plannedquantity AS orderquantity,
       oop.quantity,
       p.unit,
       oop.state
FROM orders_orderpack oop
         JOIN orders_order o ON o.id = oop.order_id
         JOIN basic_product p ON o.product_id = p.id
         LEFT JOIN basic_size s ON p.size_id = s.id;

alter table orders_orderpackdto
    owner to postgres;


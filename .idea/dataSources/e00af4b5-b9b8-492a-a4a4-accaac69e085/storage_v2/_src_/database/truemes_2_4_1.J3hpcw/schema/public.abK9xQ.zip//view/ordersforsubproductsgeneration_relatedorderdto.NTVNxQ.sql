create view ordersforsubproductsgeneration_relatedorderdto
            (id, number, name, productnumber, plannedquantity, producedquantity, datefrom, dateto, productionlinenumber,
             state, rootid, level, order_id)
as
SELECT o.id,
       o.number,
       o.name,
       p.number                                        AS productnumber,
       o.plannedquantity,
       COALESCE(o.amountofproductproduced, 0::numeric) AS producedquantity,
       o.datefrom,
       o.dateto,
       pl.number                                       AS productionlinenumber,
       o.state,
       o.root_id::integer                              AS rootid,
       COALESCE(o.level, 0)                            AS level,
       NULL::bigint                                    AS order_id
FROM orders_order o
         JOIN basic_product p ON p.id = o.product_id
         JOIN productionlines_productionline pl ON pl.id = o.productionline_id;

alter table ordersforsubproductsgeneration_relatedorderdto
    owner to postgres;


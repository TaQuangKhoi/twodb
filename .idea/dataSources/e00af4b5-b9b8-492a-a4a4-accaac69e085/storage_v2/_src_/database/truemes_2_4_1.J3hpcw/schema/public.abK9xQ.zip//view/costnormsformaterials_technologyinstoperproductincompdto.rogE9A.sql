create view costnormsformaterials_technologyinstoperproductincompdto
            (id, orderid, productnumber, productname, nominalcost, nominalcostcurrency, lastpurchasecost,
             lastpurchasecostcurrency, averagecost, averagecostcurrency, costfororder, costforordercurrency,
             lastoffercost, lastoffercostcurrency, averageoffercost, averageoffercostcurrency, costfornumber, unit)
as
SELECT tiopic.id,
       tiopic.order_id::integer AS orderid,
       p.number                 AS productnumber,
       p.name                   AS productname,
       p.nominalcost,
       ncur.alphabeticcode      AS nominalcostcurrency,
       p.lastpurchasecost,
       lcur.alphabeticcode      AS lastpurchasecostcurrency,
       p.averagecost,
       acur.alphabeticcode      AS averagecostcurrency,
       tiopic.costfororder,
       cur.alphabeticcode       AS costforordercurrency,
       p.lastoffercost,
       cur.alphabeticcode       AS lastoffercostcurrency,
       p.averageoffercost,
       cur.alphabeticcode       AS averageoffercostcurrency,
       p.costfornumber,
       p.unit
FROM costnormsformaterials_technologyinstoperproductincomp tiopic
         JOIN basic_product p ON tiopic.product_id = p.id
         CROSS JOIN basic_parameter par
         LEFT JOIN basic_currency cur ON cur.id = par.currency_id
         LEFT JOIN basic_currency acur ON acur.id = p.averagecostcurrency_id
         LEFT JOIN basic_currency lcur ON lcur.id = p.lastpurchasecostcurrency_id
         LEFT JOIN basic_currency ncur ON ncur.id = p.nominalcostcurrency_id;

alter table costnormsformaterials_technologyinstoperproductincompdto
    owner to postgres;


create view productioncounting_trackingoperationproductincomponenthelper
            (id, productiontracking_id, product_id, productnumber, productname, productunit, plannedquantity,
             usedquantity, batchnumber, producedbatchnumber)
as
SELECT trackingoperationproductincomponent.id,
       productiontracking.id::integer                  AS productiontracking_id,
       product.id::integer                             AS product_id,
       product.number                                  AS productnumber,
       product.name                                    AS productname,
       product.unit                                    AS productunit,
       sum(productioncountingquantity.plannedquantity) AS plannedquantity,
       CASE
           WHEN usedbatch.id IS NULL THEN trackingoperationproductincomponent.usedquantity
           ELSE usedbatch.quantity
           END                                         AS usedquantity,
       batch.number                                    AS batchnumber,
       producedbatch.number                            AS producedbatchnumber
FROM productioncounting_trackingoperationproductincomponent trackingoperationproductincomponent
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON productiontracking.id = trackingoperationproductincomponent.productiontracking_id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductincomponent.product_id
         LEFT JOIN advancedgenealogy_batch producedbatch ON producedbatch.id = productiontracking.batch_id
         LEFT JOIN productioncounting_usedbatch usedbatch
                   ON usedbatch.trackingoperationproductincomponent_id = trackingoperationproductincomponent.id
         LEFT JOIN advancedgenealogy_batch batch ON batch.id = usedbatch.batch_id
         LEFT JOIN basicproductioncounting_productioncountingquantity productioncountingquantity
                   ON productioncountingquantity.order_id = productiontracking.order_id AND
                      productioncountingquantity.product_id = trackingoperationproductincomponent.product_id AND
                      productioncountingquantity.role::text = '01used'::text AND
                      CASE
                          WHEN productiontracking.technologyoperationcomponent_id IS NOT NULL THEN
                              productioncountingquantity.technologyoperationcomponent_id =
                              productiontracking.technologyoperationcomponent_id
                          ELSE 1 = 1
                          END
WHERE productiontracking.state::text <> ALL
      (ARRAY ['03declined'::text::character varying::text, '04corrected'::text::character varying::text])
GROUP BY trackingoperationproductincomponent.id, productiontracking.id, product.id, product.number,
         producedbatch.number, product.unit, trackingoperationproductincomponent.usedquantity,
         productiontracking.technologyoperationcomponent_id, usedbatch.id, usedbatch.quantity, batch.number;

alter table productioncounting_trackingoperationproductincomponenthelper
    owner to postgres;


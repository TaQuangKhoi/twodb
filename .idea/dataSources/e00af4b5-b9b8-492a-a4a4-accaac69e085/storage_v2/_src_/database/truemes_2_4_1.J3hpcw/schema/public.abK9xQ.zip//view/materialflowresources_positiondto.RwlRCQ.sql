create view materialflowresources_positiondto
            (id, locationfrom, locationto, productnumber, productname, productglobaltypeofmaterial, productcategory,
             quantity, price, productunit, documentdate, expirationdate, productiondate, documenttype, state,
             documentnumber, documentname, companyname, documentaddress, batch, storagelocation, waste, deliverynumber,
             plannedeventnumber, maintenanceeventnumber, subordernumber, ordernumber, pallettype, palletnumber,
             locationfrom_id, locationto_id, givenquantity, givenunit, conversion, documentid, inbuffer, orderid, value,
             resourcenumber, additionalcode, sellingprice, staff)
as
SELECT "position".id,
       locationfrom.number                                    AS locationfrom,
       locationto.number                                      AS locationto,
       product.number                                         AS productnumber,
       product.name                                           AS productname,
       product.globaltypeofmaterial                           AS productglobaltypeofmaterial,
       product.category                                       AS productcategory,
       "position".quantity,
       "position".price,
       product.unit                                           AS productunit,
       document."time"                                        AS documentdate,
       "position".expirationdate::timestamp without time zone AS expirationdate,
       "position".productiondate::timestamp without time zone AS productiondate,
       CASE
           WHEN "position".externaldocumentnumber IS NULL THEN document.type
           ELSE '03internalOutbound'::character varying(255)
           END                                                AS documenttype,
       document.state,
       CASE
           WHEN "position".externaldocumentnumber IS NULL THEN document.number
           ELSE "position".externaldocumentnumber
           END                                                AS documentnumber,
       document.name                                          AS documentname,
       company.name                                           AS companyname,
       CASE
           WHEN address.name IS NULL THEN address.number::text
           ELSE (address.number::text || ' - '::text) || address.name::text
           END                                                AS documentaddress,
       batch.number                                           AS batch,
       storagelocation.number                                 AS storagelocation,
       "position".waste,
       delivery.number                                        AS deliverynumber,
       plannedevent.number                                    AS plannedeventnumber,
       maintenanceevent.number                                AS maintenanceeventnumber,
       suborder.number                                        AS subordernumber,
       ordersorder.number                                     AS ordernumber,
       "position".typeofpallet                                AS pallettype,
       palletnumber.number                                    AS palletnumber,
       locationfrom.id::integer                               AS locationfrom_id,
       locationto.id::integer                                 AS locationto_id,
       "position".givenquantity,
       "position".givenunit,
       "position".conversion,
       document.id::integer                                   AS documentid,
       document.inbuffer,
       CASE
           WHEN "position".orderid IS NULL THEN document.order_id::integer
           ELSE "position".orderid
           END                                                AS orderid,
       "position".price * "position".quantity                 AS value,
       "position".resourcenumber,
       additionalcode.code                                    AS additionalcode,
       "position".sellingprice,
       (staff.surname::text || ' '::text) || staff.name::text AS staff
FROM materialflowresources_position "position"
         LEFT JOIN materialflowresources_document document ON document.id = "position".document_id
         LEFT JOIN materialflow_location locationfrom ON locationfrom.id = document.locationfrom_id
         LEFT JOIN materialflow_location locationto ON locationto.id = document.locationto_id
         JOIN basic_product product ON product.id = "position".product_id
         LEFT JOIN basic_company company ON company.id = document.company_id
         LEFT JOIN basic_address address ON address.id = document.address_id
         LEFT JOIN materialflowresources_storagelocation storagelocation
                   ON storagelocation.id = "position".storagelocation_id
         LEFT JOIN cmmsmachineparts_maintenanceevent maintenanceevent
                   ON maintenanceevent.id = document.maintenanceevent_id
         LEFT JOIN cmmsmachineparts_plannedevent plannedevent ON plannedevent.id = document.plannedevent_id
         LEFT JOIN deliveries_delivery delivery ON delivery.id = document.delivery_id
         LEFT JOIN subcontractorportal_suborder suborder ON suborder.id = document.suborder_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = document.order_id OR ordersorder.id = "position".orderid
         LEFT JOIN basic_palletnumber palletnumber ON palletnumber.id = "position".palletnumber_id
         LEFT JOIN basic_additionalcode additionalcode ON additionalcode.id = "position".additionalcode_id
         LEFT JOIN advancedgenealogy_batch batch ON batch.id = "position".batch_id
         LEFT JOIN basic_staff staff ON staff.id = document.staff_id;

alter table materialflowresources_positiondto
    owner to postgres;


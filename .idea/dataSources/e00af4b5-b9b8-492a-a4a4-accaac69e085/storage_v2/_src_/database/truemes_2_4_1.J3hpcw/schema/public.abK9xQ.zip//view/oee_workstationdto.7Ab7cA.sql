create view oee_workstationdto(id, number, name, active, productionlinenumber, divisions) as
SELECT workstation.id,
       workstation.number,
       workstation.name,
       workstation.active,
       productionline.number                         AS productionlinenumber,
       string_agg(division.number::text, ', '::text) AS divisions
FROM basic_workstation workstation
         LEFT JOIN productionlines_productionline productionline ON productionline.id = workstation.productionline_id
         LEFT JOIN jointable_division_productionline division_productionline
                   ON division_productionline.productionline_id = productionline.id
         LEFT JOIN basic_division division ON division.id = division_productionline.division_id
GROUP BY workstation.id, workstation.number, workstation.name, workstation.active, productionline.number;

alter table oee_workstationdto
    owner to postgres;


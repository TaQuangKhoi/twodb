create function generate_salesplanmaterialrequirement_number() returns text
    language plpgsql
as
$$
    DECLARE
        _pattern text;
        _sequence_value numeric;
        _seq text;
        _number text;

    BEGIN
        _pattern := '#seq';

        SELECT nextval('masterorders_salesplanmaterialrequirement_number_seq') INTO _sequence_value;

        _seq := to_char(_sequence_value, 'fm000000');

        IF _seq LIKE '%#%' THEN
            _seq := _sequence_value;
        END IF;

        _number := _pattern;
        _number := replace(_number, '#seq', _seq);

        RETURN _number;
    END;
$$;

alter function generate_salesplanmaterialrequirement_number() owner to postgres;


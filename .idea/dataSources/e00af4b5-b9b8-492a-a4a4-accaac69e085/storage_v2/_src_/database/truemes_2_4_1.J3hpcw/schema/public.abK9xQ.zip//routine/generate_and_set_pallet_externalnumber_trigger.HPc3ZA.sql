create function generate_and_set_pallet_externalnumber_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
	NEW.externalnumber := generate_pallet_externalnumber();

	return NEW;
END;
$$;

alter function generate_and_set_pallet_externalnumber_trigger() owner to postgres;


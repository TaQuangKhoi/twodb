create function archive_data(_rows integer) returns void
    language plpgsql
as
$$
	DECLARE
		_order RECORD;
		_orderGroup RECORD;
		_masterOrder RECORD;
	BEGIN
		SET session_replication_role = 'replica';
		FOR _masterOrder IN SELECT * FROM masterorders_masterorder WHERE state = '03completed' ORDER BY createdate LIMIT _rows
		LOOP
			INSERT INTO arch_masterorders_masterorder SELECT * FROM masterorders_masterorder WHERE id = _masterOrder.id;
			FOR _orderGroup IN SELECT * FROM ordersgroups_ordersgroup og  WHERE masterorder_id = _masterOrder.id ORDER BY og.parent_id DESC
			LOOP
				INSERT INTO arch_ordersgroups_ordersgroup SELECT * FROM ordersgroups_ordersgroup WHERE id = _orderGroup.id;
				FOR _order IN SELECT * FROM orders_order ord  WHERE ord.ordersgroup_id = _orderGroup.id ORDER BY ord.parent_id DESC
				LOOP
					INSERT INTO arch_orders_order SELECT * FROM orders_order WHERE id = _order.id;
				END LOOP;
			END LOOP;
		END LOOP;
		EXECUTE 'SELECT archive_connected_orders();';
		EXECUTE 'SELECT archive_connected_tables_all();';
		SET session_replication_role = 'origin';

	END;
$$;

alter function archive_data(integer) owner to postgres;


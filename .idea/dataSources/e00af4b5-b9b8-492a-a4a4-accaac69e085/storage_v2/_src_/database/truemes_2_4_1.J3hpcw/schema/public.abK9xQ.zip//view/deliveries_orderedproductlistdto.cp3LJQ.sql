create view deliveries_orderedproductlistdto
            (id, succession, orderedquantity, priceperunit, conversion, additionalquantity, description, actualversion,
             delivery, deliveryid, supplier, deliverydate, deliverystate, deliverynumber, deliveryname, deliveryactive,
             deliverycurrency, suppliername, productnumber, productname, productnorm, productunit, offernumber,
             negotiationnumber, operationnumber, productcatalognumber, location_id, deliveredquantity)
as
SELECT orderedproduct.id,
       orderedproduct.succession,
       orderedproduct.orderedquantity,
       orderedproduct.priceperunit,
       orderedproduct.conversion,
       orderedproduct.additionalquantity,
       orderedproduct.description,
       orderedproduct.actualversion,
       delivery.id                                                                           AS delivery,
       delivery.id::integer                                                                  AS deliveryid,
       delivery.supplier_id                                                                  AS supplier,
       delivery.deliverydate,
       delivery.state                                                                        AS deliverystate,
       delivery.number                                                                       AS deliverynumber,
       delivery.name                                                                         AS deliveryname,
       delivery.active                                                                       AS deliveryactive,
       currency.alphabeticcode                                                               AS deliverycurrency,
       supplier.name                                                                         AS suppliername,
       product.number                                                                        AS productnumber,
       product.name                                                                          AS productname,
       product.norm                                                                          AS productnorm,
       product.unit                                                                          AS productunit,
       offer.number                                                                          AS offernumber,
       negotiation.number                                                                    AS negotiationnumber,
       operation.number                                                                      AS operationnumber,
       (SELECT productcatalognumbers_productcatalognumbers.catalognumber
        FROM productcatalognumbers_productcatalognumbers
        WHERE productcatalognumbers_productcatalognumbers.product_id = product.id
          AND productcatalognumbers_productcatalognumbers.company_id = delivery.supplier_id) AS productcatalognumber,
       delivery.location_id::integer                                                         AS location_id,
       COALESCE(orderedproduct.deliveredquantity, 0::numeric)                                AS deliveredquantity
FROM deliveries_orderedproduct orderedproduct
         LEFT JOIN deliveries_delivery delivery ON orderedproduct.delivery_id = delivery.id
         LEFT JOIN basic_currency currency ON delivery.currency_id = currency.id
         LEFT JOIN basic_company supplier ON delivery.supplier_id = supplier.id
         LEFT JOIN basic_product product ON orderedproduct.product_id = product.id
         LEFT JOIN supplynegotiations_offer offer ON orderedproduct.offer_id = offer.id
         LEFT JOIN supplynegotiations_negotiation negotiation ON offer.negotiation_id = negotiation.id
         LEFT JOIN technologies_operation operation ON orderedproduct.operation_id = operation.id;

alter table deliveries_orderedproductlistdto
    owner to postgres;


create view materialflowresources_palletstoragestatedto
            (id, active, palletnumber, palletnumberactive, typeofpallet, storagelocationnumber, locationnumber,
             totalquantity, palletmovehelper_id, newstoragelocation_id, newpalletnumber_id, location_id)
as
SELECT palletstoragestatedetails.palletid                      AS id,
       true                                                    AS active,
       palletstoragestatedetails.palletnumber,
       palletstoragestatedetails.palletnumberactive,
       palletstoragestatedetails.typeofpallet,
       palletstoragestatedetails.storagelocationnumber,
       palletstoragestatedetails.locationnumber,
       sum(palletstoragestatedetails.quantity)::numeric(14, 5) AS totalquantity,
       NULL::bigint                                            AS palletmovehelper_id,
       NULL::bigint                                            AS newstoragelocation_id,
       NULL::bigint                                            AS newpalletnumber_id,
       palletstoragestatedetails.location_id
FROM materialflowresources_palletstoragestatedetailsdto palletstoragestatedetails
GROUP BY palletstoragestatedetails.palletid, palletstoragestatedetails.palletnumber,
         palletstoragestatedetails.palletnumberactive, palletstoragestatedetails.typeofpallet,
         palletstoragestatedetails.storagelocationnumber, palletstoragestatedetails.locationnumber,
         palletstoragestatedetails.location_id
ORDER BY palletstoragestatedetails.palletnumber, palletstoragestatedetails.locationnumber;

alter table materialflowresources_palletstoragestatedto
    owner to postgres;


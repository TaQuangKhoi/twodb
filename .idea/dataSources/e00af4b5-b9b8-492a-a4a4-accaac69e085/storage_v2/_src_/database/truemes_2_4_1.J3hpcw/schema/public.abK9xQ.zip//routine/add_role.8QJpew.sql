create function add_role(role_identifier character varying, description character varying) returns void
    language plpgsql
as
$$
    DECLARE
    relationcount bigint;

    BEGIN

        SELECT count(*) INTO relationcount FROM qcadoosecurity_role WHERE identifier = role_identifier;

        IF relationcount = 0 THEN
            INSERT INTO qcadoosecurity_role (identifier, description) VALUES (role_identifier, description);
        END IF;

    END;
$$;

alter function add_role(varchar, varchar) owner to postgres;


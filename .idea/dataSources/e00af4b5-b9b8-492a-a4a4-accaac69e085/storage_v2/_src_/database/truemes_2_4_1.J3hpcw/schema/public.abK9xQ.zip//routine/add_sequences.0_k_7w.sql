create function add_sequences() returns void
    language plpgsql
as
$$
    DECLARE
        row record;

    BEGIN
        FOR row IN SELECT tablename FROM pg_tables p
            INNER JOIN information_schema.columns c ON p.tablename = c.table_name
            WHERE c.table_schema = 'public' AND p.schemaname = 'public' AND c.column_name = 'id' AND data_type = 'bigint'
        LOOP
            IF NOT EXISTS (SELECT 0 FROM pg_class WHERE relname = substring('' || quote_ident(row.tablename) || '_id_seq' FROM 0 FOR 64)) THEN
                EXECUTE 'CREATE SEQUENCE ' || quote_ident(row.tablename) || '_id_seq;';
                EXECUTE 'ALTER TABLE ' || quote_ident(row.tablename) || ' ALTER COLUMN id SET DEFAULT nextval(''' || quote_ident(row.tablename) || '_id_seq'');';
                EXECUTE 'ALTER SEQUENCE ' || quote_ident(row.tablename) || '_id_seq OWNED BY ' || quote_ident(row.tablename) || '.id';
                EXECUTE 'WITH mx AS (SELECT max(id)+1 AS mx FROM ' || quote_ident(row.tablename) || ') SELECT setval( ''' || quote_ident(row.tablename) || '_id_seq'' , mx.mx) FROM mx';
            END IF;
        END LOOP;

        FOR row IN SELECT viewname FROM pg_views p
            INNER JOIN information_schema.columns c ON p.viewname = c.table_name
            WHERE c.table_schema = 'public' AND p.schemaname = 'public' AND c.column_name = 'id' AND data_type = 'bigint'
        LOOP
            IF NOT EXISTS (SELECT 0 FROM pg_class WHERE relname = substring('' || quote_ident(row.viewname) || '_id_seq' FROM 0 FOR 64)) THEN
                EXECUTE 'CREATE SEQUENCE ' || quote_ident(row.viewname) || '_id_seq;';
            END IF;
        END LOOP;
    END;
$$;

alter function add_sequences() owner to postgres;


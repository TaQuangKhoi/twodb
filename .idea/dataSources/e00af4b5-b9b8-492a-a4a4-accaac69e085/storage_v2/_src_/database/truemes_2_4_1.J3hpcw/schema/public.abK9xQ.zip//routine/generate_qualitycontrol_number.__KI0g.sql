create function generate_qualitycontrol_number() returns text
    language plpgsql
as
$$
DECLARE
    _pattern text;
    _sequence_value numeric;
    _seq text;
    _number text;
BEGIN
    _pattern := '#seq';

    select nextval('qualitycontrol_qualitycontrol_number_seq') into _sequence_value;

    _seq := to_char(_sequence_value, 'fm000000');

    if _seq like '%#%' then
        _seq := _sequence_value;
    end if;

    _number := _pattern;
    _number := replace(_number, '#seq', _seq);

    RETURN _number;
END;
$$;

alter function generate_qualitycontrol_number() owner to postgres;


create view productioncounting_trackingoperationproductcomponentdto
            (id, productiontracking_id, product_id, productnumber, productname, productunit, plannedquantity,
             usedquantity, batchnumber, typeofrecord, producedbatchnumber)
as
SELECT row_number() OVER () AS id,
       trackingoperationproductcomponentdto.productiontracking_id,
       trackingoperationproductcomponentdto.product_id,
       trackingoperationproductcomponentdto.productnumber,
       trackingoperationproductcomponentdto.productname,
       trackingoperationproductcomponentdto.productunit,
       trackingoperationproductcomponentdto.plannedquantity,
       trackingoperationproductcomponentdto.usedquantity,
       trackingoperationproductcomponentdto.batchnumber,
       trackingoperationproductcomponentdto.typeofrecord,
       trackingoperationproductcomponentdto.producedbatchnumber
FROM (SELECT trackingoperationproductincomponentdto.productiontracking_id,
             trackingoperationproductincomponentdto.product_id,
             trackingoperationproductincomponentdto.productnumber,
             trackingoperationproductincomponentdto.productname,
             trackingoperationproductincomponentdto.productunit,
             trackingoperationproductincomponentdto.plannedquantity,
             trackingoperationproductincomponentdto.usedquantity,
             trackingoperationproductincomponentdto.batchnumber,
             '01in'::text                                                       AS typeofrecord,
             COALESCE(outtracking.producedbatchnumber, outtracking.batchnumber) AS producedbatchnumber
      FROM productioncounting_trackingoperationproductincomponenthelper trackingoperationproductincomponentdto
               LEFT JOIN productioncounting_trackingoperationproductoutcomponenthelper outtracking
                         ON outtracking.productiontracking_id =
                            trackingoperationproductincomponentdto.productiontracking_id
      UNION
      SELECT trackingoperationproductoutcomponentdto.productiontracking_id,
             trackingoperationproductoutcomponentdto.product_id,
             trackingoperationproductoutcomponentdto.productnumber,
             trackingoperationproductoutcomponentdto.productname,
             trackingoperationproductoutcomponentdto.productunit,
             trackingoperationproductoutcomponentdto.plannedquantity,
             trackingoperationproductoutcomponentdto.usedquantity,
             ''::text                                                      AS batchnumber,
             '02out'::text                                                 AS typeofrecord,
             COALESCE(trackingoperationproductoutcomponentdto.producedbatchnumber,
                      trackingoperationproductoutcomponentdto.batchnumber) AS producedbatchnumber
      FROM productioncounting_trackingoperationproductoutcomponenthelper trackingoperationproductoutcomponentdto) trackingoperationproductcomponentdto;

alter table productioncounting_trackingoperationproductcomponentdto
    owner to postgres;


create view ordersupplies_coverageproducttypedto(productid, technologyid, producttype) as
SELECT prod.id AS productid,
       tech.id AS technologyid,
       CASE
           WHEN tech.technologytype IS NULL AND tech.state::text = '02accepted'::text AND tech.master = true
               THEN '02intermediate'::text
           ELSE '01component'::text
           END AS producttype
FROM basic_product prod
         LEFT JOIN technologies_technology tech ON tech.product_id = prod.id
WHERE tech.technologytype IS NULL
  AND tech.state::text = '02accepted'::text
  AND tech.master = true;

alter table ordersupplies_coverageproducttypedto
    owner to postgres;


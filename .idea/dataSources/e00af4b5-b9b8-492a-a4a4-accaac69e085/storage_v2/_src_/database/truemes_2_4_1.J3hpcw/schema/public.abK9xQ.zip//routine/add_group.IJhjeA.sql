create function add_group(group_identifier character varying, name character varying, description character varying, permissiontype character varying) returns void
    language plpgsql
as
$$
    DECLARE
        relationcount bigint;

    BEGIN

        SELECT count(*) INTO relationcount FROM qcadoosecurity_group WHERE identifier = group_identifier;

        IF relationcount = 0 THEN
            INSERT INTO qcadoosecurity_group (identifier, name, description, permissiontype) VALUES (group_identifier, name, description, permissiontype);
        END IF;

   END;
$$;

alter function add_group(varchar, varchar, varchar, varchar) owner to postgres;


create view technologies_technologydto
            (id, name, number, externalsynchronized, master, state, productnumber, productglobaltypeofmaterial,
             technologygroupnumber, divisionname, productname, technologytype, active, standardperformance,
             generatorname, attachmentsexists, dateandtime, productionlinenumber, assortmentname, qualitycardnumber,
             istemplateaccepted)
as
SELECT technology.id,
       technology.name,
       technology.number,
       technology.externalsynchronized,
       technology.master,
       technology.state,
       product.number                      AS productnumber,
       product.globaltypeofmaterial        AS productglobaltypeofmaterial,
       technologygroup.number              AS technologygroupnumber,
       division.name                       AS divisionname,
       product.name                        AS productname,
       technology.technologytype,
       technology.active,
       tpl.standardperformance,
       generatorcontext.number             AS generatorname,
       count(technologyattachment.id) <> 0 AS attachmentsexists,
       technologystatechange.dateandtime,
       productionline.number               AS productionlinenumber,
       assortment.name                     AS assortmentname,
       qualitycard.number                  AS qualitycardnumber,
       technology.istemplateaccepted
FROM technologies_technology technology
         LEFT JOIN basic_product product ON product.id = technology.product_id
         LEFT JOIN basic_assortment assortment ON assortment.id = product.assortment_id
         LEFT JOIN basic_division division ON division.id = technology.division_id
         LEFT JOIN technologies_technologygroup technologygroup ON technologygroup.id = technology.technologygroup_id
         LEFT JOIN technologies_technologyattachment technologyattachment
                   ON technologyattachment.technology_id = technology.id
         LEFT JOIN technologiesgenerator_generatorcontext generatorcontext
                   ON generatorcontext.id = technology.generatorcontext_id
         LEFT JOIN technologies_technologystatechange technologystatechange
                   ON technologystatechange.technology_id = technology.id AND
                      technologystatechange.status::text = '03successful'::text AND
                      technologystatechange.sourcestate IS NULL AND technologystatechange.targetstate::text = '01draft'::text
         LEFT JOIN technologies_qualitycard qualitycard ON qualitycard.id = technology.qualitycard_id
         LEFT JOIN productflowthrudivision_technologyproductionline tpl
                   ON tpl.technology_id = technology.id AND tpl.master
         LEFT JOIN productionlines_productionline productionline ON productionline.id = tpl.productionline_id
GROUP BY technology.id, product.number, product.globaltypeofmaterial, technologygroup.number, division.name,
         product.name, generatorcontext.number, technologystatechange.dateandtime, tpl.standardperformance,
         productionline.number, assortment.name, qualitycard.number;

alter table technologies_technologydto
    owner to postgres;


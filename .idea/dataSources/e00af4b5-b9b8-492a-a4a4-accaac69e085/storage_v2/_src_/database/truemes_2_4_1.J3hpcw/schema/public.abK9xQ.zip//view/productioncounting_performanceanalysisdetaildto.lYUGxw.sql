create view productioncounting_performanceanalysisdetaildto
            (id, active, productionline_id, productionlinenumber, staff_id, staffname, assortment_id, assortmentname,
             product_id, productnumber, productname, productunit, sizenumber, performancenorm, donequantity,
             timebasedonnorms, shift_id, shiftname, timerangefrom, timerangeto, order_id, ordernumber, generator_id,
             generatorname, timerangefromwithouttime, timerangetowithouttime, labortimesum)
as
SELECT productiontracking.id,
       productiontracking.active,
       productionline.id::integer                                                                  AS productionline_id,
       productionline.number                                                                       AS productionlinenumber,
       staff.id::integer                                                                           AS staff_id,
       (staff.surname::text || ' '::text) || staff.name::text                                      AS staffname,
       assortment.id::integer                                                                      AS assortment_id,
       assortment.name                                                                             AS assortmentname,
       product.id::integer                                                                         AS product_id,
       product.number                                                                              AS productnumber,
       product.name                                                                                AS productname,
       product.unit                                                                                AS productunit,
       size.number                                                                                 AS sizenumber,
       tpl.standardperformance                                                                     AS performancenorm,
       (COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric) +
        COALESCE(trackingoperationproductoutcomponent.wastesquantity, 0::numeric))::numeric(14, 5) AS donequantity,
       ((COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric) +
         COALESCE(trackingoperationproductoutcomponent.wastesquantity, 0::numeric)) * 60::numeric /
        tpl.standardperformance)::integer                                                          AS timebasedonnorms,
       shift.id::integer                                                                           AS shift_id,
       shift.name                                                                                  AS shiftname,
       productiontracking.timerangefrom,
       productiontracking.timerangeto,
       ordersorder.id::integer                                                                     AS order_id,
       ordersorder.number                                                                          AS ordernumber,
       tcontext.id::integer                                                                        AS generator_id,
       tcontext.number                                                                             AS generatorname,
       COALESCE(productiontracking.shiftstartday,
                productiontracking.timerangefrom::date)                                            AS timerangefromwithouttime,
       productiontracking.timerangeto::date                                                        AS timerangetowithouttime,
       date_part('epoch'::text, productiontracking.timerangeto - productiontracking.timerangefrom) AS labortimesum
FROM productioncounting_productiontracking productiontracking
         LEFT JOIN orders_order ordersorder ON ordersorder.id = productiontracking.order_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = ordersorder.productionline_id
         LEFT JOIN basic_staff staff ON staff.id = productiontracking.staff_id
         LEFT JOIN productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
                   ON trackingoperationproductoutcomponent.productiontracking_id = productiontracking.id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductoutcomponent.product_id
         LEFT JOIN basic_assortment assortment ON assortment.id = product.assortment_id
         LEFT JOIN basic_size size ON size.id = product.size_id
         LEFT JOIN productflowthrudivision_technologyproductionline tpl
                   ON tpl.technology_id = ordersorder.technology_id AND tpl.master
         LEFT JOIN basic_shift shift ON shift.id = productiontracking.shift_id
         LEFT JOIN technologies_technology technologyprototype
                   ON ordersorder.technologyprototype_id = technologyprototype.id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext
                   ON tcontext.id = technologyprototype.generatorcontext_id
WHERE productiontracking.state::text = ANY
      (ARRAY ['01draft'::character varying::text, '02accepted'::character varying::text])
UNION ALL
SELECT productiontracking.id,
       productiontracking.active,
       productionline.id::integer                                                                  AS productionline_id,
       productionline.number                                                                       AS productionlinenumber,
       staff.id::integer                                                                           AS staff_id,
       (staff.surname::text || ' '::text) || staff.name::text                                      AS staffname,
       assortment.id::integer                                                                      AS assortment_id,
       assortment.name                                                                             AS assortmentname,
       product.id::integer                                                                         AS product_id,
       product.number                                                                              AS productnumber,
       product.name                                                                                AS productname,
       product.unit                                                                                AS productunit,
       size.number                                                                                 AS sizenumber,
       tpl.standardperformance                                                                     AS performancenorm,
       (COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric) +
        COALESCE(trackingoperationproductoutcomponent.wastesquantity, 0::numeric))::numeric(14, 5) AS donequantity,
       ((COALESCE(trackingoperationproductoutcomponent.usedquantity, 0::numeric) +
         COALESCE(trackingoperationproductoutcomponent.wastesquantity, 0::numeric)) * 60::numeric /
        tpl.standardperformance)::integer                                                          AS timebasedonnorms,
       shift.id::integer                                                                           AS shift_id,
       shift.name                                                                                  AS shiftname,
       productiontracking.timerangefrom,
       productiontracking.timerangeto,
       ordersorder.id::integer                                                                     AS order_id,
       ordersorder.number                                                                          AS ordernumber,
       tcontext.id::integer                                                                        AS generator_id,
       tcontext.number                                                                             AS generatorname,
       COALESCE(productiontracking.shiftstartday,
                productiontracking.timerangefrom::date)                                            AS timerangefromwithouttime,
       productiontracking.timerangeto::date                                                        AS timerangetowithouttime,
       date_part('epoch'::text, productiontracking.timerangeto - productiontracking.timerangefrom) AS labortimesum
FROM arch_productioncounting_productiontracking productiontracking
         LEFT JOIN arch_orders_order ordersorder ON ordersorder.id = productiontracking.order_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = ordersorder.productionline_id
         LEFT JOIN basic_staff staff ON staff.id = productiontracking.staff_id
         LEFT JOIN arch_productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
                   ON trackingoperationproductoutcomponent.productiontracking_id = productiontracking.id
         LEFT JOIN basic_product product ON product.id = trackingoperationproductoutcomponent.product_id
         LEFT JOIN basic_assortment assortment ON assortment.id = product.assortment_id
         LEFT JOIN basic_size size ON size.id = product.size_id
         LEFT JOIN productflowthrudivision_technologyproductionline tpl
                   ON tpl.technology_id = ordersorder.technology_id AND tpl.master
         LEFT JOIN basic_shift shift ON shift.id = productiontracking.shift_id
         LEFT JOIN technologies_technology technologyprototype
                   ON ordersorder.technologyprototype_id = technologyprototype.id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext
                   ON tcontext.id = technologyprototype.generatorcontext_id
WHERE productiontracking.state::text = ANY
      (ARRAY ['01draft'::character varying::text, '02accepted'::character varying::text]);

alter table productioncounting_performanceanalysisdetaildto
    owner to postgres;


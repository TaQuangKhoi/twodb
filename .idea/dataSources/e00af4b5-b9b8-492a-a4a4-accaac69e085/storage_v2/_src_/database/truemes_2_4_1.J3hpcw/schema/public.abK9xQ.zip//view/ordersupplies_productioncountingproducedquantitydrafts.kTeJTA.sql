create view ordersupplies_productioncountingproducedquantitydrafts(producedquantity, order_id, product_id, order_product_id) as
SELECT COALESCE(sum(topoc.usedquantity), 0::numeric) AS producedquantity,
       pt.order_id,
       topoc.product_id,
       o.product_id                                  AS order_product_id
FROM productioncounting_trackingoperationproductoutcomponent topoc
         JOIN productioncounting_productiontracking pt ON pt.id = topoc.productiontracking_id
         JOIN orders_order o ON o.id = pt.order_id
WHERE (pt.state::text = ANY (ARRAY ['01draft'::character varying::text, '02accepted'::character varying::text]))
  AND (o.state::text = ANY (ARRAY ['03inProgress'::character varying::text, '06interrupted'::character varying::text]))
GROUP BY pt.order_id, topoc.product_id, pt.technologyoperationcomponent_id, o.product_id;

alter table ordersupplies_productioncountingproducedquantitydrafts
    owner to postgres;


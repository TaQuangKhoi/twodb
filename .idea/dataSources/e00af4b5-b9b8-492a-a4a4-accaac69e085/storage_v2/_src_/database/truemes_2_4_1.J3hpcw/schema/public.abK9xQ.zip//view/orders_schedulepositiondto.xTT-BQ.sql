create view orders_schedulepositiondto
            (id, scheduleid, staffname, workstationnumber, nodenumber, operationname, operationnumber, ordernumber,
             orderproductnumber, orderproductplanedquantity, productname, productnumber, productunit, quantity,
             additionaltime, machineworktime, laborworktime, starttime, endtime)
as
SELECT scheduleposition.id,
       schedule.id::integer                                   AS scheduleid,
       (staff.surname::text || ' '::text) || staff.name::text AS staffname,
       workstation.number                                     AS workstationnumber,
       technologyoperationcomponent.nodenumber,
       operation.name                                         AS operationname,
       operation.number                                       AS operationnumber,
       _order.number                                          AS ordernumber,
       orderproduct.number                                    AS orderproductnumber,
       _order.plannedquantity                                 AS orderproductplanedquantity,
       product.name                                           AS productname,
       product.number                                         AS productnumber,
       product.unit                                           AS productunit,
       scheduleposition.quantity,
       scheduleposition.additionaltime,
       scheduleposition.machineworktime,
       scheduleposition.laborworktime,
       scheduleposition.starttime,
       scheduleposition.endtime
FROM orders_scheduleposition scheduleposition
         LEFT JOIN orders_schedule schedule ON schedule.id = scheduleposition.schedule_id
         LEFT JOIN orders_order _order ON _order.id = scheduleposition.order_id
         LEFT JOIN basic_product orderproduct ON orderproduct.id = _order.product_id
         LEFT JOIN basic_product product ON product.id = scheduleposition.product_id
         LEFT JOIN basic_staff staff ON staff.id = scheduleposition.staff_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = scheduleposition.technologyoperationcomponent_id
         LEFT JOIN technologies_operation operation ON operation.id = technologyoperationcomponent.operation_id
         LEFT JOIN basic_workstation workstation ON workstation.id = scheduleposition.workstation_id;

alter table orders_schedulepositiondto
    owner to postgres;


create view productflowthrudivision_plannedconsumptioninorderdto
            (id, orderid, ordernumber, orderstartdate, orderstate, orderplanedquantity, orderdonequantity, orderproduct,
             orderunit, productionlinenumber, productid, productnumber, productunit, productplannedquantity,
             productusedquantity, productactualneedquantity, divisionnumber)
as
SELECT pcq.id,
       o.id::integer                                                                      AS orderid,
       o.number                                                                           AS ordernumber,
       o.startdate                                                                        AS orderstartdate,
       o.state                                                                            AS orderstate,
       o.plannedquantity                                                                  AS orderplanedquantity,
       o.donequantity                                                                     AS orderdonequantity,
       op.number                                                                          AS orderproduct,
       op.unit                                                                            AS orderunit,
       pl.number                                                                          AS productionlinenumber,
       p.id::integer                                                                      AS productid,
       op.name                                                                            AS productnumber,
       p.unit                                                                             AS productunit,
       pcq.plannedquantity                                                                AS productplannedquantity,
       pcq.usedquantity                                                                   AS productusedquantity,
       GREATEST(pcq.plannedquantity - COALESCE(pcq.usedquantity, 0::numeric), 0::numeric) AS productactualneedquantity,
       d.number                                                                           AS divisionnumber
FROM basicproductioncounting_productioncountingquantity pcq
         LEFT JOIN orders_order o ON o.id = pcq.order_id
         LEFT JOIN basic_product p ON p.id = pcq.product_id
         LEFT JOIN basic_product op ON op.id = o.product_id
         LEFT JOIN basic_division d ON d.id = o.division_id
         LEFT JOIN productionlines_productionline pl ON pl.id = o.productionline_id
WHERE pcq.role::text = '01used'::text
  AND (pcq.typeofmaterial::text = ANY (ARRAY ['01component'::character varying::text]))
  AND (o.state::text = ANY
       (ARRAY ['01pending'::character varying::text, '02accepted'::character varying::text, '03inProgress'::character varying::text, '06interrupted'::character varying::text]))
  AND o.active = true;

alter table productflowthrudivision_plannedconsumptioninorderdto
    owner to postgres;


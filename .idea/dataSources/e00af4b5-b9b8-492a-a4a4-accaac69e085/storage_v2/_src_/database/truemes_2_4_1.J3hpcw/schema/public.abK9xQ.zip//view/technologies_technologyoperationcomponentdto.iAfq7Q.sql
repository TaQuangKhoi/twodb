create view technologies_technologyoperationcomponentdto
            (id, technologyid, nodenumber, operationnumber, operationname, qualitycontrol) as
SELECT toc.id,
       toc.technology_id::integer                     AS technologyid,
       toc.nodenumber,
       op.number                                      AS operationnumber,
       op.name                                        AS operationname,
       count(qca.technologyoperationcomponent_id) > 0 AS qualitycontrol
FROM technologies_technologyoperationcomponent toc
         JOIN technologies_operation op ON toc.operation_id = op.id
         LEFT JOIN qualitycontrol_qualitycontrolattributetoc qca ON qca.technologyoperationcomponent_id = toc.id
GROUP BY toc.id, toc.technology_id, toc.nodenumber, op.number, op.name;

alter table technologies_technologyoperationcomponentdto
    owner to postgres;


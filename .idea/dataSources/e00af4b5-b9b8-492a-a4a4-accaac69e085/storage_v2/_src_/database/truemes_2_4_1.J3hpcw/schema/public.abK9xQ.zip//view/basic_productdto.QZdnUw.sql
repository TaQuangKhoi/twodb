create view basic_productdto
            (id, number, name, globaltypeofmaterial, category, parentname, ean, externalnumber, assortmentname,
             modelname, norm, sizenumber, hasattachments, additionalcodes, active, unit, additionalunit, entitytype,
             supplier, nominalcost, lastpurchasecost)
as
SELECT product.id,
       product.number,
       product.name,
       product.globaltypeofmaterial,
       product.category,
       parent.name                             AS parentname,
       product.ean,
       product.externalnumber,
       assortment.name                         AS assortmentname,
       model.name                              AS modelname,
       product.norm,
       size.number                             AS sizenumber,
       count(attachment.id) <> 0               AS hasattachments,
       string_agg(code.code::text, ', '::text) AS additionalcodes,
       product.active,
       product.unit,
       product.additionalunit,
       product.entitytype,
       cmp.number                              AS supplier,
       product.nominalcost,
       product.lastpurchasecost
FROM basic_product product
         LEFT JOIN basic_product parent ON product.parent_id = parent.id
         LEFT JOIN basic_assortment assortment ON product.assortment_id = assortment.id
         LEFT JOIN basic_model model ON product.model_id = model.id
         LEFT JOIN basic_productattachment attachment ON attachment.product_id = product.id
         LEFT JOIN basic_additionalcode code ON code.product_id = product.id
         LEFT JOIN basic_size size ON size.id = product.size_id
         LEFT JOIN basic_company cmp ON cmp.id = product.supplier_id
GROUP BY product.id, parent.name, assortment.name, model.name, size.number, cmp.number;

alter table basic_productdto
    owner to postgres;


create view ordersupplies_productioncountingusedquantity(usedquantity, order_id, product_id, technologyoperationcomponent_id) as
SELECT sum(topic.usedquantity) AS usedquantity,
       pt.order_id,
       topic.product_id,
       pt.technologyoperationcomponent_id
FROM productioncounting_trackingoperationproductincomponent topic
         JOIN productioncounting_productiontracking pt ON pt.id = topic.productiontracking_id
         JOIN orders_order o ON o.id = pt.order_id
WHERE (pt.state::text = ANY (ARRAY ['02accepted'::character varying::text]))
  AND (o.state::text = ANY (ARRAY ['03inProgress'::character varying::text, '06interrupted'::character varying::text]))
GROUP BY pt.order_id, topic.product_id, pt.technologyoperationcomponent_id;

alter table ordersupplies_productioncountingusedquantity
    owner to postgres;


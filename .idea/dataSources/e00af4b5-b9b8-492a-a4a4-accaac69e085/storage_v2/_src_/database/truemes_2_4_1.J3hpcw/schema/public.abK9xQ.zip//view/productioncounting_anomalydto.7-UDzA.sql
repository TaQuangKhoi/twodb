create view productioncounting_anomalydto
            (id, number, usedquantity, state, issued, createdate, productnumber, productname, productunit, ordernumber,
             productionlinenumber, divisionnumber, productiontrackingnumber, reasons)
as
SELECT DISTINCT anomaly.id,
                anomaly.number,
                anomaly.usedquantity,
                anomaly.state,
                anomaly.issued,
                anomaly.createdate,
                product.number                                                                          AS productnumber,
                product.name                                                                            AS productname,
                product.unit                                                                            AS productunit,
                ordersorder.number                                                                      AS ordernumber,
                productionline.number                                                                   AS productionlinenumber,
                division.number                                                                         AS divisionnumber,
                productiontracking.number                                                               AS productiontrackingnumber,
                array_to_string(ARRAY(SELECT reson.name
                                      FROM jointable_anomaly_anomalyreason anomaly_anomalyreason
                                               LEFT JOIN productioncounting_anomalyreason reson
                                                         ON anomaly_anomalyreason.anomalyreason_id = reson.id
                                      WHERE anomaly_anomalyreason.anomaly_id = anomaly.id), ', '::text) AS reasons
FROM productioncounting_anomaly anomaly
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON anomaly.productiontracking_id = productiontracking.id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = productiontracking.order_id
         LEFT JOIN basic_product product ON anomaly.product_id = product.id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = ordersorder.productionline_id
         LEFT JOIN basic_division division ON division.id = productiontracking.division_id;

alter table productioncounting_anomalydto
    owner to postgres;


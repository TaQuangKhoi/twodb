create view ordersgroups_masterordergroupswithmaterials(master_order_id, groupswithmaterials, groupswithmaterialsdone) as
SELECT mo.id                                                       AS master_order_id,
       (SELECT count(gro.id) AS count
        FROM ordersgroups_ordersgroupdto gro
        WHERE gro.masterorderid = mo.id
          AND gro.materials = true)                                AS groupswithmaterials,
       (SELECT count(gro.id) AS count
        FROM ordersgroups_ordersgroupdto gro
        WHERE gro.masterorderid = mo.id
          AND gro.materials = true
          AND gro.remainingquantityinorderswithdraft = 0::numeric) AS groupswithmaterialsdone
FROM masterorders_masterorder mo
WHERE mo.materialsissued = false
  AND (mo.state::text = ANY (ARRAY ['01new'::character varying::text, '02inExecution'::character varying::text]));

alter table ordersgroups_masterordergroupswithmaterials
    owner to postgres;


create view qualitycontrol_qualitycarddto(id, number, name, description, state, attachmentsexists) as
SELECT qc.id,
       qc.number,
       qc.name,
       qc.description,
       qc.state,
       count(qualitycardattachment.id) <> 0 AS attachmentsexists
FROM technologies_qualitycard qc
         LEFT JOIN qualitycontrol_qualitycardattachment qualitycardattachment
                   ON qualitycardattachment.qualitycard_id = qc.id
GROUP BY qc.id, qc.number, qc.name, qc.description, qc.state;

alter table qualitycontrol_qualitycarddto
    owner to postgres;


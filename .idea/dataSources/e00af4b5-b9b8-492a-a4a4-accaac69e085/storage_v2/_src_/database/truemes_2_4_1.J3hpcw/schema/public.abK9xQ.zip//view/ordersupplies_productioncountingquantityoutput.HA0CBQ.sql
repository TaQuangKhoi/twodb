create view ordersupplies_productioncountingquantityoutput
            (id, orderid, finishdate, orderstate, productid, operationid, technologyoperationcomponentid,
             plannedquantity, producedquantity, quantity, eventtype, producttype)
as
SELECT pcq.id,
       o.id::integer                                                                          AS orderid,
       o.finishdate,
       o.state                                                                                AS orderstate,
       product.id::integer                                                                    AS productid,
       toc.operation_id::integer                                                              AS operationid,
       pcq.technologyoperationcomponent_id::integer                                           AS technologyoperationcomponentid,
       pcq.plannedquantity,
       COALESCE(pcq.producedquantity, 0::numeric)                                             AS producedquantity,
       GREATEST(pcq.plannedquantity - COALESCE(pcq.producedquantity, 0::numeric), 0::numeric) AS quantity,
       '05orderOutput'::text                                                                  AS eventtype,
       pcq.typeofmaterial                                                                     AS producttype
FROM basicproductioncounting_productioncountingquantity pcq
         JOIN orders_order o ON o.id = pcq.order_id
         JOIN basic_product product ON product.id = pcq.product_id
         JOIN technologies_technologyoperationcomponent toc ON pcq.technologyoperationcomponent_id = toc.id
WHERE pcq.role::text = '02produced'::text
  AND pcq.typeofmaterial::text = '03finalProduct'::text
  AND (o.state::text = ANY
       (ARRAY ['01pending'::character varying::text, '02accepted'::character varying::text, '03inProgress'::character varying::text, '06interrupted'::character varying::text]))
  AND o.active = true;

alter table ordersupplies_productioncountingquantityoutput
    owner to postgres;


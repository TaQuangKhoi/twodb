create view orders_operationaltaskwithcolordto
            (id, number, name, description, type, state, startdate, finishdate, staffname, divisionnumber,
             workstationnumber, workstationid, orderid, ordernumber, tocid, technologyoperationcomponentnodenumber,
             technologyoperationcomponentissubcontracting, productnumber, productname, productunit, plannedquantity,
             usedquantity, remainingquantity, doneinpercentage, opertaskflagpercentexecutionwithcolor,
             percentageofexecutioncellcolor, orderproductnumber, orderproductname, actualstaff, wastesquantity)
as
WITH operational_task_staff AS (SELECT jos.operationaltask_id,
                                       string_agg((staff.surname::text || ' '::text) || staff.name::text,
                                                  ', '::text) AS staffname
                                FROM jointable_operationaltask_staff jos
                                         JOIN basic_staff staff ON jos.staff_id = staff.id
                                GROUP BY jos.operationaltask_id)
SELECT operationaltask.id,
       operationaltask.number,
       operationaltask.name,
       operationaltask.description,
       operationaltask.type,
       operationaltask.state,
       operationaltask.startdate,
       operationaltask.finishdate,
       ots.staffname,
       division.number                               AS divisionnumber,
       workstation.number                            AS workstationnumber,
       workstation.id::integer                       AS workstationid,
       ordersorder.id::integer                       AS orderid,
       ordersorder.number                            AS ordernumber,
       technologyoperationcomponent.id::integer      AS tocid,
       technologyoperationcomponent.nodenumber       AS technologyoperationcomponentnodenumber,
       technologyoperationcomponent.issubcontracting AS technologyoperationcomponentissubcontracting,
       product.number::text                          AS productnumber,
       product.name::text                            AS productname,
       NULL::text                                    AS productunit,
       NULL::numeric                                 AS plannedquantity,
       NULL::numeric                                 AS usedquantity,
       NULL::numeric                                 AS remainingquantity,
       NULL::numeric                                 AS doneinpercentage,
       NULL::numeric                                 AS opertaskflagpercentexecutionwithcolor,
       NULL::character varying                       AS percentageofexecutioncellcolor,
       orderproduct.number::text                     AS orderproductnumber,
       orderproduct.name::text                       AS orderproductname,
       operationaltask.actualstaff,
       NULL::numeric                                 AS wastesquantity
FROM orders_operationaltask operationaltask
         LEFT JOIN operational_task_staff ots ON operationaltask.id = ots.operationaltask_id
         LEFT JOIN basic_division division ON operationaltask.division_id = division.id
         LEFT JOIN basic_workstation workstation ON workstation.id = operationaltask.workstation_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = operationaltask.order_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationaltask.technologyoperationcomponent_id
         LEFT JOIN basic_product product ON product.id = operationaltask.product_id
         LEFT JOIN basic_product orderproduct ON orderproduct.id = ordersorder.product_id
WHERE operationaltask.type::text = '01otherCase'::text
UNION ALL
SELECT operationaltask.id,
       operationaltask.number,
       operationaltask.name,
       operationaltask.description,
       operationaltask.type,
       operationaltask.state,
       operationaltask.startdate,
       operationaltask.finishdate,
       ots.staffname,
       division.number                                                                                 AS divisionnumber,
       workstation.number                                                                              AS workstationnumber,
       workstation.id::integer                                                                         AS workstationid,
       ordersorder.id::integer                                                                         AS orderid,
       ordersorder.number                                                                              AS ordernumber,
       technologyoperationcomponent.id::integer                                                        AS tocid,
       technologyoperationcomponent.nodenumber                                                         AS technologyoperationcomponentnodenumber,
       technologyoperationcomponent.issubcontracting                                                   AS technologyoperationcomponentissubcontracting,
       product.number::text                                                                            AS productnumber,
       product.name::text                                                                              AS productname,
       product.unit::text                                                                              AS productunit,
       productioncountingquantitydto.plannedquantity,
       max(GREATEST(productioncountingquantitydto.producedquantity, 0::numeric))                       AS usedquantity,
       max(GREATEST(COALESCE(productioncountingquantitydto.plannedquantity, 0::numeric) -
                    COALESCE(productioncountingquantitydto.producedquantity, 0::numeric),
                    0::numeric))                                                                       AS remainingquantity,
       max(ceil(COALESCE(productioncountingquantitydto.producedquantity, 0::numeric) * 100::numeric /
                productioncountingquantitydto.plannedquantity))                                        AS doneinpercentage,
       max(
               CASE
                   WHEN (SELECT basic_parameter.opertaskflagpercentexecutionwithcolor
                         FROM basic_parameter
                         LIMIT 1) AND operationaltask.type::text = '02executionOperationInOrder'::text THEN 1::numeric
                   ELSE 0::numeric
                   END)                                                                                AS opertaskflagpercentexecutionwithcolor,
       max(
               CASE
                   WHEN (COALESCE(productioncountingquantitydto.producedquantity, 0::numeric) * 100::numeric /
                         productioncountingquantitydto.plannedquantity) >= 100::numeric
                       THEN 'green-cell'::character varying(255)
                   WHEN (COALESCE(productioncountingquantitydto.producedquantity, 0::numeric) * 100::numeric /
                         productioncountingquantitydto.plannedquantity) = 0::numeric
                       THEN 'red-cell'::character varying(255)
                   ELSE 'yellow-cell'::character varying(255)
                   END::text)                                                                          AS percentageofexecutioncellcolor,
       orderproduct.number::text                                                                       AS orderproductnumber,
       orderproduct.name::text                                                                         AS orderproductname,
       operationaltask.actualstaff,
       sum(COALESCE(trackingoperationproductoutcomponent.wastesquantity, 0::numeric)::numeric(14, 5))  AS wastesquantity
FROM orders_operationaltask operationaltask
         LEFT JOIN operational_task_staff ots ON operationaltask.id = ots.operationaltask_id
         LEFT JOIN basic_division division ON operationaltask.division_id = division.id
         LEFT JOIN basic_workstation workstation ON workstation.id = operationaltask.workstation_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = operationaltask.order_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationaltask.technologyoperationcomponent_id
         LEFT JOIN basic_product product ON product.id = operationaltask.product_id
         LEFT JOIN basic_product orderproduct ON orderproduct.id = ordersorder.product_id
         LEFT JOIN basicproductioncounting_productioncountingquantitydto productioncountingquantitydto
                   ON productioncountingquantitydto.orderid = ordersorder.id AND
                      productioncountingquantitydto.tocid = technologyoperationcomponent.id AND
                      productioncountingquantitydto.role::text = '02produced'::text AND
                      (productioncountingquantitydto.typeofmaterial::text = '02intermediate'::text OR
                       productioncountingquantitydto.typeofmaterial::text = '03finalProduct'::text)
         LEFT JOIN productioncounting_productiontracking productiontracking
                   ON productiontracking.order_id = ordersorder.id AND
                      productiontracking.technologyoperationcomponent_id = technologyoperationcomponent.id AND
                      productiontracking.state::text = '02accepted'::character varying::text
         LEFT JOIN productioncounting_trackingoperationproductoutcomponent trackingoperationproductoutcomponent
                   ON trackingoperationproductoutcomponent.productiontracking_id = productiontracking.id AND
                      trackingoperationproductoutcomponent.product_id = product.id
WHERE operationaltask.type::text = '02executionOperationInOrder'::text
GROUP BY operationaltask.id, operationaltask.number, operationaltask.name, operationaltask.description,
         operationaltask.type, operationaltask.state, operationaltask.startdate, operationaltask.finishdate,
         ots.staffname, division.number, workstation.number, (workstation.id::integer), (ordersorder.id::integer),
         ordersorder.number, (technologyoperationcomponent.id::integer), technologyoperationcomponent.nodenumber,
         technologyoperationcomponent.issubcontracting, (product.number::text), (product.name::text),
         (product.unit::text), productioncountingquantitydto.plannedquantity, (orderproduct.number::text),
         (orderproduct.name::text), operationaltask.actualstaff;

alter table orders_operationaltaskwithcolordto
    owner to postgres;


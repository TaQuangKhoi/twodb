create view goodfood_extrusionusedbatchingredientdto
            (id, extrusionprotocol_id, productnumber, unit, batchnumber, priority, quantity) as
SELECT row_number() OVER ()                                           AS id,
       extrusionpouring.extrusionprotocol_id,
       p.number                                                       AS productnumber,
       p.unit,
       b.number                                                       AS batchnumber,
       extrusionpouring.priority,
       sum(COALESCE(extrusionpouringingredient.quantity, 0::numeric)) AS quantity
FROM goodfood_extrusionpouringingredient extrusionpouringingredient
         JOIN goodfood_extrusionpouring extrusionpouring
              ON extrusionpouringingredient.extrusionpouring_id = extrusionpouring.id
         JOIN basic_product p ON p.id = extrusionpouringingredient.product_id
         LEFT JOIN advancedgenealogy_batch b ON b.id = extrusionpouringingredient.batch_id
GROUP BY extrusionpouring.extrusionprotocol_id, extrusionpouring.priority, p.id, b.number, b.product_id;

alter table goodfood_extrusionusedbatchingredientdto
    owner to postgres;


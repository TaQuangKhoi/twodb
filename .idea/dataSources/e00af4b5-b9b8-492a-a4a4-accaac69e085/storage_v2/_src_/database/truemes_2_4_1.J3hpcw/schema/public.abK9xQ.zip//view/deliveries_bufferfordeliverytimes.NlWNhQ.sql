create view deliveries_bufferfordeliverytimes
            (bufferfordeliverytimes, company_id, product_id, bufferfordeliverytimesfamily, companyfamily_id,
             companyproduct_id) as
SELECT _companyproduct.bufferfordeliverytimes,
       _companyproduct.company_id,
       _companyproduct.product_id,
       _companyproductsfamily.bufferfordeliverytimes AS bufferfordeliverytimesfamily,
       _companyproductsfamily.company_id             AS companyfamily_id,
       _companyproductsfamily.product_id             AS companyproduct_id
FROM basic_product product
         LEFT JOIN basic_product parent ON parent.id = product.parent_id
         LEFT JOIN deliveries_companyproduct _companyproduct ON _companyproduct.product_id = product.id
         LEFT JOIN deliveries_companyproductsfamily _companyproductsfamily
                   ON _companyproductsfamily.product_id = parent.id;

alter table deliveries_bufferfordeliverytimes
    owner to postgres;


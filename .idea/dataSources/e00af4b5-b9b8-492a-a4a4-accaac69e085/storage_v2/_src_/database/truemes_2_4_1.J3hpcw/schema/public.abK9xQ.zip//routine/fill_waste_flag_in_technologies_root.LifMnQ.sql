create function fill_waste_flag_in_technologies_root() returns void
    language plpgsql
as
$$
DECLARE
_opoc RECORD;

BEGIN
FOR _opoc IN
SELECT opoc.id, opoc.productsinputlocation_id, opoc.productsflowlocation_id
FROM technologies_operationproductoutcomponent opoc
         LEFT JOIN technologies_technologyoperationcomponent toc ON toc.id = opoc.operationcomponent_id
         LEFT JOIN technologies_technology technology ON technology.id = toc.technology_id
WHERE toc.parent_id is null AND opoc.product_id <> technology.product_id
    LOOP
UPDATE technologies_operationproductoutcomponent
set waste = true, wastereceptionwarehouse_id = COALESCE(_opoc.productsinputlocation_id, _opoc.productsflowlocation_id),
    productsinputlocation_id = null, productsflowlocation_id = null
WHERE id = _opoc.id;
END LOOP;
END;
$$;

alter function fill_waste_flag_in_technologies_root() owner to postgres;


create view ordersgroups_drafrptquantitydto(id, number, sum) as
SELECT DISTINCT ordersgroup.id,
                ordersgroup.number,
                COALESCE(sum(topoc.usedquantity), 0::numeric) AS sum
FROM productioncounting_trackingoperationproductoutcomponent topoc
         JOIN productioncounting_productiontracking pt ON pt.id = topoc.productiontracking_id
         JOIN orders_order ord ON ord.id = pt.order_id
         JOIN ordersgroups_ordersgroup ordersgroup ON ord.ordersgroup_id = ordersgroup.id
         JOIN basic_product product ON topoc.product_id = product.id
WHERE pt.state::text = '01draft'::text
GROUP BY ordersgroup.id;

alter table ordersgroups_drafrptquantitydto
    owner to postgres;


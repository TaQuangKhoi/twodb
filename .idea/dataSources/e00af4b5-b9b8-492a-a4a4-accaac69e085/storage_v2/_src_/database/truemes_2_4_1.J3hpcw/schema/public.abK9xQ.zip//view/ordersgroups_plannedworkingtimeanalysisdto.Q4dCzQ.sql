create view ordersgroups_plannedworkingtimeanalysisdto
            (id, active, company, productionlinenumber, assortmentname, number, quantity, unit, performancenorm,
             timebasedonnorms, shiftquantity, startdate, finishdate, deadline, generatorname)
as
SELECT DISTINCT ordersgroup.id,
                ordersgroup.active,
                company.number                                                                                             AS company,
                productionline.number                                                                                      AS productionlinenumber,
                assortment.name                                                                                            AS assortmentname,
                ordersgroup.number,
                ordersgroup.quantity,
                first_value(product.unit)
                OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id)                                                 AS unit,
                first_value(tpl.standardperformance)
                OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id)                                                 AS performancenorm,
                (ordersgroup.quantity * 60::numeric / first_value(tpl.standardperformance)
                                                      OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id))::integer AS timebasedonnorms,
                (ordersgroup.quantity * 60::numeric /
                 first_value(tpl.standardperformance) OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id) /
                 (8 * 60 * 60)::numeric)::numeric(14, 1)                                                                   AS shiftquantity,
                ordersgroup.startdate,
                ordersgroup.finishdate,
                masterorder.deadline,
                first_value(tcontext.number)
                OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id)                                                 AS generatorname
FROM ordersgroups_ordersgroup ordersgroup
         JOIN basic_assortment assortment ON ordersgroup.assortment_id = assortment.id
         JOIN productionlines_productionline productionline ON ordersgroup.productionline_id = productionline.id
         JOIN masterorders_masterorder masterorder ON ordersgroup.masterorder_id = masterorder.id
         LEFT JOIN basic_company company ON company.id = masterorder.company_id
         LEFT JOIN orders_order ordersorder ON ordersorder.ordersgroup_id = ordersgroup.id
         LEFT JOIN basic_product product ON ordersorder.product_id = product.id
         LEFT JOIN technologies_technology technologyprototype
                   ON ordersorder.technologyprototype_id = technologyprototype.id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext
                   ON tcontext.id = technologyprototype.generatorcontext_id
         LEFT JOIN productflowthrudivision_technologyproductionline tpl
                   ON tpl.technology_id = ordersorder.technology_id AND tpl.master
WHERE (ordersgroup.state::text = ANY
       (ARRAY ['01draft'::character varying::text, '02inProgress'::character varying::text]))
  AND ordersorder.remainingamountofproducttoproduce <> 0::numeric
UNION ALL
SELECT DISTINCT ordersgroup.id,
                ordersgroup.active,
                company.number                                                                                             AS company,
                productionline.number                                                                                      AS productionlinenumber,
                assortment.name                                                                                            AS assortmentname,
                ordersgroup.number,
                ordersgroup.quantity,
                first_value(product.unit)
                OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id)                                                 AS unit,
                first_value(tpl.standardperformance)
                OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id)                                                 AS performancenorm,
                (ordersgroup.quantity * 60::numeric / first_value(tpl.standardperformance)
                                                      OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id))::integer AS timebasedonnorms,
                (ordersgroup.quantity * 60::numeric /
                 first_value(tpl.standardperformance) OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id) /
                 (8 * 60 * 60)::numeric)::numeric(14, 1)                                                                   AS shiftquantity,
                ordersgroup.startdate,
                ordersgroup.finishdate,
                masterorder.deadline,
                first_value(tcontext.number)
                OVER (PARTITION BY ordersgroup.id ORDER BY ordersorder.id)                                                 AS generatorname
FROM arch_ordersgroups_ordersgroup ordersgroup
         JOIN basic_assortment assortment ON ordersgroup.assortment_id = assortment.id
         JOIN productionlines_productionline productionline ON ordersgroup.productionline_id = productionline.id
         JOIN arch_masterorders_masterorder masterorder ON ordersgroup.masterorder_id = masterorder.id
         LEFT JOIN basic_company company ON company.id = masterorder.company_id
         LEFT JOIN orders_order ordersorder ON ordersorder.ordersgroup_id = ordersgroup.id
         LEFT JOIN basic_product product ON ordersorder.product_id = product.id
         LEFT JOIN technologies_technology technologyprototype
                   ON ordersorder.technologyprototype_id = technologyprototype.id
         LEFT JOIN technologiesgenerator_generatorcontext tcontext
                   ON tcontext.id = technologyprototype.generatorcontext_id
         LEFT JOIN productflowthrudivision_technologyproductionline tpl
                   ON tpl.technology_id = ordersorder.technology_id AND tpl.master
WHERE (ordersgroup.state::text = ANY
       (ARRAY ['01draft'::character varying::text, '02inProgress'::character varying::text]))
  AND ordersorder.remainingamountofproducttoproduce <> 0::numeric;

alter table ordersgroups_plannedworkingtimeanalysisdto
    owner to postgres;


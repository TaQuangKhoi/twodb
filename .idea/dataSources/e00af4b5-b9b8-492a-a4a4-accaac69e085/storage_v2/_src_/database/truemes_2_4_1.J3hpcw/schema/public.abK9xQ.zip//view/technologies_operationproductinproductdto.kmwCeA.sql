create view technologies_operationproductinproductdto
            (id, operationproductincomponentid, product_id, productid, nodenumber, technologyid, technologyname,
             technologystate, technologynumber, operationname, quantity, mastertechnology, operationcomponentid,
             technologytype, activetechnology, sizeproduct, productbysizegroupid, modelname, assortmentname,
             productnumber, technologyproductnumber)
as
SELECT technologies_operationproductincomponentdto.id,
       technologies_operationproductincomponentdto.id::integer AS operationproductincomponentid,
       technologies_operationproductincomponentdto.product_id,
       technologies_operationproductincomponentdto.productid,
       technologies_operationproductincomponentdto.nodenumber,
       technologies_operationproductincomponentdto.technologyid,
       technologies_operationproductincomponentdto.technologyname,
       technologies_operationproductincomponentdto.technologystate,
       technologies_operationproductincomponentdto.technologynumber,
       technologies_operationproductincomponentdto.operationname,
       technologies_operationproductincomponentdto.quantity,
       technologies_operationproductincomponentdto.mastertechnology,
       technologies_operationproductincomponentdto.operationcomponentid,
       technologies_operationproductincomponentdto.technologytype,
       technologies_operationproductincomponentdto.activetechnology,
       false                                                   AS sizeproduct,
       NULL::integer                                           AS productbysizegroupid,
       technologies_operationproductincomponentdto.modelname,
       technologies_operationproductincomponentdto.assortmentname,
       technologies_operationproductincomponentdto.productnumber,
       technologies_operationproductincomponentdto.technologyproductnumber
FROM technologies_operationproductincomponentdto
UNION ALL
SELECT 10000000 + productbysizegroup.id         AS id,
       operationproductincomponent.id::integer  AS operationproductincomponentid,
       product.id                               AS product_id,
       product.id::integer                      AS productid,
       technologyoperationcomponent.nodenumber,
       technology.id::integer                   AS technologyid,
       technology.name                          AS technologyname,
       technology.state                         AS technologystate,
       technology.number                        AS technologynumber,
       operation.name                           AS operationname,
       operationproductincomponent.quantity,
       technology.master                        AS mastertechnology,
       technologyoperationcomponent.id::integer AS operationcomponentid,
       technology.technologytype,
       technology.active                        AS activetechnology,
       true                                     AS sizeproduct,
       productbysizegroup.id::integer           AS productbysizegroupid,
       model.name                               AS modelname,
       assortment.name                          AS assortmentname,
       product.number                           AS productnumber,
       technology_product.number                AS technologyproductnumber
FROM technologies_productbysizegroup productbysizegroup
         LEFT JOIN technologies_operationproductincomponent operationproductincomponent
                   ON operationproductincomponent.id = productbysizegroup.operationproductincomponent_id
         LEFT JOIN technologies_technologyoperationcomponent technologyoperationcomponent
                   ON technologyoperationcomponent.id = operationproductincomponent.operationcomponent_id
         LEFT JOIN technologies_operation operation ON operation.id = technologyoperationcomponent.operation_id
         LEFT JOIN basic_product product ON product.id = productbysizegroup.product_id
         LEFT JOIN technologies_technology technology ON technology.id = technologyoperationcomponent.technology_id
         LEFT JOIN basic_product technology_product ON technology_product.id = technology.product_id
         LEFT JOIN basic_model model ON model.id = technology_product.model_id
         LEFT JOIN basic_assortment assortment ON assortment.id = technology_product.assortment_id
         LEFT JOIN technologies_technologyinputproducttype technologyinputproducttype
                   ON technologyinputproducttype.id = operationproductincomponent.technologyinputproducttype_id
GROUP BY productbysizegroup.id, operationproductincomponent.id, technologyoperationcomponent.id, product.id,
         product.number, product.name, product.unit, operationproductincomponent.quantity,
         operationproductincomponent.priority, operationproductincomponent.itemnumberintheexplodedview, technology.name,
         technology.number, technology.state, technology.master, operation.name, technology.active,
         technology.technologytype, technology.id, technologyinputproducttype.name, technology_product.number,
         model.name, assortment.name;

alter table technologies_operationproductinproductdto
    owner to postgres;


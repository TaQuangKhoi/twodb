create view linechangeovernorms_normflatview
            (number, name, duration, changeovertype, productionlineid, technnolgyfromid, technologytoid,
             technologyfromnumber, technologytonumber)
as
SELECT groupnorms.number,
       groupnorms.name,
       groupnorms.duration,
       groupnorms.changeovertype,
       groupnorms.productionlineid,
       groupnorms.technologyfromid AS technnolgyfromid,
       groupnorms.technologytoid,
       groupnorms.technologyfromnumber,
       groupnorms.technologytonumber
FROM linechangeovernorms_groupsview groupnorms
WHERE groupnorms.technologyfromid IS NOT NULL
  AND groupnorms.technologytoid IS NOT NULL
UNION ALL
SELECT norms.number,
       norms.name,
       norms.duration,
       norms.changeovertype,
       norms.productionline_id AS productionlineid,
       norms.fromtechnology_id AS technnolgyfromid,
       norms.totechnology_id   AS technologytoid,
       technologyfrom.number   AS technologyfromnumber,
       technologyto.number     AS technologytonumber
FROM linechangeovernorms_linechangeovernorms norms
         LEFT JOIN technologies_technology technologyfrom ON technologyfrom.id = norms.fromtechnology_id
         LEFT JOIN technologies_technology technologyto ON technologyto.id = norms.totechnology_id
WHERE norms.changeovertype::text = '01forTechnology'::text
  AND norms.fromtechnology_id IS NOT NULL
  AND norms.totechnology_id IS NOT NULL;

alter table linechangeovernorms_normflatview
    owner to postgres;


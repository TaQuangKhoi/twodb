create view basicproductioncounting_productioncountingquantitydto
            (id, orderid, productid, productnumber, productname, productunit, tocid, nodenumber, operationnumber,
             operationname, role, typeofmaterial, plannedquantity, usedquantity, producedquantity, replacementto,
             technologyinputproducttypename, replacement)
as
SELECT pcq.id,
       pcq.order_id::integer                           AS orderid,
       product.id::integer                             AS productid,
       product.number                                  AS productnumber,
       product.name                                    AS productname,
       product.unit                                    AS productunit,
       toc.id                                          AS tocid,
       COALESCE(toc.nodenumber, ''::character varying) AS nodenumber,
       COALESCE(op.number, ''::character varying)      AS operationnumber,
       COALESCE(op.name, ''::character varying)        AS operationname,
       pcq.role,
       pcq.typeofmaterial,
       pcq.plannedquantity,
       COALESCE(pcq.usedquantity, 0::numeric)          AS usedquantity,
       COALESCE(pcq.producedquantity, 0::numeric)      AS producedquantity,
       replacementto.number                            AS replacementto,
       tipt.name                                       AS technologyinputproducttypename,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM basic_substitutecomponent
                  WHERE basic_substitutecomponent.baseproduct_id = product.id)) > 0 THEN true
           ELSE false
           END                                         AS replacement
FROM basicproductioncounting_productioncountingquantity pcq
         JOIN basic_product product ON product.id = pcq.product_id
         JOIN orders_order o ON o.id = pcq.order_id
         LEFT JOIN basic_product replacementto ON replacementto.id = pcq.replacementto_id
         LEFT JOIN technologies_technologyoperationcomponent toc ON pcq.technologyoperationcomponent_id = toc.id
         LEFT JOIN technologies_operation op ON op.id = toc.operation_id
         LEFT JOIN technologies_technologyinputproducttype tipt ON tipt.id = pcq.technologyinputproducttype_id
WHERE o.typeofproductionrecording::text = '02cumulated'::text
UNION
SELECT pcq.id,
       pcq.order_id::integer                      AS orderid,
       product.id::integer                        AS productid,
       product.number                             AS productnumber,
       product.name                               AS productname,
       product.unit                               AS productunit,
       toc.id                                     AS tocid,
       toc.nodenumber,
       op.number                                  AS operationnumber,
       op.name                                    AS operationname,
       pcq.role,
       pcq.typeofmaterial,
       pcq.plannedquantity,
       COALESCE(pcq.usedquantity, 0::numeric)     AS usedquantity,
       COALESCE(pcq.producedquantity, 0::numeric) AS producedquantity,
       replacementto.number                       AS replacementto,
       tipt.name                                  AS technologyinputproducttypename,
       CASE
           WHEN ((SELECT count(*) AS count
                  FROM basic_substitutecomponent
                  WHERE basic_substitutecomponent.baseproduct_id = product.id)) > 0 THEN true
           ELSE false
           END                                    AS replacement
FROM basicproductioncounting_productioncountingquantity pcq
         JOIN basic_product product ON product.id = pcq.product_id
         JOIN orders_order o ON o.id = pcq.order_id
         JOIN technologies_technologyoperationcomponent toc ON pcq.technologyoperationcomponent_id = toc.id
         JOIN technologies_operation op ON op.id = toc.operation_id
         LEFT JOIN basic_product replacementto ON replacementto.id = pcq.replacementto_id
         LEFT JOIN technologies_technologyinputproducttype tipt ON tipt.id = pcq.technologyinputproducttype_id
WHERE o.typeofproductionrecording::text = '03forEach'::text;

alter table basicproductioncounting_productioncountingquantitydto
    owner to postgres;


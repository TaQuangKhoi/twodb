create function add_group_with_role_role(with_role_identifier character varying, role_identifier character varying) returns void
    language plpgsql
as
$$
    DECLARE
        withroleid bigint;
        roleid bigint;
        groupwithrole RECORD;

    BEGIN
        SELECT id INTO withroleid FROM qcadoosecurity_role WHERE identifier = with_role_identifier;

        IF withroleid IS NULL THEN
            RAISE EXCEPTION 'Role(%) not found', with_role_identifier;
        END IF;

        SELECT id INTO roleid FROM qcadoosecurity_role WHERE identifier = role_identifier;

        IF roleid IS NULL THEN
            RAISE EXCEPTION 'Role(%) not found', role_identifier;
        END IF;

        FOR groupwithrole IN SELECT * FROM jointable_group_role WHERE role_id = withroleid LOOP
            IF NOT EXISTS (SELECT group_id FROM jointable_group_role WHERE group_id = groupwithrole.group_id AND role_id = roleid) THEN
                INSERT INTO jointable_group_role (group_id, role_id) VALUES (groupwithrole.group_id, roleid);
            END IF;
        END LOOP;
    END;
$$;

alter function add_group_with_role_role(varchar, varchar) owner to postgres;


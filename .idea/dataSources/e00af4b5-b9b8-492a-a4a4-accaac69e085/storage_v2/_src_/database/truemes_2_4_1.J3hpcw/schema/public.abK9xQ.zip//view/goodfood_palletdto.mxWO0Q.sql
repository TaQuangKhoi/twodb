create view goodfood_palletdto
            (id, registrationdate, senddate, palletcontextday, palletcontextshiftname, palletcontextoperatorname,
             palletcontextoperatorsurname, productionlinenumber, masterordernumber, productnumber, ssccnumber,
             palletnumber, secondpalletnumber, numberofpallets, state, laststatechangefails, active)
as
WITH orders_orderproduct AS (SELECT orders_order.masterorder_id,
                                    sum(orders_order.plannedquantity) AS orderquantity
                             FROM orders_order
                             WHERE orders_order.masterorder_id IS NOT NULL
                             GROUP BY orders_order.masterorder_id)
SELECT pallet.id,
       pallet.registrationdate,
       pallet.senddate,
       palletcontext.day         AS palletcontextday,
       shift.name                AS palletcontextshiftname,
       staff.name                AS palletcontextoperatorname,
       staff.surname             AS palletcontextoperatorsurname,
       productionline.number     AS productionlinenumber,
       masterorder.number        AS masterordernumber,
       product.number            AS productnumber,
       pallet.ssccnumber,
       pallet.palletnumber,
       secondpallet.palletnumber AS secondpalletnumber,
       CASE
           WHEN orderproduct.masterorder_id IS NULL THEN
               (row_number() OVER (PARTITION BY masterorder.id ORDER BY pallet.id) || ' z '::text) ||
               ceiling(masterorderproduct.masterorderquantity / unitconversionitem.quantityfrom)::integer
           ELSE (row_number() OVER (PARTITION BY masterorder.id ORDER BY pallet.id) || ' z '::text) ||
                ceiling(orderproduct.orderquantity / unitconversionitem.quantityfrom)::integer
           END                   AS numberofpallets,
       pallet.state,
       pallet.laststatechangefails,
       pallet.active
FROM goodfood_pallet pallet
         LEFT JOIN goodfood_pallet secondpallet ON secondpallet.id = pallet.secondpallet_id
         LEFT JOIN goodfood_palletcontext palletcontext ON palletcontext.id = pallet.palletcontext_id
         LEFT JOIN goodfood_palletlabel palletlabel ON palletlabel.id = pallet.palletlabel_id
         LEFT JOIN basic_shift shift ON shift.id = palletcontext.shift_id
         LEFT JOIN basic_staff staff ON staff.id = palletcontext.operator_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = palletlabel.productionline_id
         LEFT JOIN masterorders_masterorder masterorder ON masterorder.id = palletlabel.masterorder_id
         LEFT JOIN masterorders_masterorderproduct masterorderproduct
                   ON masterorderproduct.masterorder_id = masterorder.id
         LEFT JOIN orders_orderproduct orderproduct ON orderproduct.masterorder_id = masterorder.id
         LEFT JOIN basic_product product ON product.id = masterorderproduct.product_id
         LEFT JOIN qcadoomodel_unitconversionitem unitconversionitem ON unitconversionitem.product_id = product.id AND
                                                                        unitconversionitem.unitfrom::text =
                                                                        'szt.'::text AND
                                                                        unitconversionitem.unitto::text =
                                                                        'paleta'::text;

alter table goodfood_palletdto
    owner to postgres;


create function update_reported_quantity() returns void
    language plpgsql
as
$$
    DECLARE
        _order RECORD;
    BEGIN
        FOR _order IN SELECT id FROM orders_order AS o WHERE o.state = '03inProgress' ORDER BY id LOOP
            UPDATE orders_order ordersorder
			SET reportedProductionQuantity = productioncountingproducedquantitydrafts.producedquantity
			FROM (SELECT * FROM ordersupplies_productioncountingproducedquantitydrafts) AS productioncountingproducedquantitydrafts
			WHERE ordersorder.id = _order.id AND ordersorder.id = productioncountingproducedquantitydrafts.order_id AND ordersorder.product_id = productioncountingproducedquantitydrafts.order_product_id;
        END LOOP;
    END;
$$;

alter function update_reported_quantity() owner to postgres;


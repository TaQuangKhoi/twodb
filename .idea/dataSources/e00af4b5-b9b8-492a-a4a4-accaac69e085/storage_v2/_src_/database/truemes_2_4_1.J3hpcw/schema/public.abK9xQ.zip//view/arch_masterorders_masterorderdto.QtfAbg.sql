create view arch_masterorders_masterorderdto
            (id, masterorderdefinitionnumber, number, name, deadline, company, companypayer, orderedpositionquantity,
             commissionedpositionquantity, quantityforcommission, masterorderstate, active, pipedriveupdate, state,
             externalnumber, asanataskid, description)
as
SELECT arch_mv_masterorders_masterorderdto.id,
       arch_mv_masterorders_masterorderdto.masterorderdefinitionnumber,
       arch_mv_masterorders_masterorderdto.number,
       arch_mv_masterorders_masterorderdto.name,
       arch_mv_masterorders_masterorderdto.deadline,
       arch_mv_masterorders_masterorderdto.company,
       arch_mv_masterorders_masterorderdto.companypayer,
       arch_mv_masterorders_masterorderdto.orderedpositionquantity,
       arch_mv_masterorders_masterorderdto.commissionedpositionquantity,
       arch_mv_masterorders_masterorderdto.quantityforcommission,
       arch_mv_masterorders_masterorderdto.masterorderstate,
       arch_mv_masterorders_masterorderdto.active,
       arch_mv_masterorders_masterorderdto.pipedriveupdate,
       arch_mv_masterorders_masterorderdto.state,
       arch_mv_masterorders_masterorderdto.externalnumber,
       arch_mv_masterorders_masterorderdto.asanataskid,
       arch_mv_masterorders_masterorderdto.description
FROM arch_mv_masterorders_masterorderdto;

alter table arch_masterorders_masterorderdto
    owner to postgres;


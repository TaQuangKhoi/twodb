create view masterorders_salesplanproductdto
            (id, salesplanid, salesplan_id, productnumber, productname, productentitytype, productassortment,
             productfamily, productmodel, productunit, technologynumber, plannedquantity, orderedquantity,
             surplusfromplan, ordersplannedquantity, orderedtowarehouse)
as
SELECT spp.id,
       spp.salesplan_id::integer AS salesplanid,
       spp.salesplan_id,
       p.number                  AS productnumber,
       p.name                    AS productname,
       p.entitytype              AS productentitytype,
       assortment.name           AS productassortment,
       family.number             AS productfamily,
       model.name                AS productmodel,
       p.unit                    AS productunit,
       t.number                  AS technologynumber,
       spp.plannedquantity,
       spp.orderedquantity,
       spp.surplusfromplan,
       CASE
           WHEN p.entitytype::text = '01particularProduct'::text THEN COALESCE((SELECT sum(sppp.plannedquantity) AS sum
                                                                                FROM masterorders_salesplanpalnnedproductdto sppp
                                                                                WHERE sppp.salesplanid = spp.salesplan_id
                                                                                  AND sppp.productid = p.id),
                                                                               0::numeric)
           ELSE COALESCE((SELECT sum(sppp.plannedquantity) AS sum
                          FROM masterorders_salesplanpalnnedproductdto sppp
                          WHERE sppp.salesplanid = spp.salesplan_id
                            AND (sppp.productid IN (SELECT prod.id
                                                    FROM basic_product prod
                                                    WHERE prod.parent_id = p.id))), 0::numeric)
           END                   AS ordersplannedquantity,
       spp.orderedtowarehouse
FROM masterorders_salesplanproduct spp
         JOIN basic_product p ON spp.product_id = p.id
         LEFT JOIN basic_assortment assortment ON p.assortment_id = assortment.id
         LEFT JOIN basic_model model ON p.model_id = model.id
         LEFT JOIN technologies_technology t ON t.id = spp.technology_id
         LEFT JOIN basic_product family ON p.parent_id = family.id;

alter table masterorders_salesplanproductdto
    owner to postgres;


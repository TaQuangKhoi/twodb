create view orders_orderplanninglistdto
            (id, active, number, name, datefrom, dateto, startdate, finishdate, state, externalnumber,
             externalsynchronized, issubcontracted, plannedquantity, workplandelivered, ordercategory,
             amountofproductproduced, wastesquantity, remainingamountofproducttoproduce, productnumber,
             technologynumber, unit, productionlinenumber, masterordernumber, divisionname, divisionnumber,
             plannedquantityforadditionalunit, unitforadditionalunit, company, description, productname, annotation,
             doneinpercentage, flagpercentageofexecutionwithcolor, percentageofexecutioncellcolor, deadline,
             daystodeadline, haspacks, salesplannumber)
as
WITH order_packs AS (SELECT order_1.id          AS orderid,
                            count(pack.id) <> 0 AS haspacks
                     FROM orders_order order_1
                              LEFT JOIN orders_orderpack pack ON pack.order_id = order_1.id
                     GROUP BY order_1.id)
SELECT ordersorder.id,
       ordersorder.active,
       ordersorder.number,
       ordersorder.name,
       ordersorder.datefrom,
       ordersorder.dateto,
       ordersorder.startdate,
       ordersorder.finishdate,
       ordersorder.state,
       ordersorder.externalnumber,
       ordersorder.externalsynchronized,
       ordersorder.issubcontracted,
       ordersorder.plannedquantity,
       ordersorder.workplandelivered,
       ordersorder.ordercategory,
       COALESCE(ordersorder.amountofproductproduced, 0::numeric)                                 AS amountofproductproduced,
       COALESCE(ordersorder.wastesquantity, 0::numeric)                                          AS wastesquantity,
       GREATEST(COALESCE(ordersorder.remainingamountofproducttoproduce, 0::numeric),
                0::numeric)                                                                      AS remainingamountofproducttoproduce,
       product.number                                                                            AS productnumber,
       technology.number                                                                         AS technologynumber,
       product.unit,
       productionline.number                                                                     AS productionlinenumber,
       masterorder.number                                                                        AS masterordernumber,
       division.name                                                                             AS divisionname,
       division.number                                                                           AS divisionnumber,
       COALESCE(ordersorder.plannedquantityforadditionalunit,
                ordersorder.plannedquantity)                                                     AS plannedquantityforadditionalunit,
       COALESCE(product.additionalunit, product.unit)                                            AS unitforadditionalunit,
       company.number                                                                            AS company,
       ordersorder.description,
       product.name                                                                              AS productname,
       ''::character varying(255)                                                                AS annotation,
       ceil(COALESCE(ordersorder.donequantity, 0::numeric) * 100::numeric /
            NULLIF(ordersorder.plannedquantity, 0::numeric))                                     AS doneinpercentage,
       CASE
           WHEN (SELECT basic_parameter.flagpercentageofexecutionwithcolor
                 FROM basic_parameter
                 LIMIT 1) THEN 1::numeric
           ELSE 0::numeric
           END                                                                                   AS flagpercentageofexecutionwithcolor,
       CASE
           WHEN (COALESCE(ordersorder.donequantity, 0::numeric) * 100::numeric /
                 NULLIF(ordersorder.plannedquantity, 0::numeric)) >= 100::numeric
               THEN 'green-cell'::character varying(255)
           WHEN (COALESCE(ordersorder.donequantity, 0::numeric) * 100::numeric /
                 NULLIF(ordersorder.plannedquantity, 0::numeric)) = 0::numeric THEN 'red-cell'::character varying(255)
           ELSE 'yellow-cell'::character varying(255)
           END                                                                                   AS percentageofexecutioncellcolor,
       ordersorder.deadline,
       date_part('day'::text, date_trunc('day'::text, ordersorder.deadline) -
                              'now'::text::date::timestamp without time zone)::integer           AS daystodeadline,
       packs.haspacks,
       salesplan.number                                                                          AS salesplannumber
FROM orders_order ordersorder
         JOIN basic_product product ON product.id = ordersorder.product_id
         LEFT JOIN technologies_technology technology ON technology.id = ordersorder.technology_id
         LEFT JOIN productionlines_productionline productionline ON productionline.id = ordersorder.productionline_id
         LEFT JOIN masterorders_masterorder masterorder ON masterorder.id = ordersorder.masterorder_id
         LEFT JOIN basic_division division ON division.id = ordersorder.division_id
         LEFT JOIN basic_company company ON company.id = ordersorder.company_id
         LEFT JOIN order_packs packs ON packs.orderid = ordersorder.id
         LEFT JOIN masterorders_salesplan salesplan ON salesplan.id = ordersorder.salesplan_id;

alter table orders_orderplanninglistdto
    owner to postgres;


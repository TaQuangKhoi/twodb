create view productioncounting_productiontrackingforproductgroupeddto
            (id, active, order_id, ordernumber, orderstartdate, technologyoperationcomponent_id,
             technologyoperationcomponentnumber, operation_id, product_id, productnumber, productname, productunit,
             plannedquantity, usedquantity, quantitydeviation, typeofrecord)
as
SELECT row_number() OVER ()                                                                                AS id,
       productiontrackingforproductdto.active,
       productiontrackingforproductdto.order_id,
       productiontrackingforproductdto.ordernumber,
       productiontrackingforproductdto.orderstartdate::date                                                AS orderstartdate,
       productiontrackingforproductdto.technologyoperationcomponent_id,
       productiontrackingforproductdto.technologyoperationcomponentnumber,
       productiontrackingforproductdto.operation_id,
       productiontrackingforproductdto.product_id,
       productiontrackingforproductdto.productnumber,
       productiontrackingforproductdto.productname,
       productiontrackingforproductdto.productunit,
       productiontrackingforproductdto.plannedquantity,
       sum(productiontrackingforproductdto.usedquantity)                                                   AS usedquantity,
       sum(productiontrackingforproductdto.usedquantity) -
       productiontrackingforproductdto.plannedquantity                                                     AS quantitydeviation,
       productiontrackingforproductdto.typeofrecord
FROM productioncounting_productiontrackingforproductdto productiontrackingforproductdto
GROUP BY productiontrackingforproductdto.active, productiontrackingforproductdto.order_id,
         productiontrackingforproductdto.ordernumber, productiontrackingforproductdto.orderstartdate,
         productiontrackingforproductdto.technologyoperationcomponent_id,
         productiontrackingforproductdto.technologyoperationcomponentnumber,
         productiontrackingforproductdto.operation_id, productiontrackingforproductdto.product_id,
         productiontrackingforproductdto.productnumber, productiontrackingforproductdto.productname,
         productiontrackingforproductdto.productunit, productiontrackingforproductdto.plannedquantity,
         productiontrackingforproductdto.typeofrecord;

alter table productioncounting_productiontrackingforproductgroupeddto
    owner to postgres;


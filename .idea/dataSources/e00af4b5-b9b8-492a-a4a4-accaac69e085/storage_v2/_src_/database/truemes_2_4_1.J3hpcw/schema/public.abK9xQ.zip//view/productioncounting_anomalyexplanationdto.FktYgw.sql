create view productioncounting_anomalyexplanationdto
            (id, usedquantity, description, createuser, createdate, anomalyid, productnumber, productname,
             locationnumber, productunit)
as
SELECT anomalyexplanation.id,
       anomalyexplanation.usedquantity,
       anomalyexplanation.description,
       anomalyexplanation.createuser,
       anomalyexplanation.createdate,
       anomaly.id::integer          AS anomalyid,
       product.number               AS productnumber,
       product.name                 AS productname,
       materialflow_location.number AS locationnumber,
       CASE
           WHEN anomalyexplanation.usewaste THEN anomalyexplanation.givenunit
           ELSE product.unit
           END                      AS productunit
FROM productioncounting_anomalyexplanation anomalyexplanation
         JOIN productioncounting_anomaly anomaly ON anomaly.id = anomalyexplanation.anomaly_id
         LEFT JOIN basic_product product ON product.id = anomalyexplanation.product_id
         LEFT JOIN materialflow_location ON materialflow_location.id = anomalyexplanation.location_id;

alter table productioncounting_anomalyexplanationdto
    owner to postgres;


create view goodfood_extrusionbatchingredientdto(id, extrusionprotocol_id, productnumber, unit, batchnumber, quantity) as
WITH ingredients AS (SELECT e.extrusionprotocol_id,
                            i_1.product_id,
                            i_1.batch_id,
                            i_1.quantity
                     FROM goodfood_extrusionaddedmixingredient i_1
                              JOIN goodfood_extrusionaddedmixentry e ON i_1.extrusionaddedmixentry_id = e.id
                     UNION ALL
                     SELECT e.extrusionprotocol_id,
                            i_1.product_id,
                            i_1.batch_id,
                            - i_1.quantity
                     FROM goodfood_extrusiontakenoffmixingredient i_1
                              JOIN goodfood_extrusiontakenoffmixentry e ON i_1.extrusiontakenoffmixentry_id = e.id
                     UNION ALL
                     SELECT e.extrusionprotocol_id,
                            i_1.product_id,
                            i_1.batch_id,
                            i_1.quantity
                     FROM goodfood_extrusionpouringingredient i_1
                              JOIN goodfood_extrusionpouring e ON i_1.extrusionpouring_id = e.id)
SELECT row_number() OVER ()                  AS id,
       i.extrusionprotocol_id,
       p.number                              AS productnumber,
       p.unit,
       b.number                              AS batchnumber,
       sum(COALESCE(i.quantity, 0::numeric)) AS quantity
FROM ingredients i
         JOIN basic_product p ON p.id = i.product_id
         LEFT JOIN advancedgenealogy_batch b ON b.id = i.batch_id
GROUP BY i.extrusionprotocol_id, p.id, b.number, b.product_id;

alter table goodfood_extrusionbatchingredientdto
    owner to postgres;


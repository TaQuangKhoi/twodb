create function f_drop_tab(_tabname text) returns boolean
    language plpgsql
as
$$
    BEGIN
        EXECUTE format('DROP TABLE IF EXISTS %s', _tabname);

        RETURN TRUE;
    END
$$;

alter function f_drop_tab(text) owner to postgres;


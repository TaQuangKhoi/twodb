create view technologies_operationtechnologydto
            (id, technologyid, nodenumber, comment, technologynumber, technologyname, technologystate, mastertechnology,
             technologytype, activetechnology, technologyproductnumber, operationid, operation_id)
as
SELECT toc.id,
       toc.technology_id::integer AS technologyid,
       toc.nodenumber,
       toc.comment,
       t.number                   AS technologynumber,
       t.name                     AS technologyname,
       t.state                    AS technologystate,
       t.master                   AS mastertechnology,
       t.technologytype,
       t.active                   AS activetechnology,
       p.number                   AS technologyproductnumber,
       toc.operation_id::integer  AS operationid,
       toc.operation_id
FROM technologies_technologyoperationcomponent toc
         JOIN technologies_technology t ON toc.technology_id = t.id
         JOIN basic_product p ON p.id = t.product_id;

alter table technologies_operationtechnologydto
    owner to postgres;


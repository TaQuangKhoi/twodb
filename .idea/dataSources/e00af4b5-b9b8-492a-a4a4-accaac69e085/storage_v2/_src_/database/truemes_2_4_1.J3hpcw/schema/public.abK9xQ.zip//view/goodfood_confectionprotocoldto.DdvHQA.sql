create view goodfood_confectionprotocoldto
            (id, active, number, dayofshiftstart, confectioncontextshift, confectioncontextplace, productionlinenumber,
             productionlinename, ordernumber, qcp5code, confectioncontextoperatorname, confectioncontextoperatorsurname,
             state, iscorrected, generationdate)
as
SELECT cp.id,
       cp.active,
       cp.number,
       cp.dayofshiftstart,
       shift.name              AS confectioncontextshift,
       confectioncontext.place AS confectioncontextplace,
       productionline.number   AS productionlinenumber,
       productionline.name     AS productionlinename,
       o.number                AS ordernumber,
       cp.qcp5code,
       staff.name              AS confectioncontextoperatorname,
       staff.surname           AS confectioncontextoperatorsurname,
       cp.state,
       cp.iscorrected,
       cp.generationdate
FROM goodfood_confectionprotocol cp
         JOIN productionlines_productionline productionline ON cp.productionline_id = productionline.id
         JOIN orders_order o ON cp.order_id = o.id
         LEFT JOIN goodfood_confectioncontext confectioncontext ON cp.confectioncontext_id = confectioncontext.id
         LEFT JOIN basic_shift shift ON confectioncontext.shift_id = shift.id
         LEFT JOIN basic_staff staff ON confectioncontext.operator_id = staff.id;

alter table goodfood_confectionprotocoldto
    owner to postgres;


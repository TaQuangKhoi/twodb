create view materialflowresources_resourcedto
            (id, number, quantity, quantityinadditionalunit, locationnumber, productnumber, productname,
             productglobaltypeofmaterial, productunit, givenunit, conversion, reservedquantity, availablequantity,
             price, value, time, productiondate, expirationdate, batchnumber, storagelocationnumber, additionalcode,
             palletnumber, typeofpallet, username, iscorrected, waste, deliverynumber,
             mergedproductnumberandadditionalcode, location_id, positionaddmultihelper_id, documentnumber,
             qualityrating, blockedforqualitycontrol, suppliernumber, colorresourcesafterdeadline,
             expirationdatecellcolor)
as
SELECT resource.id,
       resource.number,
       resource.quantity,
       resource.quantityinadditionalunit,
       location.number                                     AS locationnumber,
       product.number                                      AS productnumber,
       product.name                                        AS productname,
       product.globaltypeofmaterial                        AS productglobaltypeofmaterial,
       product.unit                                        AS productunit,
       resource.givenunit,
       resource.conversion,
       resource.reservedquantity,
       resource.availablequantity,
       resource.price,
       resource.quantity * resource.price                  AS value,
       resource."time",
       resource.productiondate,
       resource.expirationdate,
       batch.number                                        AS batchnumber,
       storagelocation.number                              AS storagelocationnumber,
       additionalcode.code                                 AS additionalcode,
       palletnumber.number                                 AS palletnumber,
       resource.typeofpallet,
       resource.username,
       resource.iscorrected,
       resource.waste,
       resource.deliverynumber,
       product.number::text ||
       CASE
           WHEN additionalcode.code IS NULL THEN ''::text
           ELSE ' - '::text || additionalcode.code::text
           END                                             AS mergedproductnumberandadditionalcode,
       resource.location_id::integer                       AS location_id,
       NULL::bigint                                        AS positionaddmultihelper_id,
       resource.documentnumber,
       resource.qualityrating,
       resource.blockedforqualitycontrol,
       COALESCE(supplier.number, document_supplier.number) AS suppliernumber,
       CASE
           WHEN (SELECT materialflowresources_documentpositionparameters.colorresourcesafterdeadline
                 FROM materialflowresources_documentpositionparameters
                 LIMIT 1) THEN 1::numeric
           ELSE 0::numeric
           END                                             AS colorresourcesafterdeadline,
       CASE
           WHEN resource.expirationdate < 'now'::text::date THEN 'red-cell'::character varying(255)
           WHEN (SELECT materialflowresources_documentpositionparameters.shortexpirydate IS NOT NULL
                 FROM materialflowresources_documentpositionparameters
                 LIMIT 1) AND resource.expirationdate >= 'now'::text::date AND resource.expirationdate <=
                                                                               ('now'::text::date +
                                                                                ((SELECT materialflowresources_documentpositionparameters.shortexpirydate
                                                                                  FROM materialflowresources_documentpositionparameters
                                                                                  LIMIT 1))::double precision *
                                                                                '1 day'::interval)
               THEN 'orange-cell'::character varying(255)
           ELSE NULL::character varying
           END                                             AS expirationdatecellcolor
FROM materialflowresources_resource resource
         JOIN materialflow_location location ON location.id = resource.location_id
         JOIN basic_product product ON product.id = resource.product_id
         LEFT JOIN basic_additionalcode additionalcode ON additionalcode.id = resource.additionalcode_id
         LEFT JOIN basic_palletnumber palletnumber ON palletnumber.id = resource.palletnumber_id
         LEFT JOIN materialflowresources_storagelocation storagelocation
                   ON storagelocation.id = resource.storagelocation_id
         LEFT JOIN advancedgenealogy_batch batch ON batch.id = resource.batch_id
         LEFT JOIN deliveries_delivery delivery ON delivery.number::text = resource.deliverynumber::text
         LEFT JOIN basic_company supplier ON delivery.supplier_id = supplier.id
         LEFT JOIN materialflowresources_document document ON document.number::text = resource.documentnumber::text
         LEFT JOIN basic_company document_supplier ON document.company_id = document_supplier.id;

alter table materialflowresources_resourcedto
    owner to postgres;


create view basic_attachmentdto
            (pinnedto, pinnedtoobjectidentifier, pinnedtoobjectidentifiername, pinnedtoobjectid, pinnedtomodelname,
             attachment, name, size, ext, id, pinnedtocorrespondingview)
as
SELECT '01products'::text                 AS pinnedto,
       product.number                     AS pinnedtoobjectidentifier,
       product.name                       AS pinnedtoobjectidentifiername,
       product.id::integer                AS pinnedtoobjectid,
       'basic_product'::text              AS pinnedtomodelname,
       productattachment.attachment,
       productattachment.name,
       productattachment.size,
       upper(productattachment.ext::text) AS ext,
       row_number() OVER ()               AS id,
       'basic/productDetails'::text       AS pinnedtocorrespondingview
FROM basic_productattachment productattachment
         LEFT JOIN basic_product product ON productattachment.product_id = product.id
UNION ALL
SELECT '02technologies'::text                 AS pinnedto,
       technology.number                      AS pinnedtoobjectidentifier,
       technology.name                        AS pinnedtoobjectidentifiername,
       technology.id::integer                 AS pinnedtoobjectid,
       'technologies_technology'::text        AS pinnedtomodelname,
       technologyattachment.attachment,
       technologyattachment.name,
       technologyattachment.size,
       upper(technologyattachment.ext::text)  AS ext,
       1000000 + row_number() OVER ()         AS id,
       'technologies/technologyDetails'::text AS pinnedtocorrespondingview
FROM technologies_technologyattachment technologyattachment
         LEFT JOIN technologies_technology technology ON technologyattachment.technology_id = technology.id
UNION ALL
SELECT '03parts'::text                             AS pinnedto,
       machinepart.number                          AS pinnedtoobjectidentifier,
       machinepart.name                            AS pinnedtoobjectidentifiername,
       machinepart.id::integer                     AS pinnedtoobjectid,
       'basic_product'::text                       AS pinnedtomodelname,
       machinepartattachment.attachment,
       machinepartattachment.name,
       machinepartattachment.size,
       upper(machinepartattachment.ext::text)      AS ext,
       2000000 + row_number() OVER ()              AS id,
       'cmmsMachineParts/machinePartDetails'::text AS pinnedtocorrespondingview
FROM cmmsmachineparts_machinepartattachment machinepartattachment
         LEFT JOIN basic_product machinepart ON machinepartattachment.product_id = machinepart.id
UNION ALL
SELECT '04components'::text                   AS pinnedto,
       subassembly.number                     AS pinnedtoobjectidentifier,
       subassembly.name                       AS pinnedtoobjectidentifiername,
       subassembly.id::integer                AS pinnedtoobjectid,
       'basic_product'::text                  AS pinnedtomodelname,
       subassemblyattachment.attachment,
       subassemblyattachment.name,
       subassemblyattachment.size,
       upper(subassemblyattachment.ext::text) AS ext,
       3000000 + row_number() OVER ()         AS id,
       'basic/subassemblyDetails'::text       AS pinnedtocorrespondingview
FROM basic_subassemblyattachment subassemblyattachment
         LEFT JOIN basic_subassembly subassembly ON subassemblyattachment.subassembly_id = subassembly.id
UNION ALL
SELECT '05batches'::text                      AS pinnedto,
       batch.number                           AS pinnedtoobjectidentifier,
       ''::text                               AS pinnedtoobjectidentifiername,
       batch.id::integer                      AS pinnedtoobjectid,
       'advancedgenealogy_batch'::text        AS pinnedtomodelname,
       batchattachment.attachment,
       batchattachment.name,
       batchattachment.size,
       upper(batchattachment.ext::text)       AS ext,
       4000000 + row_number() OVER ()         AS id,
       'advancedGenealogy/batchDetails'::text AS pinnedtocorrespondingview
FROM advancedgenealogy_batchattachment batchattachment
         LEFT JOIN advancedgenealogy_batch batch ON batchattachment.batch_id = batch.id
UNION ALL
SELECT '06deliveries'::text                AS pinnedto,
       delivery.number                     AS pinnedtoobjectidentifier,
       delivery.name                       AS pinnedtoobjectidentifiername,
       delivery.id::integer                AS pinnedtoobjectid,
       'deliveries_delivery'::text         AS pinnedtomodelname,
       deliveryattachment.attachment,
       deliveryattachment.name,
       deliveryattachment.size,
       upper(deliveryattachment.ext::text) AS ext,
       5000000 + row_number() OVER ()      AS id,
       'deliveries/deliveryDetails'::text  AS pinnedtocorrespondingview
FROM deliveries_deliveryattachment deliveryattachment
         LEFT JOIN deliveries_delivery delivery ON deliveryattachment.delivery_id = delivery.id
UNION ALL
SELECT '07qualityControls'::text                    AS pinnedto,
       qualitycontrol.number                        AS pinnedtoobjectidentifier,
       ''::text                                     AS pinnedtoobjectidentifiername,
       qualitycontrol.id::integer                   AS pinnedtoobjectid,
       'qualitycontrol_qualitycontrol'::text        AS pinnedtomodelname,
       qualitycontrolattachment.attachment,
       qualitycontrolattachment.name,
       qualitycontrolattachment.size,
       upper(qualitycontrolattachment.ext::text)    AS ext,
       6000000 + row_number() OVER ()               AS id,
       'qualityControl/qualityControlDetails'::text AS pinnedtocorrespondingview
FROM qualitycontrol_qualitycontrolattachment qualitycontrolattachment
         LEFT JOIN qualitycontrol_qualitycontrol qualitycontrol
                   ON qualitycontrolattachment.qualitycontrol_id = qualitycontrol.id
UNION ALL
SELECT '08qualityCards'::text                    AS pinnedto,
       qualitycard.number                        AS pinnedtoobjectidentifier,
       qualitycard.name                          AS pinnedtoobjectidentifiername,
       qualitycard.id::integer                   AS pinnedtoobjectid,
       'technologies_qualitycard'::text          AS pinnedtomodelname,
       qualitycardattachment.attachment,
       qualitycardattachment.name,
       qualitycardattachment.size,
       upper(qualitycardattachment.ext::text)    AS ext,
       7000000 + row_number() OVER ()            AS id,
       'qualityControl/qualityCardDetails'::text AS pinnedtocorrespondingview
FROM qualitycontrol_qualitycardattachment qualitycardattachment
         LEFT JOIN technologies_qualitycard qualitycard ON qualitycardattachment.qualitycard_id = qualitycard.id
UNION ALL
SELECT '09workstations'::text                 AS pinnedto,
       workstation.number                     AS pinnedtoobjectidentifier,
       workstation.name                       AS pinnedtoobjectidentifiername,
       workstation.id::integer                AS pinnedtoobjectid,
       'basic_workstation'::text              AS pinnedtomodelname,
       workstationattachment.attachment,
       workstationattachment.name,
       workstationattachment.size,
       upper(workstationattachment.ext::text) AS ext,
       8000000 + row_number() OVER ()         AS id,
       'basic/workstationDetails'::text       AS pinnedtocorrespondingview
FROM basic_workstationattachment workstationattachment
         LEFT JOIN basic_workstation workstation ON workstationattachment.workstation_id = workstation.id
UNION ALL
SELECT '10orders'::text                 AS pinnedto,
       o.number                         AS pinnedtoobjectidentifier,
       o.name                           AS pinnedtoobjectidentifiername,
       o.id::integer                    AS pinnedtoobjectid,
       'orders_order'::text             AS pinnedtomodelname,
       orderattachment.attachment,
       orderattachment.name,
       orderattachment.size,
       upper(orderattachment.ext::text) AS ext,
       9000000 + row_number() OVER ()   AS id,
       'orders/orderDetails'::text      AS pinnedtocorrespondingview
FROM orders_orderattachment orderattachment
         LEFT JOIN orders_order o ON orderattachment.order_id = o.id
UNION ALL
SELECT '11tools'::text                      AS pinnedto,
       tool.number                          AS pinnedtoobjectidentifier,
       tool.name                            AS pinnedtoobjectidentifiername,
       tool.id::integer                     AS pinnedtoobjectid,
       'cmmsmachineparts_tool'::text        AS pinnedtomodelname,
       toolattachment.attachment,
       toolattachment.name,
       toolattachment.size,
       upper(toolattachment.ext::text)      AS ext,
       10000000 + row_number() OVER ()      AS id,
       'cmmsMachineParts/toolDetails'::text AS pinnedtocorrespondingview
FROM cmmsmachineparts_toolattachment toolattachment
         LEFT JOIN cmmsmachineparts_tool tool ON toolattachment.tool_id = tool.id;

alter table basic_attachmentdto
    owner to postgres;


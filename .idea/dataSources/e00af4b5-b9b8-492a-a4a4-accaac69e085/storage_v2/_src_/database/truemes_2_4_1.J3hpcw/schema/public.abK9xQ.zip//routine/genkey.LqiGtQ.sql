create function genkey() returns void
    language plpgsql
as
$$
	DECLARE
		arch_table RECORD;
		orgin_table RECORD;
		ogin_column_name text;
		foregin_table_name text;
		arch_foregin_table_name text;
	BEGIN
		FOR arch_table IN SELECT * FROM information_schema.tables AS t
			WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE'
				AND t.table_name LIKE 'arch_%'
			ORDER BY t.table_name
		LOOP
			FOR orgin_table IN SELECT distinct(conname), conrelid::regclass AS table_from, contypid::regclass, conindid::regclass, confrelid::regclass, pg_get_constraintdef(c.oid)
				FROM pg_constraint c JOIN   pg_namespace n ON n.oid = c.connamespace WHERE  contype IN ('f')
				AND    n.nspname = 'public' AND  conrelid = substring(arch_table.table_name from 6 for  char_length(arch_table.table_name)-5)::regclass
			LOOP
					ogin_column_name = substring(orgin_table.pg_get_constraintdef from 14 for (position(') REFERENCES' in orgin_table.pg_get_constraintdef) - 14));
					IF  position('(id) DEFERRABLE' in orgin_table.pg_get_constraintdef) = 0 THEN
						foregin_table_name = substring(orgin_table.pg_get_constraintdef from position('REFERENCES ' in orgin_table.pg_get_constraintdef) +11  for (position('(id)' in orgin_table.pg_get_constraintdef) - position('REFERENCES' in orgin_table.pg_get_constraintdef)-11));
					ELSE
						foregin_table_name = substring(orgin_table.pg_get_constraintdef from position('REFERENCES ' in orgin_table.pg_get_constraintdef) +11  for (position('(id) DEFERRABLE' in orgin_table.pg_get_constraintdef) - position('REFERENCES' in orgin_table.pg_get_constraintdef)-11));
					END IF;
					arch_foregin_table_name = 'arch_' || foregin_table_name;
					IF EXISTS (
						SELECT 1 FROM information_schema.tables WHERE table_name = arch_foregin_table_name
					) THEN
						foregin_table_name = arch_foregin_table_name;
					END IF;
					EXECUTE 'ALTER TABLE ' || arch_table.table_name || ' ADD CONSTRAINT ' || orgin_table.conname || ' FOREIGN KEY ('|| ogin_column_name ||') REFERENCES ' || foregin_table_name || ' (id) DEFERRABLE;';
			END LOOP;
		END LOOP;
	END;
$$;

alter function genkey() owner to postgres;


create function add_group_role(group_identifier character varying, role_identifier character varying) returns void
    language plpgsql
as
$$
    DECLARE
        groupid bigint;
        roleid bigint;
        relationcount bigint;

    BEGIN

        SELECT id INTO groupid FROM qcadoosecurity_group WHERE identifier = group_identifier;

        IF groupid is null THEN
            RAISE EXCEPTION 'Group(%s) not found', group_identifier;
        END IF;

        SELECT id INTO roleid FROM qcadoosecurity_role WHERE identifier = role_identifier;

        IF roleid is null THEN
            RAISE EXCEPTION 'Role(%) not found', role_identifier;
        END IF;

        SELECT count(*) INTO relationcount FROM jointable_group_role WHERE group_id = groupid AND role_id = roleid;

        IF relationcount = 0 THEN
            INSERT INTO jointable_group_role (group_id, role_id) VALUES (groupid, roleid);
        END IF;

    END;
$$;

alter function add_group_role(varchar, varchar) owner to postgres;


create view cmmsmachineparts_plannedeventlistdto
            (id, number, type, ownername, description, factorynumber, factory_id, divisionnumber, division_id,
             productionlinenumber, workstationnumber, subassemblynumber, date, counter, createuser, createdate, state,
             plannedeventcontext_id, workstation_id, subassembly_id, company_id, sourcecost_id)
as
SELECT e.id,
       e.number,
       e.type,
       (owner.name::text || ' '::text) || owner.surname::text AS ownername,
       e.description,
       factory.number                                         AS factorynumber,
       factory.id::integer                                    AS factory_id,
       division.number                                        AS divisionnumber,
       division.id::integer                                   AS division_id,
       productionline.number                                  AS productionlinenumber,
       workstation.number                                     AS workstationnumber,
       subassembly.number                                     AS subassemblynumber,
       e.date::timestamp without time zone                    AS date,
       e.counter,
       e.createuser,
       e.createdate,
       e.state,
       context.id                                             AS plannedeventcontext_id,
       workstation.id                                         AS workstation_id,
       subassembly.id                                         AS subassembly_id,
       company.id                                             AS company_id,
       sourcecost.id                                          AS sourcecost_id
FROM cmmsmachineparts_plannedevent e
         LEFT JOIN basic_staff owner ON e.owner_id = owner.id
         JOIN basic_factory factory ON e.factory_id = factory.id
         JOIN basic_division division ON e.division_id = division.id
         LEFT JOIN productionlines_productionline productionline ON e.productionline_id = productionline.id
         LEFT JOIN basic_workstation workstation ON e.workstation_id = workstation.id
         LEFT JOIN basic_subassembly subassembly ON e.subassembly_id = subassembly.id
         LEFT JOIN cmmsmachineparts_plannedeventcontext context ON e.plannedeventcontext_id = context.id
         LEFT JOIN basic_company company ON e.company_id = company.id
         LEFT JOIN cmmsmachineparts_sourcecost sourcecost ON e.sourcecost_id = sourcecost.id;

alter table cmmsmachineparts_plannedeventlistdto
    owner to postgres;


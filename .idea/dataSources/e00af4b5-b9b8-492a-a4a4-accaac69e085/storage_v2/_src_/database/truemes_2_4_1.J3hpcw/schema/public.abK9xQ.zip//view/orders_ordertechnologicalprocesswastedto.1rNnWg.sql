create view orders_ordertechnologicalprocesswastedto
            (id, number, date, worker, wastequantity, productunit, causeofwaste, orderpackid, orderpacknumber,
             technologicalprocessid, technologicalprocessname, orderid, ordernumber, productid, productnumber,
             ordertechnologicalprocessid, ordertechnologyprocessnumber, ordertechnologicalprocessdate,
             ordertechnologicalprocessworker)
as
SELECT ordertechnologicalprocesswaste.id,
       ordertechnologicalprocesswaste.number,
       ordertechnologicalprocesswaste.date,
       (staff.name::text || ' '::text) || staff.surname::text           AS worker,
       ordertechnologicalprocesswaste.wastequantity,
       product.unit                                                     AS productunit,
       ordertechnologicalprocesswaste.causeofwaste,
       orderpack.id::integer                                            AS orderpackid,
       orderpack.number                                                 AS orderpacknumber,
       technologicalprocess.id::integer                                 AS technologicalprocessid,
       technologicalprocess.name                                        AS technologicalprocessname,
       ordersorder.id::integer                                          AS orderid,
       ordersorder.number                                               AS ordernumber,
       product.id::integer                                              AS productid,
       product.number                                                   AS productnumber,
       ordertechnologicalprocess.id::integer                            AS ordertechnologicalprocessid,
       ordertechnologicalprocess.number                                 AS ordertechnologyprocessnumber,
       ordertechnologicalprocess.date                                   AS ordertechnologicalprocessdate,
       (orderstaff.name::text || ' '::text) || orderstaff.surname::text AS ordertechnologicalprocessworker
FROM orders_ordertechnologicalprocesswaste ordertechnologicalprocesswaste
         LEFT JOIN basic_staff staff ON staff.id = ordertechnologicalprocesswaste.worker_id
         LEFT JOIN orders_orderpack orderpack ON orderpack.id = ordertechnologicalprocesswaste.orderpack_id
         LEFT JOIN technologies_technologicalprocess technologicalprocess
                   ON technologicalprocess.id = ordertechnologicalprocesswaste.technologicalprocess_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = ordertechnologicalprocesswaste.order_id
         LEFT JOIN basic_product product ON product.id = ordertechnologicalprocesswaste.product_id
         LEFT JOIN orders_ordertechnologicalprocess ordertechnologicalprocess
                   ON ordertechnologicalprocess.id = ordertechnologicalprocesswaste.ordertechnologicalprocess_id
         LEFT JOIN basic_staff orderstaff ON orderstaff.id = ordertechnologicalprocess.worker_id;

alter table orders_ordertechnologicalprocesswastedto
    owner to postgres;


create function generate_master_order_number() returns text
    language plpgsql
as
$$
DECLARE
    _yymm text;
	_sequence_name text;
	_sequence_value numeric;
	_tmp text;
	_seq text;
	_number text;
BEGIN
    _yymm := to_char(current_timestamp, 'YYMM');

	_sequence_name := 'masterorders_master_order_number_' || _yymm || '_seq';

	SELECT sequence_name into _tmp FROM information_schema.sequences where sequence_schema = 'public'
		and sequence_name = _sequence_name;
	if _tmp is null then
		execute 'CREATE SEQUENCE ' || _sequence_name || ';';
	end if;

	select nextval(_sequence_name) into _sequence_value;

	_seq := to_char(_sequence_value, 'fm0000');
	if _seq like '%#%' then
		_seq := _sequence_value;
	end if;

	_number := _yymm || _seq;

	RETURN _number;
END;
$$;

alter function generate_master_order_number() owner to postgres;


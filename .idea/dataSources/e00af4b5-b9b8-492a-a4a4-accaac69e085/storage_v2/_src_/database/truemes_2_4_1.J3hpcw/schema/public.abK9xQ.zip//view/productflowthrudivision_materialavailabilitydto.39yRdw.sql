create view productflowthrudivision_materialavailabilitydto
            (id, order_id, orderid, product_id, productid, location_id, locationid, locationnumber, ordernumber,
             productnumber, productname, productunit, availablequantity, requiredquantity, unit, availability,
             replacement, batchesid, batches, batchesquantity, batchesquantityclass)
as
SELECT materialavailability.id,
       materialavailability.order_id,
       materialavailability.order_id::integer    AS orderid,
       materialavailability.product_id,
       materialavailability.product_id::integer  AS productid,
       materialavailability.location_id,
       materialavailability.location_id::integer AS locationid,
       location.number                           AS locationnumber,
       ordersorder.number                        AS ordernumber,
       product.number                            AS productnumber,
       product.name                              AS productname,
       product.unit                              AS productunit,
       materialavailability.availablequantity,
       materialavailability.requiredquantity,
       materialavailability.unit,
       materialavailability.availability,
       materialavailability.replacement,
       materialavailability.batchesid,
       materialavailability.batches,
       materialavailability.batchesquantity,
       CASE
           WHEN materialavailability.batchesquantity >= 0::numeric AND
                materialavailability.requiredquantity > materialavailability.batchesquantity AND
                materialavailability.batchesid IS NOT NULL THEN 'red-cell'::text
           ELSE 'base-cell'::text
           END                                   AS batchesquantityclass
FROM productflowthrudivision_materialavailability materialavailability
         JOIN orders_order ordersorder ON ordersorder.id = materialavailability.order_id
         JOIN basic_product product ON product.id = materialavailability.product_id
         LEFT JOIN materialflow_location location ON location.id = materialavailability.location_id;

alter table productflowthrudivision_materialavailabilitydto
    owner to postgres;


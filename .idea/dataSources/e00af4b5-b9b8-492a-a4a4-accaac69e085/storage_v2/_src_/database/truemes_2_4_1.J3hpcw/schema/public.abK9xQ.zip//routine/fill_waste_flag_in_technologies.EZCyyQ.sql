create function fill_waste_flag_in_technologies() returns void
    language plpgsql
as
$$
DECLARE
_opoc RECORD;

BEGIN
FOR _opoc IN
SELECT opoc.id, opoc.productsinputlocation_id, opoc.productsflowlocation_id
FROM technologies_operationproductoutcomponent opoc
         LEFT JOIN basic_product pr ON pr.id = opoc.product_id
         LEFT JOIN technologies_technologyoperationcomponent toc ON toc.id = opoc.operationcomponent_id
         LEFT JOIN technologies_technologyoperationcomponent parent ON parent.id = toc.parent_id
WHERE toc.parent_id is not null AND (select count(1) from technologies_operationproductincomponent _opic
									 WHERE _opic.operationcomponent_id = toc.parent_id AND _opic.product_id = opoc.product_id) = 0
    LOOP
UPDATE technologies_operationproductoutcomponent
set waste = true, wastereceptionwarehouse_id = COALESCE(_opoc.productsinputlocation_id, _opoc.productsflowlocation_id),
    productsinputlocation_id = null, productsflowlocation_id = null
WHERE id = _opoc.id;
END LOOP;
END;
$$;

alter function fill_waste_flag_in_technologies() owner to postgres;


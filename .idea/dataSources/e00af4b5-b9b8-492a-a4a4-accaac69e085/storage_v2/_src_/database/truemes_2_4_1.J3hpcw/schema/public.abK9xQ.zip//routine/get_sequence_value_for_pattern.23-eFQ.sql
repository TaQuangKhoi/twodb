create function get_sequence_value_for_pattern(_patternnumber text, _monthly boolean, _annual boolean) returns text
    language plpgsql
as
$$
DECLARE
	_year numeric;
	_yymm text;
	_sequence_name text;
	_sequence_value numeric;
	_tmp text;
BEGIN
	_year := to_char(current_timestamp, 'YY');
    _yymm := to_char(current_timestamp, 'YYMM');

	if _monthly then
				_sequence_name := 'number_pattern_' || _patternNumber || '_' || _yymm|| '_seq';
	elsif _annual then
			_sequence_name := 'number_pattern_' || _patternNumber || '_' || _year|| '_seq';
	else
		_sequence_name := 'number_pattern_' || _patternNumber || '_seq';
	end if;

	SELECT sequence_name into _tmp FROM information_schema.sequences where sequence_schema = 'public'
		and sequence_name = _sequence_name;
	if _tmp is null then
		execute 'CREATE SEQUENCE ' || _sequence_name || ';';
	end if;

	select nextval(_sequence_name) into _sequence_value;

	RETURN _sequence_value;
END;
$$;

alter function get_sequence_value_for_pattern(text, boolean, boolean) owner to postgres;


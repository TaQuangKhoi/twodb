create view basicproductioncounting_productioncountingquantitylistdto
            (id, ordernumber, orderid, operationaltasknumber, operationaltaskid, startdate, productnumber, productname,
             productunit, nodenumber, operationnumber, operationname, role, typeofmaterial, plannedquantity,
             usedquantity, producedquantity, replacementto, technologyinputproducttypename)
as
SELECT pcq.id,
       o.number                                        AS ordernumber,
       o.id::integer                                   AS orderid,
       ot.number                                       AS operationaltasknumber,
       ot.id::integer                                  AS operationaltaskid,
       COALESCE(ot.startdate, o.startdate)             AS startdate,
       product.number                                  AS productnumber,
       product.name                                    AS productname,
       product.unit                                    AS productunit,
       COALESCE(toc.nodenumber, ''::character varying) AS nodenumber,
       COALESCE(op.number, ''::character varying)      AS operationnumber,
       COALESCE(op.name, ''::character varying)        AS operationname,
       pcq.role,
       pcq.typeofmaterial,
       pcq.plannedquantity,
       COALESCE(pcq.usedquantity, 0::numeric)          AS usedquantity,
       COALESCE(pcq.producedquantity, 0::numeric)      AS producedquantity,
       replacementto.number                            AS replacementto,
       tipt.name                                       AS technologyinputproducttypename
FROM basicproductioncounting_productioncountingquantity pcq
         JOIN basic_product product ON product.id = pcq.product_id
         JOIN orders_order o ON o.id = pcq.order_id
         LEFT JOIN technologies_technologyoperationcomponent toc ON pcq.technologyoperationcomponent_id = toc.id
         LEFT JOIN technologies_operation op ON op.id = toc.operation_id
         LEFT JOIN technologies_technologyinputproducttype tipt ON tipt.id = pcq.technologyinputproducttype_id
         LEFT JOIN orders_operationaltask ot ON ot.order_id = o.id AND ot.technologyoperationcomponent_id = toc.id
         LEFT JOIN basic_product replacementto ON replacementto.id = pcq.replacementto_id
WHERE o.typeofproductionrecording::text = '02cumulated'::text
  AND (o.state::text = ANY
       (ARRAY ['02accepted'::character varying::text, '03inProgress'::character varying::text, '06interrupted'::character varying::text]))
UNION
SELECT pcq.id,
       o.number                                   AS ordernumber,
       o.id::integer                              AS orderid,
       ot.number                                  AS operationaltasknumber,
       ot.id::integer                             AS operationaltaskid,
       COALESCE(ot.startdate, o.startdate)        AS startdate,
       product.number                             AS productnumber,
       product.name                               AS productname,
       product.unit                               AS productunit,
       toc.nodenumber,
       op.number                                  AS operationnumber,
       op.name                                    AS operationname,
       pcq.role,
       pcq.typeofmaterial,
       pcq.plannedquantity,
       COALESCE(pcq.usedquantity, 0::numeric)     AS usedquantity,
       COALESCE(pcq.producedquantity, 0::numeric) AS producedquantity,
       replacementto.number                       AS replacementto,
       tipt.name                                  AS technologyinputproducttypename
FROM basicproductioncounting_productioncountingquantity pcq
         JOIN basic_product product ON product.id = pcq.product_id
         JOIN orders_order o ON o.id = pcq.order_id
         JOIN technologies_technologyoperationcomponent toc ON pcq.technologyoperationcomponent_id = toc.id
         JOIN technologies_operation op ON op.id = toc.operation_id
         LEFT JOIN technologies_technologyinputproducttype tipt ON tipt.id = pcq.technologyinputproducttype_id
         LEFT JOIN orders_operationaltask ot ON ot.order_id = o.id AND ot.technologyoperationcomponent_id = toc.id
         LEFT JOIN basic_product replacementto ON replacementto.id = pcq.replacementto_id
WHERE o.typeofproductionrecording::text = '03forEach'::text
  AND (o.state::text = ANY
       (ARRAY ['02accepted'::character varying::text, '03inProgress'::character varying::text, '06interrupted'::character varying::text]));

alter table basicproductioncounting_productioncountingquantitylistdto
    owner to postgres;


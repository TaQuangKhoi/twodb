create view materialflowresources_documentdto
            (inbuffer, id, number, description, name, type, time, state, active, locationfrom_id, locationfromnumber,
             locationto_id, locationtonumber, company_id, companyname, documentaddress, user_id, username,
             maintenanceevent_id, maintenanceeventnumber, plannedevent_id, plannedeventnumber, delivery_id,
             deliverynumber, order_id, ordernumber, suborder_id, subordernumber, printed, issend, wms, stateinwms,
             pickingworker, staff, ordersgroup)
as
SELECT document.inbuffer,
       document.id,
       document.number,
       document.description,
       document.name,
       document.type,
       document."time",
       document.state,
       document.active,
       locationfrom.id::integer                                                   AS locationfrom_id,
       locationfrom.number                                                        AS locationfromnumber,
       locationto.id::integer                                                     AS locationto_id,
       locationto.number                                                          AS locationtonumber,
       company.id::integer                                                        AS company_id,
       company.name                                                               AS companyname,
       CASE
           WHEN address.name IS NULL THEN address.number::text
           ELSE (address.number::text || ' - '::text) || address.name::text
           END                                                                    AS documentaddress,
       securityuser.id::integer                                                   AS user_id,
       (securityuser.firstname::text || ' '::text) || securityuser.lastname::text AS username,
       maintenanceevent.id::integer                                               AS maintenanceevent_id,
       maintenanceevent.number                                                    AS maintenanceeventnumber,
       plannedevent.id::integer                                                   AS plannedevent_id,
       plannedevent.number                                                        AS plannedeventnumber,
       delivery.id::integer                                                       AS delivery_id,
       delivery.number                                                            AS deliverynumber,
       ordersorder.id::integer                                                    AS order_id,
       ordersorder.number                                                         AS ordernumber,
       suborder.id::integer                                                       AS suborder_id,
       suborder.number                                                            AS subordernumber,
       document.printed,
       document.issend,
       document.wms,
       document.stateinwms,
       document.pickingworker,
       (stf.surname::text || ' '::text) || stf.name::text                         AS staff,
       og.number                                                                  AS ordersgroup
FROM materialflowresources_document document
         LEFT JOIN materialflow_location locationfrom ON locationfrom.id = document.locationfrom_id
         LEFT JOIN materialflow_location locationto ON locationto.id = document.locationto_id
         LEFT JOIN basic_company company ON company.id = document.company_id
         LEFT JOIN basic_address address ON address.id = document.address_id
         LEFT JOIN qcadoosecurity_user securityuser ON securityuser.id = document.user_id
         LEFT JOIN cmmsmachineparts_maintenanceevent maintenanceevent
                   ON maintenanceevent.id = document.maintenanceevent_id
         LEFT JOIN cmmsmachineparts_plannedevent plannedevent ON plannedevent.id = document.plannedevent_id
         LEFT JOIN deliveries_delivery delivery ON delivery.id = document.delivery_id
         LEFT JOIN orders_order ordersorder ON ordersorder.id = document.order_id
         LEFT JOIN subcontractorportal_suborder suborder ON suborder.id = document.suborder_id
         LEFT JOIN basic_staff stf ON stf.id = document.staff_id
         LEFT JOIN ordersgroups_ordersgroup og ON og.id = document.ordersgroup_id;

alter table materialflowresources_documentdto
    owner to postgres;

